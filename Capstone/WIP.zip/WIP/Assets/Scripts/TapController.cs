﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//this tells Unity to make a 2D rigid body
[RequireComponent(typeof(Rigidbody2D))]
public class TapController : MonoBehaviour {
    public delegate void PlayerDelegate();
    public static event PlayerDelegate OnPlayerDeath;
    public static event PlayerDelegate OnPlayerScored;

    public float tapForce = 10;
    public float tiltSmooth = 5; //rotates the bird
    public Vector3 startPos;

    //audio
    public AudioSource tapAudio;
    public AudioSource scoreAudio;
    public AudioSource deathAudio;
    Rigidbody2D rb;
    //Quaternion is a form of rotation using x,y,z,w and is a Vector4 
    Quaternion downRotation;
    Quaternion forwardRotation;
    GameManager game;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        downRotation = Quaternion.Euler(0,0,-90); //turning a vector3 to quaternion
        forwardRotation = Quaternion.Euler(0, 0, 35);
        game = GameManager.Instance;
        rb.simulated = false;
    }
    void OnEnable()
    {
        GameManager.OnGameStarted += OnGameStarted;
        GameManager.OnGameOverConfirmed += OnGameOverConfirmed;

    }

    void OnDisable()
    {
        GameManager.OnGameStarted -= OnGameStarted;
        GameManager.OnGameOverConfirmed -= OnGameOverConfirmed;
    }

    void OnGameStarted()
    {
        rb.velocity = Vector3.zero;
        rb.simulated = true;
    }

    void OnGameOverConfirmed()
    {
        //reset the position of everything
        transform.localPosition = startPos; //inside the parent object
        transform.rotation = Quaternion.identity;
    }
    void Update()
    {
        if (game.GameOver) return;

        if (Input.GetMouseButtonDown(0))
        {
            tapAudio.Play();
           // Time.timeScale += 1;
            transform.rotation = forwardRotation;
            rb.velocity = Vector3.zero;
            rb.AddForce(Vector2.up * tapForce, ForceMode2D.Force);
        }

        transform.rotation = Quaternion.Lerp(transform.rotation, downRotation, tiltSmooth * Time.deltaTime); //source value to target value over
        //period of time
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "ScoreZone")
        {
            //register a score event
            OnPlayerScored(); //event sent to GameManager
            //play a sound
            scoreAudio.Play();
        }
        if(collision.gameObject.tag == "DeadZone")
        {
            rb.simulated = false;
            //register a dead event
            OnPlayerDeath(); //event sent to GameManager
            //play a sound
            deathAudio.Play();
        }
    }
}
