public class Questions {

    public static void rotate(int array[], int n){
        int tempArray = array[0]; //start at the beginning
        int i;
        for(i =0; i < n-1; i++){
            //swap the element
            array[i] = array[i + 1];
        }
        array[i] = tempArray;
    }

    public static void rotateArray(int array[], int d, int n){
        for(int i = 0; i < d; i++){
            //call the method here to rotate the array
            rotate(array, n);
        }
    }

    public static int Minimum(int array[], int n){
        int min = array[0]; //start in the beginning

        for(int i = 0; i < n; i++){
            if(array[i] < min){
                //if the element at the index
                // is less than the min
                //make it the new min
                min = array[i];
            }
        }
        return min;
    }

    public static void printArray(int array[], int n){
        for(int i = 0; i < n; i++){
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static void splitArray(int array[], int n, int d){

        //recycle from the rotate method
        for(int j = 0; j < d; j++) {
            int tempArray = array[0];
            int i;
            for (i = 0; i < n - 1; i++) {
                //swap the element
                array[i] = array[i + 1];
            }

            array[n - 1] = tempArray;
        }

    }
    public static void main(String [] args){
        //n refers to the size while d is the position
        //use .length as opposed to hardcoding the values
        // for convenience as array sizes may change
        System.out.println("Rotating the array: ");
        int array[] = {1,2,3,4,5,6,7}; //testing example from doc
        printArray(array, array.length); //7
        rotateArray(array, 2, array.length);
        printArray(array, array.length); //7

        System.out.println("Finding the minimum of the array(s): ");
        int arr[] = {5,6,1,2,3,4};
        int arrA[] = {1,2,3,4};
        int arrB[] = {2,1};
        printArray(arr,arr.length); //6
        printArray(arrA,arrA.length);
        printArray(arrB,arrB.length);
        int min = Minimum(arr, arr.length); //6
        int minA = Minimum(arrA, arrA.length); //6
        int minB = Minimum(arrB, arrB.length); //6
        System.out.println("Minimum element for 1st array is: " + min);
        System.out.println("Minimum element for 2nd array is: " + minA);
        System.out.println("Minimum element for 3rd array is: " + minB);
        System.out.println("Original array before splitting: ");
        int arr2[] = {12,10,5,6,52,36};
        printArray(arr2, arr2.length); //6
        int position = 2;

        splitArray(arr2, arr2.length, position); //6,2
        System.out.println("After splitting the array: ");
        printArray(arr2,arr2.length); //6
    }
}
