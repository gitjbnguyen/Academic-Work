import java.util.NoSuchElementException;

public class MyLinkedList {
    MyLinkedListNode first;
    MyLinkedListNode last;
    int count;

    public MyLinkedList()
    {
        first = last = null;
    }

    public int size()
    {
        return this.count;
    }

    public void addFirst(Comparable data)
    {
        // create a new node
        MyLinkedListNode node = new MyLinkedListNode(data);
        if (size() == 0)
        {
            first = node;
            last = node;
        }
        else
        {
            node.next = first;
            first.prev = node;
            first = node;
        }
        count++;
    }

    public void addLast(Comparable data)
    {
        // create a new node
        MyLinkedListNode node = new MyLinkedListNode(data);
        if(size() == 0)
        {
            first = node;
            last = node;
        }
        else
        {
            node.prev = last;
            last.next = node;
            last = node;

            // both work
            //last.next = node;
            //node.prev = last;
            //last = node;
        }
        count++;
    }

    public void insert(int index, Comparable data)
    {
        MyLinkedListNode afterNode = getNode(index);
        MyLinkedListNode beforeNode = afterNode.prev;

        MyLinkedListNode node = new MyLinkedListNode(data);

        // connect beforeNode to new node
        // connect new node to after node
    }

    public void removeDupes()
    {
        MyLinkedListNode head = first;
        //if the list is empty base case
        if(head == null)
        {
            return;
        }
        MyLinkedListNode current = head;

        //go through the list till the end
        while(current.next != null)
        {
            //compare current node with next node
            if(current.data == current.next.data)
            {
                //delete the node
                nodeDeletion(head, current.next);
            }
            else
                current = current.next;
        }
    }

    public void nodeDeletion(MyLinkedListNode head, MyLinkedListNode delete)
    {
        //base case
        if(head == null || delete == null)
        {
            return;
        }
        //if deleted node is head node
        if(head == delete)
        {
            head = delete.next;
        }
        //change next only if deleted node is not the last mode
        if(delete.next!= null)
        {
            delete.next.prev = delete.prev;
        }
        //change prev only if deleted node is not the first node
        if(delete.prev != null)
            delete.prev.next = delete.next;

    }

    private MyLinkedListNode getNode(int index)
    {
        // go through the nodes until we reach node at the given position
        MyLinkedListNode temp = first;
        int i = 0;
        while(i <= index)
        {
            // go to next node
            temp = temp.next;
            i++;
        }
        return temp; // pointing at the node at the given position
    }

    //helper method to be called in InsertionSort to help sort the linked list
    public MyLinkedListNode InsertionSortHelper(MyLinkedListNode head, MyLinkedListNode newNode)
    {
        MyLinkedListNode current;
        //check if list is empty
        if(head == null)
        {
            head = newNode;
        }
        //check if the node needs to be inserted in the beginning of the linked list
        else if(head.data.compareTo(newNode.data) >= 0)
        {
            newNode.next = head;
            newNode.next.prev = newNode;
            head = newNode;
        }
        else {
            current = head;

            //need to locate the node after the new node is inserted
            while(current.next != null && current.next.data.compareTo(newNode.data) < 0)
            {
                current = current.next;
            }
            newNode.next = current.next;

            //if the new node is not inserted
            if(current.next != null)
            {
                newNode.next.prev = newNode;
            }
            current.next = newNode;
            newNode.prev = current;

        }
        return head;
    }

    public MyLinkedListNode InsertionSort()
    {
        MyLinkedListNode sorted = null;
        //go through the doubly linked list and insert each node to sorted
        MyLinkedListNode current = first;
        while(current != null)
        {
            //store the next
            MyLinkedListNode next = current.next;

            //cut off links to create a new current node for insertion
            current.prev = current.next = null;

            //insert current in the sorted
            sorted = InsertionSortHelper(sorted,current);

            //update current
            current = next;

        }
        //update head to point to sorted
        first = sorted;
        return first;
    }

    public void Reverse()
    {
        MyLinkedListNode temp = null;
        MyLinkedListNode current = first;
        //to reverse the nodes, the nodes need to be swapped
        //swap next and previous for all nodes of doubly linked list
        //null at the end is okay which means it is the end of the list
        while(current != null)
        {
            temp = current.prev;
            current.prev = current.next;
            current.next = temp;
            current = current.prev;
        }

        //need to check if empty or list with one node
        if(temp != null)
        {
            first = temp.prev;
        }

    }


    public Comparable[] toArray()
    {
        Comparable[] array = new Comparable[count];
        MyLinkedListNode temp = first;
        int index = 0;
        while(temp != null)
        {
            // copy node to array at index
            array[index] = temp.data;
            // go to next node
            temp = temp.next;
            index++;
        }
        return array;
    }

    public Comparable removeFirst()
    {
        throw new NoSuchElementException();
    }

    public Comparable removeLast()
    {
        throw new NoSuchElementException();
    }

    public void display()
    {
        MyLinkedListNode temp = first;
        while(temp != null)
        {
            System.out.print(temp.data + "-->");
            // go to next node
            temp = temp.next;
        }
        System.out.println("null");
    }

    class MyLinkedListNode
    {
        Comparable data;
        MyLinkedListNode next;
        MyLinkedListNode prev;

        public MyLinkedListNode(Comparable data)
        {
            this.data = data;
            next = null;
            prev = null;
        }

    }

}
