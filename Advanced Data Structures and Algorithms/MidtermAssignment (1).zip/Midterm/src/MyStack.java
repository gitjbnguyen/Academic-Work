public class MyStack {
    Object[] array;
    int sp; //stack pointer. always points to the last item added to the stack(top of the stack)


    //constructors
    public MyStack(int capacity)
    {
        array = new Object[capacity];
        sp = -1; //initial value to indicate empty stack

    }
    //default constructor
    public MyStack()
    {
        //calls the MyStack with the capacity of 4
        //default capacity = 4
        this(4);
    }

    //property
    //public int Count { get { return sp + 1; } }

    public int Size(){
        return sp+1;
    }

    //methods
    public void Push(Object data)
    {
        //add item to the top or sometimes called the sp of the stack

        sp++;

        //make sure there is at least one spot
        if(sp < array.length){
            array[sp] = data;
        }
        //if there is no space
        else{
            //double the size
            // create a temp twice as big
            Object [] tempArray = new Object[2 * array.length];
            //copy the current array to the temp
            for(int i = 0; i < array.length; i++){
                tempArray[i] = array[i];
            }
            tempArray[sp] = data;
            //make the temp the array
            array = tempArray;
        }
    }
    public Object Pop()
    {
        //if empty throw an exception
        if(sp == -1)
            throw new IllegalArgumentException("Stack is empty.");
        else{
            //read data: remove and return it
            Object data = array[sp];
            //decrement sp
            sp--;
            return data;
        }
    }

    public Object Peek()
    {
        if(sp == -1)
            throw new IllegalArgumentException("Stack is empty.");
        return array[sp];
    }
    //----------------------
    public boolean Contains(Object data)
    {
        throw new IllegalArgumentException("");
    }

    public void Swap()
    {
        //keep the temp array the same size as the original
        // shifting values around, the length is not effected.
        Object [] temp = new Object [array.length];
        int position = 0;
        for(int i = array.length/2; i < array.length; i++)
        {
            temp[position++] = array[i];
        }

        for(int j = 0; j < array.length /2; j++)
        {
            temp[position++] = array[j];
        }
        array = temp;

    }

    //add helper method to test this class
    public void displayStack(){
        //display the stack
        if(sp == -1)
            throw new IllegalArgumentException("Stack is empty.");
        System.out.println();
        //display as if it is a stack, display from top down
        for(int i = sp; i >= 0; i--){
            System.out.println(i + " : " + array[i]);
        }
    }

    public void displaySwap()
    {
        for(int i =0; i <= sp; i++)
        {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }

}
