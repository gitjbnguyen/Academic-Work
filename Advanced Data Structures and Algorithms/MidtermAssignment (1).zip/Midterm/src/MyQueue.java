//Julie Nguyen
// 1/22/2021
// Queue Exercises 1 - 5
public class MyQueue {
    private Object[] array; //represents the internal storage of MyQueue
    private int front; // always points to the first element in the queue
    private int rear; //always points to the last element in the queue
    private int count; //is the number of elements in the queue

    //constructors
    public MyQueue()
    {
        array = new Object[8]; //default size of 8 elements
        front = rear = -1;//indicating that the two indices are pointing to any element
        count = 0;
    }
    public MyQueue(int capacity)
    {
        array = new Object[capacity];
        front = rear = -1;//indicating that the two indices are pointing to any element
        count = 0;
    }
    //property
    //get the number of items in queue
    public int size()
    {
        return count;
    }
    public void Enqueue(Object item)
    {
        if(size() ==0){
            front = rear = 0;
            array[rear] = item;
        }
        else if(size() < array.length){
            rear = (rear + 1) % array.length;
            array[rear] = item;
        }
        else{
            //double the size of the array
            //make temp array
            //copy array to temp
            Object [] temp = new Object[array.length * 2];
            //copy array to temp
            for(int i = 0; i < array.length; i++){
                temp[i] = array[i];
            }
            temp[rear+1] = item; //1
            //make temp array the array
            array = temp;
        }
        count++;

    }
    public int findMax(){
        int max = (int)array[0]; //start in the beginning

        for(int i = 0; i < array.length; i++){
            if((int)array[i] > max){
                //if the element at the index
                // is less than the max
                //make it the new max
                max = (int)array[i];
            }
        }
        return max;
    }

    public int indexOf(int item)
    {

        for(int i =0; i < array.length; i++) //or use count
        {
            if(array[i].equals(item))
            {
                return i; //return the position
            }
        }
        //if position not found or nonexistent return -1
        return -1;
    }

    public void MoveElement(int start, int end)
    {
        //wherever the starting position is of the element
        //being shifted
        int temp = (int)array[start];

        for(int i = start; i > 0; i--)
        {
            array[i] = array[i - 1];
        }
        //make that element move to the front
        array[end] = temp;

    }

    public int Sum(){
        int sum = 0;
        for(int i =0; i < count; i++){
            sum += (int)array[i];
        }
        return sum;
    }

    public int Average(){
        //call for convenience
        int sum = Sum();
        //divide by the # of elements in the queue
        return sum/count;
    }

    public MyQueue RemoveNegatives(){
        MyQueue temp = new MyQueue();

        for(int i = 0; i < count; i++){
            if((int)array[i] > 0){
                temp.Enqueue(array[i]);
            }
        }
        return temp;
    }

    public void RemoveNegativesNoShift(){
        for(int i = 0; i < count; i++){
            if((int)array[i] < 0){
                array[i] = null;
            }
        }
    }

    public Object Dequeue()
    {
        if(size() == 0)
            throw new IllegalArgumentException("Queue is empty.");
        else{
            Object data = array[front];
            //move front to the next item in line. rotate if necessary
            front = (front+1)% array.length; //make this circular
            count--;
            return data;
        }

    }
    public Object Peek()
    {
        //returns, but does not remove, the element in the front
        //check if empty
        if(size() ==0){
            throw new IllegalArgumentException("queue is empty");
        }
        return array[front];
    }

    public MyQueue CopyQueue(MyQueue q){
        //takes the original and copies it over to the temp
        MyQueue temp = new MyQueue();
        for(int i = 0; i < count; i++){
            temp.Enqueue(q.array[i]);
            //temp.array[i] = q.array[i];
        }
        return temp;
    }
    public MyQueue Merge(MyQueue queue1, MyQueue queue2)
    {
        MyQueue temp = new MyQueue();
        while(queue1.count != 0 && queue2.count != 0)
        {
            if(queue1.count != 0) {
                temp.Enqueue(queue1.Dequeue()); //a
            }
            if(queue2.count !=0) {
                temp.Enqueue(queue2.Dequeue()); //b
            }
        }

        while(queue1.count != 0)
        {
            temp.Enqueue(queue1.Dequeue());
        }
        while (queue2.count != 0)
        {
            temp.Enqueue(queue2.Dequeue());
        }
        return temp;
    }

    public MyQueue Reversal(){
        MyQueue temp = new MyQueue();
        //beware of accessing -1
        for(int i = count - 1; i >= 0; i--){
            temp.Enqueue(array[i]);
        }
        return temp;
    }
    public void display(){
        for(int i = 0; i < count; i++){
            System.out.print(array[i] + " : ");
        }
        System.out.println();
    }
}
