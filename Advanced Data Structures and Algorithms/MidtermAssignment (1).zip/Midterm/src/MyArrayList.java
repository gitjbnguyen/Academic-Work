import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;

public class MyArrayList {

    Object[] array;
    int pointer; //points to the last item added to this array
    int count;

    //constructor
    public MyArrayList(){
        array = new Object[8];
        count=0;
        pointer = -1;
    }
    public MyArrayList(int capacity){
        array = new Object[capacity];
        count=0;
        pointer = -1;
    }

    public int size(){
        return count;
    }

    //add method. to add a new item
    public void add(Object data){
        //increment pointer
        pointer++;
        if(pointer < array.length){
            array[pointer]=data;                    //1
            count++;                                //1
            //T(n)= 2 (constant)                    //O(1) constant time
        }
        else{
            int n = array.length;
            //create a temp array                             //Time complexity
            Object[] tempArray = new Object[2 * n];           // 2n
            //copy array to temp
            for(int i=0; i<n; i++){                         // 1 + n + n
                //copy from array to temp array
                tempArray[i] = array[i];                    //n
            }
            tempArray[pointer]=data;                        //1
            count++;                                        //1
            //make the tempArray the array
            array = tempArray;                              //1
        }
        //Time Complexity : T(n) = 5n + 4;

    }

    //remove data at specific index
    public void remove(int index){
        //make sure the index is valid
        //if not throw an IndexOutBoundException

        if(index > count)
            throw new IndexOutOfBoundsException();
        else
            for(int i = index; i < count; i++) //1 + n - n
            {
                //if yes remove it.
                array[i] = array[i + 1]; //n
            }
            array[count--] = null; //1
            pointer --; //1
        //write time complexity
        // T(n) = 3 + n



    }
    public int indexOf(Object data){

        for(int i = 0; i < count; i++)
        {
            //returns the index if found
            if (data.equals(array[i]))
                return i;
        }
        //returns -1 otherwise
        return -1;
        //use the equals method and not == for java code.

    }

    public MyArrayList removeDuplicates(MyArrayList list)
    {
        //create a hash table to store the duplicates
        Hashtable<Integer,Integer> hs = new Hashtable<Integer,Integer>();

        pointer = 0;
        //recycled logic from question 4 (this does not work)
        for(int i = 0; i < array.length - 1; i++)
        {
            if(!hs.contains(array[i]) && array[i] != array[i+1])
                array[pointer++] = array[i+1];
            //put the duplicates inside the hash table
                hs.put(i,i);
        }
        array[pointer++] = array[array.length-1];
        for(int i = array.length -1; i >= pointer; i--)
        {
            array[i] = 0;
        }

        return list;

    }

    //using a hash set as opposed to hash table
    public void removingDuplicatesUsingHS()
    {
        HashSet hs = new HashSet(array.length);

        for(var i : array)
        {
            hs.add(i);
        }
        //cleans up the null values
        hs.remove(null);
        array = hs.toArray(new Integer[hs.size()]);
    }



    public void DisplayArrayList()
    {
        for(int i =0; i < array.length; i++)
        {
            System.out.print(array[i] + " ");
        }
        System.out.println();
    }



}

















