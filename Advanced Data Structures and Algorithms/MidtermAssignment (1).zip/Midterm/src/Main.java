import jdk.jfr.Frequency;

import java.util.*;

public class Main {


    public static void Pairing(int[] array, int sum)
    {
        for(int i =0; i < array.length - 1; i++)
        {
            for(int j = i+1; j < array.length; j++)
            {
                if(array[i] + array[j] == sum)
                    System.out.println("pairs: (" + array[i] + " , " + array[j] + ")");

            }
        }
    }

    public static int [] Intersection(int [] a, int [] b, int length, int length2)
    {
        int i = 0;
        int j = 0;
        int count = 0;
        int [] intersection = new int [a.length];
        while(i < a.length && j < b.length)
        {
            if(a[i] < b[j])
                i++;
            else if(b[j] < a[i])
                j++;
            else
                intersection[count++] = b[j++];
                System.out.println(b[j++] + " ");
            i++;
        }
        return intersection;
    }

    public static Boolean Contain(int [] a, int element)
    {
        for(int i = 0; i < a.length; i++)
        {
            if(a[i] == element)
                return true;
        }
        return false;
    }


    public static int [] Intersect(int [] a, int [] b )
    {
        int [] Intersected = new int[a.length];
        int count = 0;
        for(int i = 0; i < a.length; i++)
        {
             //this for loop also contains the checking for repeats in the array
             for(int j = 0; j < b.length; j++)
             {
                 if(a[i] == b[j])
                 {
                     if (!Contain(Intersected, a[i]))
                         Intersected[count++] = a[i];
                 }
             }
        }
        return Intersected;
    }
    public static void Reversal(int [] array, int n)
    {
        for(int i =0; i < array.length/2; i++)
        {
            int temp = array[i];
            array[i] = array[n - i - 1];
            array[n - i - 1] = temp;

        }
    }
    public static void DisplayArray(int [] array)
    {
        for(int i = 0; i < array.length; i++)
        {
            //this is to clean up the excess zeros in the display as the array is initially initialized at 0.
            if (!(array[i] == 0))
                System.out.print(array[i] + " ");
        }
        System.out.println();
    }

    public static int NoDupes(int [] array)
    {
        //without the use of temp array
        if(array.length == 0 || array.length == 1)
        {
            return array.length;
        }
        int pointer = 0; //this goes point to the next element

        for(int i =0; i < array.length - 1; i++)
        {
            if(array[i] != array[i+1])
            {
                array[pointer++] = array[i];
            }
        }
        array[pointer++] = array[array.length-1];
        for(int i = array.length -1; i >= pointer; i--)
        {
            array[i] = 0;
        }

        return pointer;
    }

    public static void displayDQ(Deque<Integer> dq)
    {
        for (Iterator i = dq.iterator(); i.hasNext();)
        {
            System.out.print(i.next() + " ");
        }
        System.out.println();
    }

    public static void Frequency(ArrayList al)
    {
        HashMap<Object,Integer> map = new HashMap<>();
        int count = 0;
        for(int i = 0; i < al.size(); i++)
        {
            if(map.containsKey(al.get(i)))
            {
                count = map.get(al.get(i));
                map.put(al.get(i), count + 1);
            }
            else {
                map.put(al.get(i), 1);
            }

        }
        for(Map.Entry<Object,Integer> entry : map.entrySet())
        {
            System.out.print("Key:" + entry.getKey() + " ");
            System.out.println("frequency: " + entry.getValue());
        }
    }
    public static void main(String [] args)
    {
        //create a list that takes in a data type of Pair

        int [] q1 = {-5,-4,-1,-3,-2,0,1,2,3,4,6,5,-6};
        int [] q2 = {-5,-4,-1,-3,-2,0};
        int [] q3a = {1,2,3,4,5};
        int [] q3b = {1,21,68,4,5};
        int [] q4 = {7, 10,10, 12, 15, 17, 17, 17, 17, 20, 25, 33, 40,40,40, 45, 45,  49};
        MyLinkedList q5 = new MyLinkedList();
        q5.addFirst(1);
        q5.addFirst(2);
        q5.addFirst(3);
        q5.addFirst(4);
        q5.addFirst(5);

        MyLinkedList q6 = new MyLinkedList();
        q6.addFirst(10);
        q6.addFirst(3);
        q6.addFirst(2);
        q6.addFirst(40);
        q6.addFirst(50);

        MyLinkedList q7 = new MyLinkedList();
        q7.addFirst(100);
        q7.addFirst(3);
        q7.addFirst(2);
        q7.addFirst(50);
        q7.addFirst(50);
        q7.addFirst(10);
        q7.addFirst(1);

        MyStack q8 = new MyStack();
        q8.Push(2);
        q8.Push(4);
        q8.Push(6);
        q8.Push(8);
        q8.Push(10);

        Deque<Integer> q8dq = new LinkedList<Integer>();
        q8dq.add(2);
        q8dq.add(4);
        q8dq.add(6);
        q8dq.add(8);
        q8dq.add(10);

        MyStack q9 = new MyStack(10);
        //top half
        q9.Push(7);
        q9.Push(3);
        q9.Push(15);
        q9.Push(4);
        q9.Push(9);
        //bottom half
        q9.Push(20);
        q9.Push(33);
        q9.Push(25);
        q9.Push(31);
        q9.Push(27);

        MyQueue q10 = new MyQueue(5);
        q10.Enqueue(10);
        q10.Enqueue(2);
        q10.Enqueue(15);
        q10.Enqueue(7);
        q10.Enqueue(11);


        MyArrayList q11 = new MyArrayList(7);
        q11.add(1);
        q11.add(1);
        q11.add(2);
        q11.add(3);
        q11.add(3);
        q11.add(5);
        q11.add(6);

        //using built in arraylist
        ArrayList<Integer> q12 = new ArrayList<>(7);
        q12.add(1);
        q12.add(1);
        q12.add(2);
        q12.add(3);
        q12.add(3);
        q12.add(5);
        q12.add(6);




        System.out.println("Q1: Finding pairs that add up to 0.");
        System.out.println(Arrays.toString(q1));
        Pairing(q1,0);
        System.out.println("Q2: Reversing an int array without temp.");
        System.out.println("before reversal and after reversal:");
        //System.out.println(Arrays.toString(q2));
        DisplayArray(q2);
        Reversal(q2,q2.length);
        DisplayArray(q2);
        //System.out.println(Arrays.toString(q2));

        System.out.println("Q3: Finding common elements: ");
        DisplayArray(q3a);
        DisplayArray(q3b);

        int [] intersection = Intersect(q3a,q3b);
        DisplayArray(intersection);

        System.out.println("Q4: taking out duplicates from a given array");
        System.out.println("before");
        DisplayArray(q4);
        System.out.println("after");
        NoDupes(q4);
        DisplayArray(q4);

        System.out.println("Q5: reversing a linked list");
        System.out.println("before reversing linked list");
        q5.display();
        System.out.println("after reversing a linked list");
        q5.Reverse();
        q5.display();


        System.out.println("Q6: Sorting a doubly linked list using insertion sort");
        System.out.println("before insertion sort: ");
        q6.display();
        System.out.println("after insertion sort");
        q6.InsertionSort();
        q6.display();

        System.out.println("Q7: Removing duplicates from a sorted doubly linked list");
        System.out.println("Q7: before sorting and with duplicates");
        q7.display();
        System.out.println("Q7: after sorting and with duplicates");
        q7.InsertionSort();
        q7.display();
        System.out.println("Q7: after sorting and removing the duplicates");

        q7.removeDupes();
        q7.display();

        System.out.println("Q8: removing the last element in a stack");
        System.out.println("this is the current stack: ");
        q8.displayStack();
        System.out.println("After popping the last element: ");
        q8.Pop();
        q8.displayStack();

        System.out.println("Q8: removing the last element in a deque");
        System.out.println("this is the current deque: ");
        displayDQ(q8dq);
        System.out.println("After removing the last element: ");
        q8dq.removeLast();
        displayDQ(q8dq);
        System.out.println("Q9: Swapping halves of the stack");
        System.out.println("Original: ");
        q9.displaySwap();
        System.out.println("Q9: Swapped: ");
        q9.Swap();
        q9.displaySwap();

        System.out.println("Q10: moving the max element to the front of the queue");
        System.out.println("Original Queue:");
        q10.display();
        System.out.println("After shifting the max element:");
        int max = q10.findMax();
        int elementPosition = q10.indexOf(max);
        q10.MoveElement(elementPosition, 0);
        q10.display();


        System.out.println("Q11: removing duplicates with hash table (used hash set)");
        System.out.println("Original list: ");
        q11.DisplayArrayList();
        System.out.println("After removing duplicates: ");
        q11.removingDuplicatesUsingHS();
        q11.DisplayArrayList();
        System.out.println("Q12: follow up on question 11 except showing the frequencies");
        Frequency(q12);

    }
}
