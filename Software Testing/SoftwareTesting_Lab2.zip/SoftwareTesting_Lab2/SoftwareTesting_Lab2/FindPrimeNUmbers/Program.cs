﻿using System;


namespace FindPrimeNumbers
{
    class Program
    {
        static void Main(string[] args)
        {
            int n = 100;
            Console.Write($"Enter a number less than {n}: ");
            int num = int.Parse(Console.ReadLine());

            PrimeNumber pObj = new PrimeNumber() { Number = num };

            if (pObj.IsPrime())
            {
                Console.WriteLine($"{num} is a prime number!");
            }
            else
            {
                Console.WriteLine($"{num} is not a prime number!");
            }

            // Print all the prime numbers that are less than 'n'
            Console.WriteLine($"Prime numbers less than {n}:");
            FindAndPrintPrimeNumbers(n);
        }

        static void FindAndPrintPrimeNumbers(int range)
        {
            PrimeNumber pObj = new PrimeNumber();
            for (int i = 3; i < range; i++)
            {
                pObj.Number = i;
                if (pObj.IsPrime()) Console.Write($"{i} ");
            }
            Console.WriteLine();
        }

     
    }
}
