﻿using System;
using FindPrimeNumbers;
using NUnit.Framework;

namespace FindPrimeNumbersTester
{
    [TestFixture]
    public class UnitTests
    {
        PrimeNumber pNumber;

        [TestFixtureSetUp]

        public void TestSetup()
        {
            pNumber = new PrimeNumber();
        }
        [Test]
        public void YouShouldNotBeATestingDummy()
        {
            // Dummy test
            Assert.IsFalse(false, "You are a testing dummy");

        }
        [Test]
        public void OneShouldNotBePrime()
        {
            pNumber.Number = 1;
            Assert.IsFalse(pNumber.IsPrime(),"1 is not a prime number, but in the case if it is true it becomes prime.");
        }
        [Test]
        public void EvenNumbersShouldNotBePrime()
        {
            pNumber.Number = 2;
            Assert.IsFalse(pNumber.IsPrime(),"2 is not a prime number but in the case if it is true it becomes prime.");
        } 
        [Test]
        public void ShouldFindPrimeNumbers()
        {
            pNumber.Number = 17;
            Assert.IsTrue(pNumber.IsPrime(), "17 is a prime number but in the case it isn't prime it did not become prime.");
        }

        [TestFixtureTearDown]
        public void TestTeardown()
        {
            pNumber = null;
        }
    }
}
