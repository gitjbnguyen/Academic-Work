﻿using System;


namespace FindPrimeNumbers
{
    public class PrimeNumber
    {
        // property storing a number
        public int Number { get; set; }

        // Instance method returns true, 
        // if property 'Number' stores a prime number
        public bool IsPrime()
        {
            if (Number == 2) // 'two' is a prime number
                return true;
            else if (Number == 1 || Number % 2 == 0) // 'one' and all other even number are not prime numbers
                return false;
            else
            { // check odd numbers greater than 2
                // for efficiency, stop when i is less the sqrt of Number
                int n = (int)Math.Round(Math.Sqrt(Number));
                for (int i = 3; i <= n; i += 2)
                {
                    if (Number % i == 0)
                        return false; // Number is divisible, (not a prime)
                }
                return true; // Number is not divisible, (a prime)
            }

            // return statement not necessary; it is never reached
        }

    }
}
