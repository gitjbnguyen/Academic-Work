﻿using System;
using System.Collections.Generic;

namespace FindPrimeNumbers
{
    public class Program
    {
        static void Main(string[] args)
        {
            int max = 100;
            Console.Write($"Enter a positive number less than {max}: ");
            int num = int.Parse(Console.ReadLine());

            // Create an object on the fly and use the question operator
            // to check if it is a prime and output the correct message
            Console.WriteLine(new PrimeNumber() { Number = num }.IsPrime() ?
                $"{num} is a prime number!" : $"{num} is not a prime number!");


            // Print all the prime numbers that are less than 'max'
            string strList = "[" + string.Join(", ", GetPrimeNumbers(max)) + "]";
            Console.WriteLine($"Prime numbers less than {max}:\n{strList}");

        }

        static int[] GetPrimeNumbers(int range)
        {
            List<int> primes = new List<int>();
            for (int i = 1; i < range; i++)
            {
                if (new PrimeNumber() { Number = i }.IsPrime()) primes.Add(i);
            }
            return primes.ToArray();
        }


    }
}
