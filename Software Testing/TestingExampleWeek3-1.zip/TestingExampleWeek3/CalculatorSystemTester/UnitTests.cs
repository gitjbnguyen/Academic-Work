﻿using System;
using System.Collections.Generic;
using System.Linq;
using CalculatorSystem;
using NUnit.Framework;

namespace CalculatorSystemTester
{
   [TestFixture]
    public class UnitTests
    {
        Calculator cal;

        // Test method to setup the global objects used by the
        // test units
        [TestFixtureSetUp]
        public void TestSetup()
        {
           cal = new Calculator();
        }
        // 1st test unit. Check if Add method works
       [Test]
        public void ShouldAddTwoNumbers()
        {
           // Calculator cal = new Calculator();
            // Actual result: 7 + 8 = 15
            int actualResult = 15;
            int expectedResult = cal.Add(7, 8);
            //Assert.AreEqual(expectedResult, actualResult, "error");
            //Assert.That(actualResult == expectedResult);
            Assert.That(expectedResult, Is.EqualTo(actualResult));
        }

        // 2nd Unit Test: Check if Mult method works correctly\
        [Test]
        public void ShouldMulTwoNumbers()
        {
            //Calculator cal = new Calculator();
            // Actual result: 7 * 8 = 56
            int actualResult = 56;
            int expectedResult = cal.Mul(7, 8);
            //Assert.AreEqual(expectedResult, actualResult, "error");
            //Assert.That(actualResult == expectedResult);
            Assert.That(expectedResult, Is.EqualTo(actualResult));
        }

        [Test]
        public void ShouldDivTwoNumbers()
        {
            //Calculator cal = new Calculator();
            // Actual result: 7 * 8 = 56
            double actualResult = 33.33;
            double expectedResult = Math.Round(cal.Div(100, 3), 2);
            //Assert.AreEqual(expectedResult, actualResult, "error");
            //Assert.That(actualResult == expectedResult);
            Assert.That(expectedResult, Is.EqualTo(actualResult));
        }

        [TestFixtureTearDown] 
        public void TestTearDown()
        {
            cal = null; // tells the garbage collector that
            // the object is not need; it is removed from memory
        }
    }
}
