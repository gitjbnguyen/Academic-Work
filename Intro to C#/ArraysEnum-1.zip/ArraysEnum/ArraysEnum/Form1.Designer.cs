﻿namespace ArraysEnum
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DisplayArrayAbtn = new System.Windows.Forms.Button();
            this.SwapFLbtn = new System.Windows.Forms.Button();
            this.SwapValues = new System.Windows.Forms.Button();
            this.Updatebtn = new System.Windows.Forms.Button();
            this.ParseSelectedBreedbtn = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.cboDogBreed = new System.Windows.Forms.ComboBox();
            this.IndextextBox3 = new System.Windows.Forms.TextBox();
            this.NewValuetextBox4 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // DisplayArrayAbtn
            // 
            this.DisplayArrayAbtn.Location = new System.Drawing.Point(0, 41);
            this.DisplayArrayAbtn.Name = "DisplayArrayAbtn";
            this.DisplayArrayAbtn.Size = new System.Drawing.Size(120, 23);
            this.DisplayArrayAbtn.TabIndex = 0;
            this.DisplayArrayAbtn.Text = "Display Array A";
            this.DisplayArrayAbtn.UseVisualStyleBackColor = true;
            this.DisplayArrayAbtn.Click += new System.EventHandler(this.DisplayArrayAbtn_Click);
            // 
            // SwapFLbtn
            // 
            this.SwapFLbtn.Location = new System.Drawing.Point(0, 100);
            this.SwapFLbtn.Name = "SwapFLbtn";
            this.SwapFLbtn.Size = new System.Drawing.Size(120, 23);
            this.SwapFLbtn.TabIndex = 1;
            this.SwapFLbtn.Text = "Swap first last";
            this.SwapFLbtn.UseVisualStyleBackColor = true;
            this.SwapFLbtn.Click += new System.EventHandler(this.SwapFLbtn_Click);
            // 
            // SwapValues
            // 
            this.SwapValues.Location = new System.Drawing.Point(377, 74);
            this.SwapValues.Name = "SwapValues";
            this.SwapValues.Size = new System.Drawing.Size(120, 23);
            this.SwapValues.TabIndex = 2;
            this.SwapValues.Text = "Swap Values";
            this.SwapValues.UseVisualStyleBackColor = true;
            this.SwapValues.Click += new System.EventHandler(this.SwapValues_Click);
            // 
            // Updatebtn
            // 
            this.Updatebtn.Location = new System.Drawing.Point(645, 67);
            this.Updatebtn.Name = "Updatebtn";
            this.Updatebtn.Size = new System.Drawing.Size(120, 23);
            this.Updatebtn.TabIndex = 3;
            this.Updatebtn.Text = "Update";
            this.Updatebtn.UseVisualStyleBackColor = true;
            this.Updatebtn.Click += new System.EventHandler(this.Updatebtn_Click);
            // 
            // ParseSelectedBreedbtn
            // 
            this.ParseSelectedBreedbtn.Location = new System.Drawing.Point(415, 313);
            this.ParseSelectedBreedbtn.Name = "ParseSelectedBreedbtn";
            this.ParseSelectedBreedbtn.Size = new System.Drawing.Size(139, 23);
            this.ParseSelectedBreedbtn.TabIndex = 4;
            this.ParseSelectedBreedbtn.Text = "Parse Selected Breed";
            this.ParseSelectedBreedbtn.UseVisualStyleBackColor = true;
            this.ParseSelectedBreedbtn.Click += new System.EventHandler(this.ParseSelectedBreedbtn_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(386, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(386, 38);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 6;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(167, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(139, 199);
            this.listBox1.TabIndex = 7;
            // 
            // cboDogBreed
            // 
            this.cboDogBreed.FormattingEnabled = true;
            this.cboDogBreed.Location = new System.Drawing.Point(415, 265);
            this.cboDogBreed.Name = "cboDogBreed";
            this.cboDogBreed.Size = new System.Drawing.Size(139, 21);
            this.cboDogBreed.TabIndex = 8;
            // 
            // IndextextBox3
            // 
            this.IndextextBox3.Location = new System.Drawing.Point(654, 15);
            this.IndextextBox3.Name = "IndextextBox3";
            this.IndextextBox3.Size = new System.Drawing.Size(100, 20);
            this.IndextextBox3.TabIndex = 9;
            // 
            // NewValuetextBox4
            // 
            this.NewValuetextBox4.Location = new System.Drawing.Point(654, 41);
            this.NewValuetextBox4.Name = "NewValuetextBox4";
            this.NewValuetextBox4.Size = new System.Drawing.Size(100, 20);
            this.NewValuetextBox4.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(563, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 18);
            this.label1.TabIndex = 11;
            this.label1.Text = "Enter index";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(536, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 18);
            this.label2.TabIndex = 12;
            this.label2.Text = "Enter new value";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(322, 14);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 18);
            this.label3.TabIndex = 13;
            this.label3.Text = "Index 1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(322, 40);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 18);
            this.label4.TabIndex = 14;
            this.label4.Text = "Index 2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 464);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.NewValuetextBox4);
            this.Controls.Add(this.IndextextBox3);
            this.Controls.Add(this.cboDogBreed);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.ParseSelectedBreedbtn);
            this.Controls.Add(this.Updatebtn);
            this.Controls.Add(this.SwapValues);
            this.Controls.Add(this.SwapFLbtn);
            this.Controls.Add(this.DisplayArrayAbtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button DisplayArrayAbtn;
        private System.Windows.Forms.Button SwapFLbtn;
        private System.Windows.Forms.Button SwapValues;
        private System.Windows.Forms.Button Updatebtn;
        private System.Windows.Forms.Button ParseSelectedBreedbtn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ComboBox cboDogBreed;
        private System.Windows.Forms.TextBox IndextextBox3;
        private System.Windows.Forms.TextBox NewValuetextBox4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

