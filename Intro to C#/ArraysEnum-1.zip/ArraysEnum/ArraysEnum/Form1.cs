﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*Julie Nguyen
 *4/27/2018
 *ArraysEnum.sln 
 *Description: parsing through the array to get results 
 */
namespace ArraysEnum
{
    public partial class Form1 : Form
    {
        int[] A = { 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80 };
        public enum DogBreed{
        Pitbull, Rottweiler, Dachshund, Akita, Beagle, Bulldog, Husky, Pomeranian,
        Corgi, Doberman
        
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string [] DogBreeds = Enum.GetNames(typeof(DogBreed));
            //populate the combo box with DogBreeds string array 
            cboDogBreed.Items.AddRange(DogBreeds);
            //preselection
            cboDogBreed.SelectedIndex = 0;
           
        }

        private void arrayDisplay()
        {
            listBox1.Items.Clear();
            foreach (int item in A)
            {
                listBox1.Items.Add(item);
            }
        }

        private void DisplayArrayAbtn_Click(object sender, EventArgs e)
        {
            arrayDisplay();
        }

        private void SwapFLbtn_Click(object sender, EventArgs e)
        {

            int x = A[0];
            int y = A[A.Length - 1];

            A[0] = y;
            A[A.Length - 1] = x;
            arrayDisplay();
        }

        private void SwapValues_Click(object sender, EventArgs e)
        {
            int first = int.Parse(textBox1.Text);
            int second = int.Parse(textBox2.Text);
            int index = 0;
            int index2 = 0;
            if (index >= 0 && first < A.Length)
            {
                 index = A[first];
            }
            if (index >= 0 && second < A.Length) {

                index2 = A[second];
            }
            A[first] = index2;
            A[second] = index;
            arrayDisplay();
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            int Nindex = int.Parse(IndextextBox3.Text);
            int Nvalue = int.Parse(NewValuetextBox4.Text);
            if (Nindex >= 0 &&  Nindex < A.Length)
            {
             
                A[Nindex] = Nvalue;
                arrayDisplay();
            }
        }

        private void ParseSelectedBreedbtn_Click(object sender, EventArgs e)
        {
            String dog = cboDogBreed.SelectedItem.ToString(); //item
            DogBreed breed = (DogBreed)Enum.Parse(typeof(DogBreed),dog);
            string result = $"string value: {breed.ToString()} \n" + $"int value: {(int)breed}";
            MessageBox.Show(result);
        }
    }
}
