﻿/*Julie Nguyen
 *DentalApp.zip
 *4/13/2018
 *Description: This form creates a subtotal and total for the dental patient 
 * 
 * 
 */



using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DentalApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void ComputeTotal_Click(object sender, EventArgs e)
        {
            display.Clear();
            String dentalServices = "";

            decimal cleaning = 65.00m;
            decimal cavityFilling = 200.00m;
            decimal rootCanal = 250.00m;
            decimal otherService = decimal.Parse(textBox2.Text); //other service box
            decimal price = 0.0m;
            if (CleaningBox.Checked)
            {
                price += cleaning;
                dentalServices += "Cleaning cost: $65" +"\n";
            }
            if (CavityFillBox.Checked)
            {
                price += cavityFilling;
                dentalServices += "Cavity filling cost: $200\n";
            }
            if (RootCanalBox.Checked)
            {
                price += rootCanal;
                dentalServices += "Root canal cost: $250";
            }
            if (OtherBox.Checked && otherService > 0)
            {
                price += otherService;
               dentalServices += " ";
            }
            //finding the discount
            decimal discount = 0;
            if (Holiday15.Checked)
            {
                discount += 0.15m;
            }
            else if (Special25.Checked)
            {
                discount += 0.25m;
            }
            else if (NoDiscount.Checked)
            {
                discount += 0.0m;
            }
            //computes subtotal
            decimal subTotal = price; //* (1 - discount);
            decimal total = price * (1 - discount);
            //displays in the total text box

            textBox1.Text = String.Format($"{ subTotal.ToString("c")}");
            String patientName = String.Format(nameBox.Text);
            display.AppendText( //display is a rich text box
               $"Patient name: {patientName.ToString()}" +
               $"\nDental services:{dentalServices}" + 
               $"\nother services: {otherService.ToString("c")}"+
               $"\nsubtotal: {subTotal.ToString("c")}" +
               $"\ndiscount: {discount.ToString("p")}" +
               $"\ntotal: {total.ToString("c")}");
        }
    }
}
