﻿namespace DentalApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.display = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.NoDiscount = new System.Windows.Forms.RadioButton();
            this.Special25 = new System.Windows.Forms.RadioButton();
            this.Holiday15 = new System.Windows.Forms.RadioButton();
            this.OtherBox = new System.Windows.Forms.CheckBox();
            this.RootCanalBox = new System.Windows.Forms.CheckBox();
            this.CavityFillBox = new System.Windows.Forms.CheckBox();
            this.CleaningBox = new System.Windows.Forms.CheckBox();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.ComputeTotal = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // display
            // 
            this.display.Location = new System.Drawing.Point(19, 447);
            this.display.Name = "display";
            this.display.Size = new System.Drawing.Size(331, 140);
            this.display.TabIndex = 13;
            this.display.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.NoDiscount);
            this.groupBox1.Controls.Add(this.Special25);
            this.groupBox1.Controls.Add(this.Holiday15);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(16, 263);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(296, 127);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Discounts";
            // 
            // NoDiscount
            // 
            this.NoDiscount.AutoSize = true;
            this.NoDiscount.Location = new System.Drawing.Point(16, 82);
            this.NoDiscount.Name = "NoDiscount";
            this.NoDiscount.Size = new System.Drawing.Size(178, 24);
            this.NoDiscount.TabIndex = 2;
            this.NoDiscount.TabStop = true;
            this.NoDiscount.Text = "No Discount Today";
            this.NoDiscount.UseVisualStyleBackColor = true;
            // 
            // Special25
            // 
            this.Special25.AutoSize = true;
            this.Special25.Location = new System.Drawing.Point(16, 52);
            this.Special25.Name = "Special25";
            this.Special25.Size = new System.Drawing.Size(153, 24);
            this.Special25.TabIndex = 1;
            this.Special25.TabStop = true;
            this.Special25.Text = "Special 25% off";
            this.Special25.UseVisualStyleBackColor = true;
            // 
            // Holiday15
            // 
            this.Holiday15.AutoSize = true;
            this.Holiday15.Location = new System.Drawing.Point(16, 22);
            this.Holiday15.Name = "Holiday15";
            this.Holiday15.Size = new System.Drawing.Size(153, 24);
            this.Holiday15.TabIndex = 0;
            this.Holiday15.TabStop = true;
            this.Holiday15.Text = "Holiday 15% off";
            this.Holiday15.UseVisualStyleBackColor = true;
            // 
            // OtherBox
            // 
            this.OtherBox.AutoSize = true;
            this.OtherBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OtherBox.Location = new System.Drawing.Point(7, 228);
            this.OtherBox.Name = "OtherBox";
            this.OtherBox.Size = new System.Drawing.Size(228, 29);
            this.OtherBox.TabIndex = 6;
            this.OtherBox.Text = "Other                  $";
            this.OtherBox.UseVisualStyleBackColor = true;
            // 
            // RootCanalBox
            // 
            this.RootCanalBox.AutoSize = true;
            this.RootCanalBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RootCanalBox.Location = new System.Drawing.Point(7, 193);
            this.RootCanalBox.Name = "RootCanalBox";
            this.RootCanalBox.Size = new System.Drawing.Size(305, 29);
            this.RootCanalBox.TabIndex = 5;
            this.RootCanalBox.Text = "Root Canal               $250";
            this.RootCanalBox.UseVisualStyleBackColor = true;
            // 
            // CavityFillBox
            // 
            this.CavityFillBox.AutoSize = true;
            this.CavityFillBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CavityFillBox.Location = new System.Drawing.Point(7, 158);
            this.CavityFillBox.Name = "CavityFillBox";
            this.CavityFillBox.Size = new System.Drawing.Size(304, 29);
            this.CavityFillBox.TabIndex = 4;
            this.CavityFillBox.Text = "Cavity Filling            $200";
            this.CavityFillBox.UseVisualStyleBackColor = true;
            // 
            // CleaningBox
            // 
            this.CleaningBox.AutoSize = true;
            this.CleaningBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CleaningBox.Location = new System.Drawing.Point(7, 123);
            this.CleaningBox.Name = "CleaningBox";
            this.CleaningBox.Size = new System.Drawing.Size(296, 29);
            this.CleaningBox.TabIndex = 3;
            this.CleaningBox.Text = "Cleaning                   $65";
            this.CleaningBox.UseVisualStyleBackColor = true;
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(129, 74);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(158, 20);
            this.nameBox.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Patient name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(58, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(199, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dental Payment Form";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(188, 412);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 24);
            this.label3.TabIndex = 11;
            this.label3.Text = "Total";
            // 
            // ComputeTotal
            // 
            this.ComputeTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ComputeTotal.Location = new System.Drawing.Point(16, 408);
            this.ComputeTotal.Name = "ComputeTotal";
            this.ComputeTotal.Size = new System.Drawing.Size(156, 33);
            this.ComputeTotal.TabIndex = 10;
            this.ComputeTotal.Text = "Compute Total";
            this.ComputeTotal.UseVisualStyleBackColor = true;
            this.ComputeTotal.Click += new System.EventHandler(this.ComputeTotal_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.display);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.ComputeTotal);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.OtherBox);
            this.panel1.Controls.Add(this.RootCanalBox);
            this.panel1.Controls.Add(this.CavityFillBox);
            this.panel1.Controls.Add(this.CleaningBox);
            this.panel1.Controls.Add(this.nameBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(217, 72);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(366, 603);
            this.panel1.TabIndex = 2;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(241, 235);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 15;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(250, 416);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 734);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox display;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton NoDiscount;
        private System.Windows.Forms.RadioButton Special25;
        private System.Windows.Forms.RadioButton Holiday15;
        private System.Windows.Forms.CheckBox OtherBox;
        private System.Windows.Forms.CheckBox RootCanalBox;
        private System.Windows.Forms.CheckBox CavityFillBox;
        private System.Windows.Forms.CheckBox CleaningBox;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button ComputeTotal;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
    }
}

