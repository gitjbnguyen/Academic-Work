﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Dealer.Models.ViewModels;
using Dealer.Models;

namespace Dealer.Controllers 
{
    public class CarController : Controller
    {
        private ICarRepository repository;
        public int PageSize = 4;
        public CarController(ICarRepository repo)
        {
            repository = repo;
        }
        public ViewResult List(string category, int productPage = 1)
        => View(new CarsListViewModel
        {
             Cars = repository.Cars
            .Where(p => category == null || p.Category == category)
            .OrderBy(p => p.ProductID)
            .Skip((productPage - 1) * PageSize)
            .Take(PageSize),
            PagingInfo = new PagingInfo
            {
                CurrentPage = productPage,
                ItemsPerPage = PageSize,
                TotalItems = category == null ?
                    repository.Cars.Count() :
                    repository.Cars.Where(e =>
                    e.Category == category).Count()
            },
            CurrentCategory = category
        });
    }
}
