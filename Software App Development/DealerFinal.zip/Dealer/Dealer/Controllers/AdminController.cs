﻿using Microsoft.AspNetCore.Mvc;
using Dealer.Models;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
namespace Dealer.Controllers
{
    [Authorize]
    public class AdminController : Controller
    {
        private ICarRepository repository;
        public AdminController(ICarRepository repo)
        {
            repository = repo;
        }
        public ViewResult Index() => View(repository.Cars);

        public ViewResult Edit(int productId) =>
        View(repository.Cars
        .FirstOrDefault(p => p.ProductID == productId));

        [HttpPost]
        public IActionResult Edit(Car product)
        {
            if (ModelState.IsValid)
            {
                repository.SaveProduct(product);
                TempData["message"] = $"{product.Make} {product.Model} {product.Year} has been saved";
                return RedirectToAction("Index");
            }
            else
            {
                // there is something wrong with the data values
                return View(product);
            }
        }

        public ViewResult Create() => View("Edit", new Car());
        [HttpPost]
        public IActionResult Delete(int productId)
        {
            Car deletedProduct = repository.DeleteCar(productId);
            if (deletedProduct != null)
            {
                TempData["message"] = $"{deletedProduct.Make} {deletedProduct.Model} {deletedProduct.Year} was deleted";

            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult SeedDatabase()
        {
            SeedData.EnsurePopulated(HttpContext.RequestServices);
            return RedirectToAction(nameof(Index));
        }
    }
}