﻿using Microsoft.AspNetCore.Mvc;

namespace Dealer.Controllers
{
    public class ErrorController : Controller
    {
        public ViewResult Error() => View();
    }
}
