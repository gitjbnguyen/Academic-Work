﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding;
namespace Dealer.Models
{
    public class Car
    {
        [Key]
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Please enter the car Make")]
        public string Make { get; set; }

        [Required(ErrorMessage = "Please enter the car Model")]
        public string Model { get; set; }

        [Required(ErrorMessage = "Please enter the car Year")]
        public int Year { get; set; }

        [Required(ErrorMessage = "Please enter a description for the car")]
        public string Description { get; set; }

        [Required]
        [Range(0.01, double.MaxValue,
            ErrorMessage = "Please enter a positive price")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Please specify the category")]
        public string Category { get; set; }
    }
}
