﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dealer.Models
{
    public class FakeCarRepository
    {
        public IQueryable<Car> Cars => new List<Car> {
        new Car { Make = "Honda", Model ="Accord", Year = 2002, Price = 1500  },
        new Car { Make = "Toyota", Model ="Camry", Year = 2020, Price = 25000  },
        new Car { Make = "Hyundai", Model ="Sonata", Year = 2019, Price = 250000  }
        }.AsQueryable<Car>();
    }
}
