﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
namespace Dealer.Models
{
    public class SeedData
    {
        public static void EnsurePopulated(IServiceProvider services)
        {
            ApplicationDbContext context =
            services.GetRequiredService<ApplicationDbContext>();
            //context.Database.Migrate();
            if (!context.Cars.Any())
            {
                context.Cars.AddRange(
                new Car
                {
                    Make = "Toyota",
                    Model = "Camry",
                    Year = 2018,
                    Description = "A red commuting car suitable for up to 5 people.",
                    Category = "Sedan",
                    Price = 27500
                },
                new Car
                {
                    Make = "Honda",
                    Model = "Accord",
                    Year = 2019,
                    Description = "A blue commuting car suitable for up to 5 people.",
                    Category = "Sedan",
                    Price = 28500
                }, 
                new Car
                {
                    Make = "Hyundai",
                    Model = "Sonata",
                    Year = 2018,
                    Description = "A blue commuting car suitable for up to 5 people.",
                    Category = "Sedan",
                    Price = 27450
                },
                new Car
                {
                    Make = "Toyota",
                    Model = "RAV4",
                    Year = 2018,
                    Description = "A red commuting car suitable for up to 5 people and road trips.",
                    Category = "SUV",
                    Price = 30000
                },
                new Car
                {
                    Make = "Lambourghini",
                    Model = "Aventador",
                    Year = 2020,
                    Description = "A red sports car suitable for up to 2 people.",
                    Category = "Sports",
                    Price = 250000
                },
                new Car
                {
                    Make = "Tesla",
                    Model = "Model S",
                    Year = 2020,
                    Description = "A white electric car suitable for up to 5 people.",
                    Category = "Electric",
                    Price = 27500
                });
                context.SaveChanges();
            }
        }
    }
}
