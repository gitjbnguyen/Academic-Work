﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System.Threading.Tasks;

namespace Dealer.Models
{
    public static class IdentitySeedData
    {
        private const string adminUser = "Amin";
        private const string adminPassword = "Group6CarDealer$hip";

        public static async Task EnsurePopulated(UserManager<IdentityUser>userManager)
        {
            IdentityUser user = await userManager.FindByIdAsync(adminUser);
            if (user == null)
            {
                user = new IdentityUser("Admin");
                await userManager.CreateAsync(user, adminPassword);
            }
        }
    }
}
