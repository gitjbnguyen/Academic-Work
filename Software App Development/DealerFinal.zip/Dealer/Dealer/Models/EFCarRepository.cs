﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Dealer.Models
{
    public class EFCarRepository : ICarRepository
    {
        private ApplicationDbContext context;
        public EFCarRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public IQueryable<Car> Cars => context.Cars;
        public void SaveProduct(Car car)
        {
            if (car.ProductID == 0)
            {
                context.Cars.Add(car);
            }
            else
            {
                Car dbEntry = context.Cars
                .FirstOrDefault(p => p.ProductID == car.ProductID);
                if (dbEntry != null)
                {
                    dbEntry.Make = car.Make;
                    dbEntry.Model = car.Model;
                    dbEntry.Year = car.Year;
                    dbEntry.Description = car.Description;
                    dbEntry.Price = car.Price;
                    dbEntry.Category = car.Category;
                }
            }
            context.SaveChanges();

        }

        public Car DeleteCar(int productID)
        {
            Car dbEntry = context.Cars
            .FirstOrDefault(p => p.ProductID == productID);
            if (dbEntry != null)
            {
                context.Cars.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;
        }
    }
}
