﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Midterm.Models;
using Newtonsoft.Json;

namespace Midterm.Controllers
{
    //Done by: Najib Jama
    ////done by: Julie Nguyen 
    ///Amin Sahebi
    ///Navraj Singh

    //controller 1 
    [Route("[controller]/[action]")]
    public class ReservationController : Controller 
    {
        private readonly IHostingEnvironment envirement;
        private IReservationRepository dataRepository;
        public ReservationController(IReservationRepository repo, IHostingEnvironment env)
        {
            dataRepository = repo;
            envirement = env;
        }
        //Action 1
        [Route("/")]
        [Route("/Reservations")]
        public IActionResult Index()//returns reservation form 
        {
            return View(new Reservation());
        }
        //Action 2
        [HttpPost]
        public IActionResult Submit( Reservation newReservation)  
        {
            //error check
            if (ModelState.IsValid)
            {
                //add new reservation and redirect to a thank you page 
                dataRepository.SaveReservation(newReservation); 
                return RedirectToAction(nameof(Completed));
            }
             return View(new Reservation());
        }
        //reservation completed 
        public IActionResult Completed()
        {
            return View(); // returns a view 
        }
        // ****late return .json 
        [Route("/Reservations")]
        public IActionResult Display()
        {
            return View(dataRepository.GetAllReservations());
        }

        //Returns Json
        [Route ("/Reservations2")]
        public IActionResult Display2() 
        {
            string WebsiteRoot = envirement.WebRootPath;
            string people = System.IO.File.ReadAllText(WebsiteRoot + "\\lib\\reservations.json");
            var MyJsonObject = JsonConvert.DeserializeObject(people);
            return new JsonResult(MyJsonObject);
        }
    }
}
