﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Midterm.Models;
using Newtonsoft.Json;

//Done by: Najib Jama
////done by: Julie Nguyen 
///Amin Sahebi
///Navraj Singh

namespace Midterm.Controllers
{
    [Route("[controller]/[action]")]
    public class ReservationAdminController : Controller
    {
        private IReservationRepository dataRepository;
        private readonly IHostingEnvironment envirement;
        public ReservationAdminController(IReservationRepository repo, IHostingEnvironment env)
        {
            dataRepository = repo;
            envirement = env;
        }


        //display all data for the admin 
        [Route("/Admin")]
        public IActionResult Index()
        {
            return View(dataRepository.GetAllReservations());

        }
        [Route("/Admin/Create")]
        public IActionResult Create(Reservation newReservation) 
        {
            //error check
            if (ModelState.IsValid)
            {
                //add new reservation and redirect to a thank you page 
                dataRepository.SaveReservation(newReservation);
                return RedirectToAction(nameof(Index));
            }
            return View(new Reservation());
        }
        [HttpGet]
        [Route("/Admin/Edit")]
        public IActionResult Edit(int id)
        {
            Reservation reservationToEdit = dataRepository.GetReservation(id);
            return View(reservationToEdit);
        }
        [HttpPost]
        public IActionResult Edit(Reservation res)
        {
            dataRepository.UpdateReservation(res);
            return RedirectToAction(nameof(Index));
        }
        [HttpGet]
        [Route("/Admin/Detail")]
        public IActionResult Details(int id)
        {
            return View(dataRepository.GetReservation(id));
        }
        public IActionResult Delete(int id)
        {
            dataRepository.DeleteReservation(id);
            return RedirectToAction(nameof(Index));
        }

        //Returns Simple text File Format
        [Route("/Admin/Reservation")]
        public ContentResult DisplayDataAssimpleText()
        {
            string WebsiteRoot = envirement.WebRootPath;
            string people = System.IO.File.ReadAllText(WebsiteRoot + "\\lib\\reservations.json");
            var all = dataRepository.GetAllReservations().ToString(); 
            var MyJsonObject = JsonConvert.DeserializeObject(people);
            return Content(MyJsonObject.ToString(), "text/plain", Encoding.UTF8);
        }
    }
}