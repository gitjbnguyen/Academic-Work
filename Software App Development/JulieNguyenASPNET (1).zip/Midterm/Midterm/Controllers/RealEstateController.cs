﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Midterm.Models;

namespace Midterm.Controllers
{
    //Question 3: return the different views
    [Route("[action]/[controller]")]
    public class RealEstateController : Controller
    {
        private readonly ApplicationContext _context;
        private readonly IHostingEnvironment environment;
        private IRealEstateRepository dataRepository;

        public RealEstateController(ApplicationContext context, IRealEstateRepository repo, IHostingEnvironment env)
        {
            _context = context;
            dataRepository = repo;
            environment = env;
        }

        //shows a list
        [Route("/Index/RealEstate")]
        public async Task<IActionResult> Index()
        {
            return View(await _context.RealEstate.ToListAsync());
        }

        //get the details from here
        [Route("/Details/RealEstate")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var realEstate = await _context.RealEstate
                .FirstOrDefaultAsync(m => m.ID == id);
            if (realEstate == null)
            {
                return NotFound();
            }

            return View(realEstate);
        }

        // Creating data starts here
        [Route("/Create/RealEstate")]
        public IActionResult Create()
        {
            return View();
        }

        //Create data
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Agent,Phone,Address,City,Zipcode,State,Country,Price")] RealEstate realEstate)
        {
            if (ModelState.IsValid)
            {
                _context.Add(realEstate);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(realEstate);
        }

        //editing information here from this method by referring to the ID
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var realEstate = await _context.RealEstate.FindAsync(id);
            if (realEstate == null)
            {
                return NotFound();
            }
            return View(realEstate);
        }

        //Edit information here

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Agent,Phone,Address,City,Zipcode,State,Country,Price")] RealEstate realEstate)
        {
            if (id != realEstate.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(realEstate);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RealEstateExists(realEstate.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(realEstate);
        }

        //delete information here
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var realEstate = await _context.RealEstate
                .FirstOrDefaultAsync(m => m.ID == id);
            if (realEstate == null)
            {
                return NotFound();
            }

            return View(realEstate);
        }

        // POST: RealEstates/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var realEstate = await _context.RealEstate.FindAsync(id);
            _context.RealEstate.Remove(realEstate);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool RealEstateExists(int id)
        {
            return _context.RealEstate.Any(e => e.ID == id);
        }

        //routes to pages here
        [Route("/Fake/RealEstate")]
        public IActionResult Fake()
        {
            return Json(dataRepository.GetAllRealEstates());
        }

        [Route("/Prank/RealEstate")]
        public ContentResult Prank(string message)
        {
            message = "Nothing to see here, I am a fake page!";
            return Content(message);
        }
    }
}
