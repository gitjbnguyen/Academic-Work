﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Midterm.Models
{
    //Done by: Najib Jama
    public interface IReservationRepository
    {
        Reservation GetReservation(int id);
        IEnumerable<Reservation> GetAllReservations(); 
        void SaveReservation(Reservation reservation);
        void UpdateReservation(Reservation reservation);
        void DeleteReservation(int id);
        JsonResult GetAllReservationsAsJson(); 
    }
}
