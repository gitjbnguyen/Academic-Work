﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Midterm.Models
{
    //Question 2: sending data to database
    public class Employee
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Please give us your first name. Letters only no numbers")]
        [StringLength(50)]
        [Display(Name = "First Name")]
        [RegularExpression("^[a-zA-Z ]*$")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please give us your last name. Letters only no numbers.")]
        [StringLength(50)]
        [Display(Name = "Last Name")]
        [RegularExpression("^[a-zA-Z ]*$")]
        public string LastName { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "Please enter a valid email address so we can contact you.")]
        public string Email { get; set; }

        [Required]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$",
                   ErrorMessage = "Entered phone number is not valid.")]
        [Phone]
        public string Phone { get; set; }

        [Display(Name = "Vaccinated")]
        public bool isVaccinated { get; set; }

        [Required(ErrorMessage = "Please indicate when you are applying.")]
        [Display(Name = "Hiring Date")]
        public DateTime HiringDate { get; set; }

        [Required(ErrorMessage = "Please tell us which department you are applying for.")]
        [RegularExpression("^[a-zA-Z ]*$")]
        [StringLength(25)]
        public string Department { get; set; }

        [Required(ErrorMessage = "Please tell us what role you are applying for.")]
        [RegularExpression("^[a-zA-Z ]*$")]
        [StringLength(25)]
        public string Role { get; set; }

        [Required(ErrorMessage = "Please tell us which company you are applying for.")]
        [StringLength(25)]
        public string Company { get; set; }
    }
}
