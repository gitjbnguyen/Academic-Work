﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

//Done by: Najib Jama 
namespace Midterm.Models
{
    public class ReservationRepository : IReservationRepository
    {
        private ApplicationContext _context;
        public ReservationRepository(ApplicationContext ctx)
        {
            _context = ctx;
        }

        public void UpdateReservation(Reservation reservation)
        {
            //Reservation recordInTheData =  _context.Reservations.Where(r => r.Id == reservation.Id).SingleOrDefault();
            _context.Reservations.Update(reservation);
            _context.SaveChanges();
        }

        public IEnumerable<Reservation> GetAllReservations()
        {
            return _context.Reservations;
        }

        public Reservation GetReservation(int id)
        {
            return _context.Reservations.Where(r => r.Id == id).SingleOrDefault();
        }

        public void SaveReservation(Reservation reservation)
        {
            _context.Reservations.Add(reservation);
            _context.SaveChanges();
        }

        public void DeleteReservation(int id)
        {
            Reservation reservationToDelete = _context.Reservations.Where(r => r.Id == id).Single();
            _context.Reservations.Remove(reservationToDelete);
            _context.SaveChanges();
        }

        public JsonResult GetAllReservationsAsJson()
        {
            //projection 
            var records = from entity in _context.Reservations
                          select new
                          {
                              Prop1 = entity.Id,
                              Prop2 = entity.Name,
                              prop3 = entity.NumberOfGuests,
                              prop4 = entity.Phone,

                          };
                          return new JsonResult(records);





          

           // return Json(objCollection, JsonRequestBehavior.AllowGet);
           
        }
    }
}
