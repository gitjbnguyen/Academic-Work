﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Midterm.Models
{
    //done by: Julie Nguyen
    public class Menu
    {
        public int ID { get; set; }
        [Required]
        public string DishName { get; set; }
        public string Origin { get; set; }
        public decimal Cost { get; set; }
    }
}
