﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Midterm.Models
{
    public class Pet
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter your name.")]
        [StringLength(50)]
        public string Owner { get; set; }

        [Required]
        [EmailAddress(ErrorMessage = "Please enter your email address so we can contact you.")]
        public string Email { get; set; }

        [Required]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$",
                   ErrorMessage = "Entered phone format is not valid.")]
        [Phone]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please tell us the name of your pet.")]
        [StringLength(50)]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please tell us what kind of pet you are giving over to us.")]
        public string Kind { get; set; }

        [Required(ErrorMessage = "Please tell us what breed your pet is.")]
        public string Breed { get; set; }

        [Required(ErrorMessage = "Tell us how old your pet is.")]
        [Range(0, 20)]
        public int Age { get; set; }

    }
}
