﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Midterm.Models;

namespace Midterm.Models
{
    //Done by: Najib Jama
    ////done by: Julie Nguyen 
    public class ApplicationContext:DbContext  
    {
      

        public ApplicationContext(DbContextOptions<ApplicationContext> options ):base(options)
        {
        }
        public DbSet<Reservation> Reservations { get; set; }
        public DbSet<Contact> Contacts { get; set; }
        public DbSet<Midterm.Models.Restaurant> Restaurant { get; set; }
        public DbSet<Midterm.Models.Menu> Menu { get; set; }
        public DbSet<Employee> Employee { get; set; }
        public DbSet<Pet> Pet { get; set; }
        public DbSet<RealEstate> RealEstate { get; set; }

    

    }

}
