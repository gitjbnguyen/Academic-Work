﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Midterm.Models
{
    public class RealEstateRepository : IRealEstateRepository
    {
        private ApplicationContext _context;
        public RealEstateRepository(ApplicationContext ctx)
        {
            _context = ctx;
        }

        public void UpdateRealEstate(RealEstate RealEstate)
        {
            //RealEstate recordInTheData =  _context.RealEstates.Where(r => r.Id == RealEstate.Id).SingleOrDefault();
            _context.RealEstate.Update(RealEstate);
            _context.SaveChanges();
        }

        public IEnumerable<RealEstate> GetAllRealEstates()
        {
            return _context.RealEstate;
        }

        public RealEstate GetRealEstate(int id)
        {
            return _context.RealEstate.Where(r => r.ID == id).SingleOrDefault();
        }

        public void SaveRealEstate(RealEstate RealEstate)
        {
            _context.RealEstate.Add(RealEstate);
            _context.SaveChanges();
        }

        public void DeleteRealEstate(int id)
        {
            RealEstate RealEstateToDelete = _context.RealEstate.Where(r => r.ID == id).Single();
            _context.RealEstate.Remove(RealEstateToDelete);
            _context.SaveChanges();
        }

        public JsonResult GetAllRealEstatesAsJson()
        {
            //projection 
            //var records = from entity in _context.RealEstate
            //              select new
            //              {
            //                  Prop1 = entity.ID,
            //                  Prop2 = entity.Agent,
            //                  Prop3 = entity.Phone,
            //                  Prop4 = entity.Address,
            //                  Prop5 = entity.City,
            //                  Prop6 = entity.Zipcode,
            //                  Prop7 = entity.State,
            //                  Prop8 = entity.Country,
            //                  Prop9 = entity.Price

            //              };

            var records = new List<string>();
            records.Add("123");
            return new JsonResult(records);

            // return Json(objCollection, JsonRequestBehavior.AllowGet);

        }
    }
}
