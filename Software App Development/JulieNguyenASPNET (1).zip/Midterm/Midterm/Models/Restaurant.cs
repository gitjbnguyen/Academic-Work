﻿using System.ComponentModel.DataAnnotations;
//done by: Julie Nguyen
namespace Midterm.Models
{
    public class Restaurant
    {
        public int ID { get; set; }
        [Required]
        public string Name { get; set; }
        public string Address { get; set;}
        public string Cuisine { get; set; }
    }
}
