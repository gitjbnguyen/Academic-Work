﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Midterm.Models
{
    public class RealEstate
    {
        [Key]
        public int ID { get; set; }

        [Required(ErrorMessage = "Please enter the name of the real estate agent.")]
        [StringLength(25)]
        [Display(Name = "Name of Real Estate Agent")]
        [RegularExpression("^[a-zA-Z ]*$")]
        public string Agent { get; set; }

        [Phone]
        [Required(ErrorMessage = "Please enter the real estate agent's phone number at the time of listing.")]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$",
                   ErrorMessage = "Entered phone format is not valid.")]
        public string Phone { get; set; }

        [Required]
        public string Address { get; set; }

        [Required(ErrorMessage = "Please enter the city in which this property is located.")]
        [RegularExpression("^[a-zA-Z ]*$")]
        public string City { get; set; }

        [Required]
        [Range(00000, 99999)]
        public int Zipcode { get; set; }

        [Required(ErrorMessage = "Please enter the state in which this property is located.")]
        [RegularExpression("^[a-zA-Z ]*$")]
        public string State { get; set; }

        [Required(ErrorMessage = "Please enter the country in which this property is located.")]
        [RegularExpression("^[a-zA-Z ]*$")]
        public string Country { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Please enter a positive value.")]
        [DataType(DataType.Currency)]
        public float Price { get; set; }

    }
}
