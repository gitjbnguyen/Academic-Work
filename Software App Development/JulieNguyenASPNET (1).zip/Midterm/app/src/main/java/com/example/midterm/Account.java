package com.example.midterm;
import android.os.Parcel;
import android.os.Parcelable;

//Julie Nguyen
//5/18/2021
public class Account implements Parcelable
{
    private int accountNumber;
    private double balance;
    private String bankName;
    public  String transactionType = "";

    //Account activity methods
    public void Deposit(double amount)
    {
        balance += amount;
    }

    public void Withdraw(double amount)
    {
        balance -= amount;
    }
    public String getTransactionType()
    {
        return this.transactionType;
    }

    public Account(int accountNumber, double balance, String bankName)
    {
        this.accountNumber = accountNumber;
        this.balance = balance;
        this.bankName = bankName;
    }

    //getter methods
    public int getAccountNumber()
    {
        return  accountNumber;
    }

    public double getBalance()
    {
        return balance;
    }

    public String getBankName()
    {
        return  bankName;
    }

    //Parcelling as taught in week 6
    public Account(Parcel in)
    {
        String[] data = new String[3];
        in.readStringArray(data);
        //Order needs to be the same as in writeToParcel() method
        this.accountNumber = Integer.parseInt(data[0]);
        this.balance = Float.parseFloat(data[1]);
        this.bankName = data[2];
    }

    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeStringArray(new String[] { (
                String.valueOf(this.accountNumber)),
                String.valueOf(this.balance),
                String.valueOf(this.bankName)});
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public Account createFromParcel(Parcel in)
        {
            return new Account(in);
        }

        public Account[] newArray(int size)
        {
            return new Account[size];
        }
    };

}
