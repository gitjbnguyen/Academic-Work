package com.example.midterm;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

//Julie Nguyen
//5/18/2021

public class Activity2 extends AppCompatActivity {

    //game variables:
    Player player1;
    Player player2;
    int currentBet;
    int player1tries = 0;
    int player1Score = 0;

    int player2tries = 0;
    int player2Score = 0;
    //need to point to the player upon their turn
    int activePlayerPointer = 1;

    //dice images
    ImageView dice1;
    ImageView dice2;
    ImageView dice3;

    //buttons
    Button btnScore;
    Button btnPlayer1;
    Button btnPlayer2;

    //textViews
    TextView txtPlayer1Score;
    TextView txtPlayer2Score;
    TextView txtPlayer1Pot;
    TextView txtPlayer2Pot;
    EditText txtBet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        setTitle("Activity 2 - Dice Game");

        //begin initializing the objects
        player1 = new Player();
        player2 = new Player();

        dice1 = findViewById(R.id.d1);
        dice2 = findViewById(R.id.d2);
        dice3 = findViewById(R.id.d3);

        btnScore = findViewById(R.id.btnScore);
        btnPlayer1 = findViewById(R.id.btnPlayer1);
        btnPlayer2 = findViewById(R.id.btnPlayer2);

        //scores and pots
        txtPlayer1Score = findViewById(R.id.txtPlayer1Score);
        txtPlayer2Score = findViewById(R.id.txtPlayer2Score);
        txtPlayer1Pot = findViewById(R.id.txtPlayer1Pot);
        txtPlayer2Pot = findViewById(R.id.txtPlayer2Pot);

        txtBet = findViewById(R.id.txtBet);

        currentBet = Integer.parseInt(txtBet.getText().toString());

        //disable player 2 and their button
        btnPlayer2 = findViewById(R.id.btnPlayer2);
        btnPlayer2.setEnabled(false);
        btnScore.setEnabled(false);
    }

    public void DisablePlayer1()
    {
        btnPlayer1.setEnabled(false);
        btnPlayer2.setEnabled(true);
    }

    public void DisablePlayer2()
    {
        btnPlayer2.setEnabled(false);
        btnPlayer1.setEnabled(true);
    }

    public void DiceRollViews(int DiceRolls, ImageView i)
    {
        switch (DiceRolls)
        {
            case 1:
                i.setImageResource(R.drawable.die1);
                break;
            case 2:
                i.setImageResource(R.drawable.die2);
                break;
            case 3:
                i.setImageResource(R.drawable.die3);
                break;
            case 4:
                i.setImageResource(R.drawable.die4);
                break;
            case 5:
                i.setImageResource(R.drawable.die5);
                break;
            default:
                i.setImageResource(R.drawable.die6);
        }
    }

    public void UpdatePoints()
    {
        player1.updatePoints(player1Score);
        player2.updatePoints(player2Score);
    }

    //update the pots on the conditions of winning or losing
    public void UpdatePot(Player victor, Player loser, boolean draw)
    {
        if(!draw)
        {
            victor.updatePot(currentBet);
            loser.updatePot(-currentBet);
        }
    }

    public void UpdateStats()
    {
        txtPlayer1Score.setText(Integer.toString((int)player1.getPoints()));
        txtPlayer1Pot.setText(String.valueOf(player1.getPot()));

        txtPlayer2Score.setText(Integer.toString((int)player2.getPoints()));
        txtPlayer2Pot.setText(String.valueOf(player2.getPot()));
    }

    public void ScoreRecord(View view)
    {
        int pointToNextTurn;
        if (activePlayerPointer == 1) {
            player1tries = 3;
            pointToNextTurn = 2;
        }
        else {
            pointToNextTurn = 1;
            player2tries = 3;
        }
        //call the switch player method here
        SwitchNextPlayer(pointToNextTurn);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void Player1Start(View view)
    {
        int nextPlayerTurn = 2; //go to player 2
        int first = Player.ThreadRandomNumberGenerator();
        int second = Player.ThreadRandomNumberGenerator();
        int third = Player.ThreadRandomNumberGenerator();
        int outcome = first + second + third;

        //update the image view here
        DiceRollViews(first, dice1);
        DiceRollViews(second, dice2);
        DiceRollViews(third, dice3);
        player1Score = outcome;
        player1tries += 1;

        //should the player run out of tries, switch to player 2
        if(player1tries == 3)
        {
            //switch player method called here
            SwitchNextPlayer(nextPlayerTurn);
        }

        //reactivate the score button
        btnScore.setEnabled(true);

    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void Player2Start(View view)
    {
        int nextPlayerTurn = 1; //go to player 1
        int first = Player.ThreadRandomNumberGenerator();
        int second = Player.ThreadRandomNumberGenerator();
        int third = Player.ThreadRandomNumberGenerator();
        int outcome = first + second + third;

        //update the image view here
        DiceRollViews(first, dice1);
        DiceRollViews(second, dice2);
        DiceRollViews(third, dice3);
        player2Score = outcome;
        player2tries += 1;

        //should the player run out of tries, switch to player 1
        if(player2tries == 3)
        {
            //switch player method called here
            SwitchNextPlayer(nextPlayerTurn);
        }
        //reactivate the score button to allow gameplay
        btnScore.setEnabled(true);
    }

    //check if the round is over
    public boolean IsRoundOver()
    {
        return player1tries == 3 && player2tries == 3;
    }

    //if round is done, who is the winner?
    public int WinnerOfRound()
    {
        if(player1Score > player2Score)
            return 1; //player 1
        else if (player2Score > player1Score)
            return 2; //player 2
        return -1; //tied
    }

    //game is done
    public boolean IsGameOver()
    {
        return player1.getPoints() >= 100 || player2.getPoints() >= 100;
    }

    public int WinnerOfGame()
    {
        if(player1.getPoints() > player2.getPoints())
            return 1; //player 1 is the victor
        else if (player2.getPoints() > player1.getPoints())
        {
            return 2;
        }
        return -1;
    }

    public void ResettingRound(int NextPlayerTurn)
    {
        player1tries = 0;
        player1Score = 0;

        player2tries = 0;
        player2Score = 0;
        if (NextPlayerTurn == 1)
        {
            btnPlayer1.setEnabled(true);
            btnPlayer2.setEnabled(false);
        }
        else if (NextPlayerTurn == 2)
        {
            btnPlayer1.setEnabled(false);
            btnPlayer2.setEnabled(true);
        }

        activePlayerPointer = NextPlayerTurn;
    }

    public void ResetAll(int newPlayer)
    {
        player1 = new Player();
        player2 = new Player();
        ResettingRound(newPlayer);
    }

    public void SwitchNextPlayer(int nextPlayerTurn)
    {
        if(!IsRoundOver() && !IsGameOver())
        {
            switch(activePlayerPointer)
            {
                case 1:
                    //deactivate player 1
                    DisablePlayer1();
                    break;
                case 2:
                    //deactivate player 2
                    DisablePlayer2();
                    break;
            }
            activePlayerPointer = nextPlayerTurn;
            return;
        }
        if (IsRoundOver() && !IsGameOver())
        {
            boolean draw = false;
            switch (WinnerOfRound())
            {
                case 1:
                    UpdatePot(player1, player2, draw);
                    break;
                case 2:
                    UpdatePot(player2, player1, draw);
                    break;
                case -1:
                    draw = true;
                    UpdatePot(player2, player1, draw);
                    break;
            }
            //update players score
            UpdatePoints();

            //display winner of the round
            DisplayRoundVictorToast(WinnerOfRound());

            //at this point just reset the round
            ResettingRound(nextPlayerTurn);

            //update players stats
            UpdateStats();

            return;
        }

        if(IsGameOver())
        {
            boolean draw = false;
            UpdatePoints();
            switch(WinnerOfGame())
            {
                case 1:
                    UpdatePot(player1,player2,draw);
                    break;
                case 2:
                    UpdatePot(player2,player1,draw);
                    break;
                case -1:
                    draw = true;
                    UpdatePot(player2,player1,draw);
                    break;
            }

            DisplayGameVictorToast(WinnerOfGame());
            ResetAll(nextPlayerTurn);
            UpdateStats();
        }

    }

    //toasts have a delay, play the game slowly or else the messages will not match with the timing

    public void DisplayRoundVictorToast(int victor)
    {
        Context context = getApplicationContext();
        int duration = Toast.LENGTH_SHORT;
        CharSequence text;
        switch (victor)
        {
            case 1:
                text = "Player 1 is the winner! Player 2 loses!";
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                break;
            case 2:
                text = "Player 2 is the winner! Player 1 loses!";
                toast = Toast.makeText(context, text, duration);
                toast.show();
                break;
            default:
                text = "Both players make a draw this round!";
                toast = Toast.makeText(context,text,duration);
                toast.show();
                break;
        }
    }

    public void DisplayGameVictorToast(int victor)
    {
        Context context = getApplicationContext();
        int duration = Toast.LENGTH_SHORT;
        CharSequence text;
        switch (victor)
        {
            case 1:
                text = "Player 1 is the champion! Player 2 lost!";
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
                break;
            case 2:
                text = "Player 2 is the champion! Player 1 lost!";
                toast = Toast.makeText(context, text, duration);
                toast.show();
                break;
            default:
                text = "Both players make a draw this game!";
                toast = Toast.makeText(context,text,duration);
                toast.show();
                break;
        }
    }
}