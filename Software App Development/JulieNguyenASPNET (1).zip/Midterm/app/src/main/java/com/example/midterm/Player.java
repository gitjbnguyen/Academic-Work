package com.example.midterm;
import android.os.Build;
import androidx.annotation.RequiresApi;
import java.util.concurrent.ThreadLocalRandom;

//Julie Nguyen
//5/18/2021
public class Player {
private int points = 0;
private int pot = 0;

    public Player()
    {
        pot = 50;
        points = 0;
    }

    public void updatePoints(int score)
    {
        points += score;
    }

    public void updatePot(int newPot)
    {
            pot += newPot;
    }

    public int getPoints()
    {
        return points;
    }

    public int getPot()
    {
        return pot;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static int ThreadRandomNumberGenerator()
    {
        //thread will always give random number, it won't give the same repeating values unlike Random() object
        int RNG = ThreadLocalRandom.current().nextInt(1,6+1);
        return RNG;
    }

}
