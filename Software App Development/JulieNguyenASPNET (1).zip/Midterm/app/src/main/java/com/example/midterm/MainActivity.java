package com.example.midterm;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Random;

//Julie Nguyen
//5/18/2021
public class MainActivity extends AppCompatActivity {
    Button button;
    EditText editText;
   public static Account acc;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Midterm Exam");
        Intent intent = getIntent();

        if(intent.hasExtra("A"))
        {
            Bundle info = getIntent().getExtras();
            acc = (Account) info.getParcelable("A");
            editText = findViewById(R.id.txtDisplay);
            editText.setText(
                   info.getCharSequence("info") +
                    "\n Bank Name: " + acc.getBankName() + " " +
                    "\n Account Number: " + String.valueOf(acc.getAccountNumber()) + " " +
                    "\n Balance: $" + acc.getBalance() +
                            "\n Transaction: "
            );
        } else {
            editText = findViewById(R.id.txtDisplay);
            editText.setText("no account object found yet.");
        }

    }

    public void DiceGame(View view)
    {
        Intent intent = new Intent(this, Activity2.class);
        startActivity(intent);
    }

    public void Bank(View view)
    {
        BankAccount();
    }

    public void BankAccount()
    {
        //initialize
        Intent intent = new Intent(this, Activity3.class);
        Random rand = new Random();
        int number = rand.nextInt(9999);
        intent.putExtra("A", new Account(number, 700, "BECU"));
        startActivity(intent);
    }
}