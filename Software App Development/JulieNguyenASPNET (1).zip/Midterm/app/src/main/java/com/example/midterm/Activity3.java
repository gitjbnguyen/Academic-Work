package com.example.midterm;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.icu.util.Currency;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.Locale;

//Julie Nguyen
//5/18/2021
public class Activity3 extends AppCompatActivity {

    public TextView  txtAmount;
    public TextView txtAccountView;
    public Button btnWithdraw;
    public Button btnDeposit;
    public Account acc;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
        setTitle("Activity 3 - Bank Account");

        //get ui elements
        txtAmount = findViewById(R.id.txtAmount);
        txtAccountView = findViewById(R.id.txtAccountView);

        Bundle info = getIntent().getExtras();
        acc = (Account) info.getParcelable("A");
        String displayInfo =
                "Account #:" + acc.getAccountNumber() +
                        " Balance: $" + acc.getBalance() +
                        " Bank Name: " + acc.getBankName();
        txtAccountView.setText(displayInfo);
    }

    public void Deposit(View view)
    {
        double amount = 0.00d;
        amount = Double.parseDouble(txtAmount.getText().toString());
        acc.Deposit(amount);
        //SEND DATA BACK
        String info = "Deposited $" + String.valueOf(amount);
        returnData(info);
    }

    public void Withdraw(View view)
    {
        double amount = 0.00f;
        amount = Double.parseDouble(txtAmount.getText().toString());
        acc.Withdraw(amount);
        String info = "Withdrew $" + String.valueOf(amount);
        returnData(info);
    }

    public void returnData(String info)
    {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("A",acc);
        intent.putExtra("info",info);
        startActivity(intent);
    }
}