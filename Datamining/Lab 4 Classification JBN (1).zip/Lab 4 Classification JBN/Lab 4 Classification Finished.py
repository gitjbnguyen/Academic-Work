
# coding: utf-8

# In[7]:


import pandas as pd
import numpy as np

df = pd.read_csv("Absenteeism.csv")
#df.apply(lambda s: pd.to_numeric(s, errors='coerce').notnull().all())
df.drop('ID', inplace=True, axis=1)
df.drop('Work load Average/day ', inplace=True, axis=1)
#df.head()

df.to_csv("Absenteeism v2.csv")


# In[36]:


import pylab as pl
from sklearn.neighbors import KNeighborsClassifier
get_ipython().run_line_magic('matplotlib', 'inline')

df = pd.read_csv('Absenteeism v2.csv')
list(df.columns.values)

absent = df[df.columns[1:]]
list(absent.columns.values)

test_idx = np.random.uniform(0, 1, len(absent)) <= .333
train = absent[test_idx == True]
test = absent[test_idx == False]

train.head()

# # CLASSIFICATION
# ## Specify features used to predict

features = [ 
 'Reason for absence',
 'Month of absence',
 'Day of the week',
 'Seasons',
 'Transportation expense',
 'Distance from Residence to Work',
 'Service time',
 'Age',
 'Hit target',
 'Disciplinary failure',
 'Education',
 'Son',
 'Social drinker',
 'Social smoker',
 'Pet',
 'Weight',
 'Height',
 'Body mass index',
 'Absenteeism time in hours' ]


# ## Chose n & conduct knn classification


n = 8  # Neighbors

results = []

clf = KNeighborsClassifier(n_neighbors = n)
clf.fit(train[features], train['Absenteeism time in hours'])
preds = clf.predict(test[features])
accuracy = np.where(preds == test['Absenteeism time in hours'], 1, 0).sum() / float(len(test))*100


print ("Neighbors: %d, Accuracy: %2d%%" % (n, round(accuracy, 2)))


# In[5]:




