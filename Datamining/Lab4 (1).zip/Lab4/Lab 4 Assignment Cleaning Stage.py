
# coding: utf-8

# In[101]:


import pandas as pd
import numpy as np

data = pd.read_csv("Lab4.csv")

data = data.replace(' ', np.nan)
data.dropna(subset=['DOMAIN'], inplace = True)
data.dropna(subset=['AGE'], inplace = True)
data.dropna(subset=['GENDER'], inplace = True)
data.dropna(subset=['WEALTH1'], inplace = True)
data.dropna(subset=['HIT'], inplace = True)
data.drop('SOLP3', axis=1, inplace=True)
data.dropna(subset=['WEALTH2'], inplace = True)
data.dropna(subset=['GEOCODE'], inplace = True)
data.dropna(subset=['PEPSTRFL'], inplace = True)
data.dropna(subset=['RFA_2'], inplace = True)
data.dropna(subset=['RFA_3'], inplace = True)
data.dropna(subset=['CARDPROM'], inplace = True)
data.dropna(subset=['NUMPROM'], inplace = True)
data.dropna(subset=['CARDPM12'], inplace = True)
data.dropna(subset=['NUMPRM12'], inplace = True)
data.dropna(subset=['RAMNTALL'], inplace = True)
data.dropna(subset=['NGIFTALL'], inplace = True)
data.dropna(subset=['CARDGIFT'], inplace = True)
data.dropna(subset=['MINRAMNT'], inplace = True)
data.dropna(subset=['MINRDATE'], inplace = True)
data.dropna(subset=['MAXRAMNT'], inplace = True)
data.dropna(subset=['MAXRDATE'], inplace = True)
data.dropna(subset=['LASTGIFT'], inplace = True)
data.dropna(subset=['LASTDATE'], inplace = True)
data.dropna(subset=['FISTDATE'], inplace = True)
data.dropna(subset=['NEXTDATE'], inplace = True)
data.dropna(subset=['TIMELAG'], inplace = True)
data.dropna(subset=['AVGGIFT'], inplace = True)
data.dropna(subset=['CONTROLN'], inplace = True)
data.dropna(subset=['TARGET_B'], inplace = True)
data.dropna(subset=['TARGET_D'], inplace = True)
data.dropna(subset=['RFA_2F'], inplace = True)
data.dropna(subset=['RFA_2A'], inplace = True)
data.dropna(subset=['MDMAUD_R'], inplace = True)
data.drop('MDMAUD_F', axis=1, inplace=True)
data.dropna(subset=['MDMAUD_A'], inplace = True)
data.dropna(subset=['CLUSTER2'], inplace = True)
data.dropna(subset=['GEOCODE2'], inplace = True)
data.dropna(subset=['rownum'], inplace = True)
data.dropna(subset=['AGE_imputerand'], inplace = True)
data.dropna(subset=['AGE_modelimpute'], inplace = True)
print(data)
data.to_csv("Lab 4 CLEANED.csv")

