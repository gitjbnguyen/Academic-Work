# LOAD DATA ################################################

# Read CSV
states <- read.csv("C:/Users/julie/OneDrive/Documents/Lab4/Lab 4 CLEANED.csv", header = T)
colnames(states)

systems <- read.table("C:/Users/julie/OneDrive/Documents/Lab4/Lab 4 CLEANED.csv", 
                      header=TRUE, sep=",", row.names=NULL)

# Save numerical data only
st <- states[, 3:27]
row.names(st) <- states[, 2]
colnames(st)

# Sports search data only
sports <- st[, 8:11]
head(sports)

# CLUSTERING ###############################################

# Create distance matrix
d <- dist(st)

# Hierarchical clustering
c <- hclust(d)
c # Info on clustering

# Plot dendrogram of clusters
plot(c, main = "Cluster with All Searches and Personality")

# Or nest commands in one line (for age data)
plot(hclust(dist(sports)), main = "Ages")

# CLEAN UP #################################################

# Clear workspace
rm(list = ls()) 

# Clear plots
dev.off()

# Clear console
cat("\014")  # ctrl+L

