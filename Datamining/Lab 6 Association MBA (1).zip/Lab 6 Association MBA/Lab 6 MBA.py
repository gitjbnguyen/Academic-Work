
# coding: utf-8

# In[1]:


import apriori


# In[2]:


item_supports, rules = apriori.run_apriori("basket_analysis.csv", min_confidence=0.05)


# In[3]:


for items, support in item_supports[: 5]:
    print("{0} - {1:.2f}".format(", ".join(items), support))


# In[4]:


for items, rule in rules[: 5]:
    print("{0} => {1} - {2:.2f}".format(", ".join(items[0]), ", ".join(items[1]), rule))

