# DM_06_03.R

# INSTALL AND LOAD PACKAGES ################################

pacman::p_load(arules, arulesViz) 

# DATA #####################################################

## Read transactional data from arules package
# Import the data
d = read.csv("C:/Users/julie/Downloads/basket_analysis.csv")
str(d)      # Structure of data
summary(d)  # Includes 5 most frequent items

# RULES ####################################################

# Set minimum support (minSup) to .001
# Set minimum confidence (minConf) to .75

f1 <- mean(d$Butter)
f2 <- median(d$Butter)
f3 <- sd(d$Butter)



d$Bread <- factor(d$Bread, labels=c(1, 2))
pairs(d)

plot(d$Bread ~ d$Butter)
plot(d$Bread ~ d$Butter, xlab="Bread", ylab="Butter")
m <- lm(d$Bread~d$Butter)
print(m)
print(f1)
print(f2)
print(f3)
abline(m)
abline(mean(d$Butter), 0, lty=2)

discretize(x, method = "frequency", breaks = 3, 
           labels = NULL, include.lowest = TRUE, right = FALSE, dig.lab = 3,
           ordered_result = FALSE, infinity = FALSE, onlycuts = FALSE, 
           categories, ...)

discretizeDF(df, methods = NULL, default = NULL)

hist(d$Bread[d$Butter == TRUE],breaks = 50)
dev.new()
hist(d$Bread[d$Butter == FALSE],breaks = 50)
dev.new()
#hist(d$year, breaks = 50)
#dev.new()
plot(d$Bread, d$Butter)

# CLEAN UP #################################################

# Clear workspace
rm(list = ls()) 

# Clear packages
pacman::p_unload(arules, arulesViz)

# Clear plots
dev.off()

# Clear console
cat("\014")  # ctrl+L

