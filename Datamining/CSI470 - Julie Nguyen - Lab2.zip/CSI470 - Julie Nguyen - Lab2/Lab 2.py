
# coding: utf-8

# In[9]:


import pandas as pd
#rename the columns in notepad++ or excel
#print the data to show preview
data = pd.read_csv("What Did you do Last Night_ (Responses).csv")
data = data.drop([2])
#print(data)
#replace the snowman
data = data.replace('☃', 'Cooking')
#print(data)
#replace the minutes
data = data.replace('15 minutes', '0.25')
#print(data)
#correctly replace the value of hours
data = data.replace('2 hours', '2')
print(data)

