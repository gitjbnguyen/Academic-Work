﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimedSorts
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        public Form1()
        {
            InitializeComponent();
        }
        private void Display(int[] array)
        {
            
            foreach (int x in array)
            {
                richTextBox1.AppendText(x + " ");
            }
            richTextBox1.AppendText("\n\n");
        }
        private void Merge(int[] array, int first, int mid, int last)
        {
            //array1 is defined from first to mid
            //array2 is defined from mid+1 to last
            int i = first;
            int j = mid + 1;
            int k = 0;

            //To Do: complete the code
            //rewrite the algorithm code in MergeTwoSortedSubArrays to fit
            //the Merge method as defined

            //need a temp array
            int[] temp = new int[last - first + 1];

            while (i <= mid && j <= last)
            {
                if (array[i] < array[j])
                {
                    temp[k] = array[i];
                    i++;
                    k++;
                }
                else
                {
                    temp[k] = array[j];
                    j++;
                    k++;
                }
            }
            //manage the leftover
            //only one of the while statement will run, whichever has some leftover
            while (i <= mid)
            {
                temp[k] = array[i];
                i++;
                k++;
            }

            //or 
            while (j <= last)
            {
                temp[k] = array[j];
                j++;
                k++;
            }
            //after merging all the values
            //need to copy the temp back into the array
            //let i be the index in the array
            //and j be the index in the temp
            for (i = first, j = 0; j < temp.Length; i++, j++)
            {
                array[i] = temp[j];
            }
        }
        //define the MergeSort method to break down an array into multiple subarrays of
        //length:1
        private void MergeSort(int[] array, int first, int last)
        {
            //if (first >= last)
            //    return;
            //divide the array into 2 parts [first,mid]  [mid+1, last]
            if (first < last)
            {
                int mid = (first + last) / 2;
                MergeSort(array, first, mid);
                MergeSort(array, mid + 1, last);
                Merge(array, first, mid, last);
            }
        }
        private void Swap(int[] array, int i, int j)
        {
            int temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }
        private int Partition(int[] array, int first, int last)
        {
            /*
             the partition algorithm takes an array
             chooses a pivot (usually the first element array[first]
             
             defines an index up that starts at first and move
             upwards stopping at values higher than pivot
             
             defines an index down that starts at last and move
             downwards stopping at values smaller or equal to pivot

             swap the values at up and down

             continue the process until the up and down cross each other
             outside the loop do a last swap between the pivot and
             the value at down index

             return the final index of the pivot
             */
            int up = first;
            int down = last;
            int pivot = array[first];

            while (up < down) //while the two have not crossed
            {
                //move the up index to the next larger value
                while (up <= last && array[up] <= pivot)
                    up++;

                //move the down index to the next smaller value
                while (down >= first && array[down] > pivot)
                    down--;

                //swap, but make sure they have not crossed
                if (up < down)
                    Swap(array, up, down);
            }
            //at this point the up and down have crossed each other
            //do a last swap between pivot (at first) and the value
            //at down
            Swap(array, first, down);
            //return the current index of the pivot
            return down;
        }
        private void QuickSort(int[] array, int first, int last)
        {
            if (first >= last)
                return;

            int pivotIndex = Partition(array, first, last);
            //repeat partitioning the left part of the pivot and 
            QuickSort(array, first, pivotIndex - 1);
            //the right part of the pivot
            QuickSort(array, pivotIndex + 1, last);
        }
        //Insertion sort
        private void InsertionSortIterative(int[] array)
        {
            //the concept of insertion sort is to divide the array into 2 parts
            //the left: initially containing a single element (first element at index 0)
            //the right part: initially starts at index 1 containing the rest 
            //of the elements

            //the left part is considered sorted
            //the algorithm is to pick each element from the right part and
            //insert it into the left part at its sorted position
            int n = array.Length;
            for (int i = 1; i < n; i++) //1 + n + n
            {
                //set j to i - 1
                //j is an index that marches backwards looking for the
                //insertion point j is the index that marches across the
                //sorted left part deciding where to insert the new element
                int temp = array[i]; //save the element to insert in a temp variable //n
                int j = i - 1; //initialize j to the end of the left part //n

                while (j >= 0 && temp < array[j]) //n  n^2 n^2
                {
                    //copy the value at j to j+1 that is move the element at
                    //j over (one hop) 
                    array[j + 1] = array[j]; //n^2
                    //march j towards the start of the left part
                    j--; //n^2
                }
                //now insert the temp element into j+1
                array[j + 1] = temp; //n
            }
            //write time efficiency T(n) = 4n^2 + 5n + 1
            //convert that to Big O notation =  O(n^2) quadratic
        }
        //using recursion to compare against iterative
        private void InsertionSortRecursive(int [] array, int n)
        {
            //n refers to array.length
            //base condition
            if (n <= 1)
                return;
            // Sort first n-1 elements 
            InsertionSortRecursive(array, n - 1);

            // inserting the last element at  
            // its correct position 
            // in sorted array.
            //array index at array.length-1
            int last = array[n - 1]; //swapping
            //second to last
            int j = n - 2;

            
            while (j >= 0 && array[j] > last)
            {
                //copy the value at j to j+1 that is moving the element at j over one position
                array[j + 1] = array[j];
                //march j towards the start of the left part
                j--;
            }
            //if you remove this there will be duplicates
            array[j + 1] = last;
        }
        private void btnTimer_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            Stopwatch swms = new Stopwatch(); //merge sort
            Stopwatch swqs = new Stopwatch(); //quick sort
            Stopwatch swis = new Stopwatch(); //insertion sort
            Stopwatch swisi = new Stopwatch();
            //read the array size from textbox
            int size = int.Parse(txtArray.Text);
            int[] array = new int[size];
            int[] array2 = new int[size];
            int[] array3 = new int[size];
            int[] array4 = new int[size];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = rand.Next(0,1000);
                array2[i] = rand.Next(0, 1000);
                array3[i] = rand.Next(0, 1000);
                array4[i] = rand.Next(0, 1000);

            }
            //display before sorting
            //richTextBox1.AppendText("before\n");
            //Display(array);
            //Display(array2);
            //Display(array3);
            //Display(array4);

            //start swms
            swms.Start();
            //run merge sort
            MergeSort(array,0,array.Length-1);
            //MergeSort(array2, 0, array2.Length - 1);
            //MergeSort(array3, 0, array3.Length - 1);
            //stop timer
            swms.Stop();
            //-------------

            //start swqs
            swqs.Start();
            //run quick sort
            QuickSort(array2,0,array2.Length-1);
            //QuickSort(array2, 0, array2.Length - 1);
            //QuickSort(array3, 0, array3.Length - 1);
            //stop timer
            swqs.Stop();
            //-------------

            //start swis
            swis.Start();
            //run insertion sort
            InsertionSortRecursive(array3, array3.Length);
            //InsertionSortRecursive(array2, array2.Length);
            //stop timers
            swis.Stop();
            //---------------

            //start swisi
            swisi.Start();

            //run insertion iterative
            InsertionSortIterative(array4);

            //stop timer
            swisi.Stop();

            //display after sorting
            //richTextBox1.AppendText("\nAfter sorting:\n");
            //Display(array);
            //Display(array2);
            //Display(array3);
            //Display(array4);
            //display the time here
            richTextBox1.AppendText($"\n\n Merge sort elapse time: {swms.Elapsed} \n" +
                    $"Quick sort elapsed time: {swqs.Elapsed} \n" +
                    $"Insertion sort (recursive) elapsed time: {swis.Elapsed} \n" + 
                    $"Insertion sort (iterative) elapsed time: {swisi.Elapsed}");
        }
    }
}
/*
 * 
 Comparing the InsertionSort, MergeSort and the QuickSort

Timing the InsertionSort, MergeSort and the QuickSort  using the StopWatch

Your code should allow you to decide on the size of the array
once that is done, your code is to create and initialize three arrays, with the given size, with random values.

Then it should run the insertionsort  under a stopwatch

the mergesort under a stopwatch

and run the quicksort under a stopwatch

Display the time each has taken

To test it start with small values of n (like 10, 15, 20,…) where insertion sort should show better time

(be careful with running insertion sort with very high values of n (size) as it may take many seconds

Read on Hash functions and hashtables
 * 
 */
