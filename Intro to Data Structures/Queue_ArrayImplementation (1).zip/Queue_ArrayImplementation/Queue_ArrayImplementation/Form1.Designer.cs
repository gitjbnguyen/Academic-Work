﻿namespace Queue_ArrayImplementation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnDisplayQueue = new System.Windows.Forms.Button();
            this.btnDequeue = new System.Windows.Forms.Button();
            this.btnMerge = new System.Windows.Forms.Button();
            this.btnMergeSort = new System.Windows.Forms.Button();
            this.btnGetDuplicates = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(87, 44);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(122, 225);
            this.listBox1.TabIndex = 0;
            // 
            // btnDisplayQueue
            // 
            this.btnDisplayQueue.Location = new System.Drawing.Point(87, 276);
            this.btnDisplayQueue.Name = "btnDisplayQueue";
            this.btnDisplayQueue.Size = new System.Drawing.Size(122, 23);
            this.btnDisplayQueue.TabIndex = 1;
            this.btnDisplayQueue.Text = "Display/ Enqueue";
            this.btnDisplayQueue.UseVisualStyleBackColor = true;
            this.btnDisplayQueue.Click += new System.EventHandler(this.btnDisplayQueue_Click);
            // 
            // btnDequeue
            // 
            this.btnDequeue.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDequeue.Location = new System.Drawing.Point(87, 305);
            this.btnDequeue.Name = "btnDequeue";
            this.btnDequeue.Size = new System.Drawing.Size(120, 32);
            this.btnDequeue.TabIndex = 4;
            this.btnDequeue.Text = "Test Dequeue";
            this.btnDequeue.UseVisualStyleBackColor = true;
            this.btnDequeue.Click += new System.EventHandler(this.btnDequeue_Click);
            // 
            // btnMerge
            // 
            this.btnMerge.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMerge.Location = new System.Drawing.Point(87, 343);
            this.btnMerge.Name = "btnMerge";
            this.btnMerge.Size = new System.Drawing.Size(120, 32);
            this.btnMerge.TabIndex = 5;
            this.btnMerge.Text = "Test Merge";
            this.btnMerge.UseVisualStyleBackColor = true;
            this.btnMerge.Click += new System.EventHandler(this.btnMerge_Click);
            // 
            // btnMergeSort
            // 
            this.btnMergeSort.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMergeSort.Location = new System.Drawing.Point(65, 381);
            this.btnMergeSort.Name = "btnMergeSort";
            this.btnMergeSort.Size = new System.Drawing.Size(162, 32);
            this.btnMergeSort.TabIndex = 6;
            this.btnMergeSort.Text = "Test MergeSort";
            this.btnMergeSort.UseVisualStyleBackColor = true;
            this.btnMergeSort.Click += new System.EventHandler(this.btnMergeSort_Click);
            // 
            // btnGetDuplicates
            // 
            this.btnGetDuplicates.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetDuplicates.Location = new System.Drawing.Point(65, 419);
            this.btnGetDuplicates.Name = "btnGetDuplicates";
            this.btnGetDuplicates.Size = new System.Drawing.Size(162, 32);
            this.btnGetDuplicates.TabIndex = 7;
            this.btnGetDuplicates.Text = "Test getDuplicates";
            this.btnGetDuplicates.UseVisualStyleBackColor = true;
            this.btnGetDuplicates.Click += new System.EventHandler(this.btnGetDuplicates_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 539);
            this.Controls.Add(this.btnGetDuplicates);
            this.Controls.Add(this.btnMergeSort);
            this.Controls.Add(this.btnMerge);
            this.Controls.Add(this.btnDequeue);
            this.Controls.Add(this.btnDisplayQueue);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnDisplayQueue;
        private System.Windows.Forms.Button btnDequeue;
        private System.Windows.Forms.Button btnMerge;
        private System.Windows.Forms.Button btnMergeSort;
        private System.Windows.Forms.Button btnGetDuplicates;
    }
}

