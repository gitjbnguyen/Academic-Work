﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Queue_ArrayImplementation
{
    public class MyQueue
    {
        //array implementation: means that this queue is built using an iternal array
        private object[] array;
        private int head; //index that points to the first item in the queue (front of the queue)
        private int tail; ///index that points to the last item in the queue (back of the queue)
        int count;

        public MyQueue()
        {
            //default capacity of 4
            array = new object[4];
            head = tail = -1; //queue is empty
            count = 0;
        }
        public MyQueue(int capacity)
        {
            array = new object[capacity];
            head = tail = -1; //queue is empty
            count = 0;
        }
        public MyQueue(ICollection collection)
        {
            //use the foreach to sequence through the collection
            //and Enqueue every item to this queue
        }

        //property
        public int Count { get { return count; } }

        //methods
        public void Enqueue(object data)
        {
            //Adds the data to the back of the Queue.
            if (count == 0)
            {
                head = tail = 0;
                array[tail] = data;
                count++;
            }
            else if (count < array.Length)
            {
                //still some space available
                //increment the tail with wrap aroung
                tail = (tail + 1) % array.Length;
                //add the new data
                array[tail] = data;
                count++;
            }
            else //full --> create a new temp array twice as big. copy array to temp
            {            //make the temp be the array

                object[] temp = new object[2 * array.Length];
                //copy
                for (int i = head, j = 0; j < array.Length; j++)
                {
                    temp[j] = array[i];
                    ////next item in the array
                    //i++;
                    ////wrap i around if reached end of array
                    //i = i % array.Length;
                    //or
                    i = (i + 1) % array.Length;
                }
                //make the temp be the array
                array = temp;
                //adjust the head and tail
                head = 0;
                tail = count;
                //add the new data
                array[tail] = data;
                count++;
            }
        }
        public object Dequeue()
        {
            //removes and returns the first item in the Queue
            //check if empty
            //check if it has one item
            //else (if it has more than one)
            if (count == 0)
                throw new InvalidOperationException("Queue is empty...");

            if (count == 1)
            {
                //both head and tail should be set -1, count=0
                object temp1 = array[head];//save item you want to return
                //reset the head and tail
                head = tail = -1;
                count--;
                return temp1;

            }
            object temp2 = array[head];//save item you want to return
            head = (head + 1) % array.Length; //next item becomes (with wrap around) the first item in the queue
            count--;
            return temp2;
        }
        public object Peek()
        {
            //returns (but does not remove) dthe first item in the Queue
            if (count == 0)
                throw new InvalidOperationException("Queue is empty...");

            //return (but not remove) the first item in the queue
            return array[head];
        }
        //helper methods
        public bool Contains(object data)
        {

            for (int i = head; i < count; i = (i + 1) % array.Length)
            {
                if (array[i].Equals(data)) //your custom class MUST override the Equals
                {                          //method to work properly
                    return true;
                }
            }
            return false;
        }
        public object[] ToArray()
        {
            object[] temp = new object[count];
            //let i be the index for the internal array
            //let j be the index for the temp array
            for (int i = head, j = 0; j < temp.Length; j++)
            {
                temp[j] = array[i];
                ////next item in the array
                //i++;
                ////wrap i around if reached end of array
                //i = i % array.Length;
                //or
                i = (i + 1) % array.Length;
            }
            return temp;
        }
        public void Clear()
        {
            //empties the entire queue.
            head = tail = -1;
            count = 0;
        }
        public static MyQueue Merge(MyQueue queue1, MyQueue queue2)
        {
            MyQueue temp = new MyQueue(); 
            while(queue1.Count != 0 && queue2.Count != 0)
            {
                temp.Enqueue(queue1.Dequeue()); //a
                temp.Enqueue(queue2.Dequeue()); //b
            }

            while(queue1.Count != 0)
            {
                temp.Enqueue(queue1.Dequeue());
            }
            while (queue2.Count != 0)
            {
                temp.Enqueue(queue2.Dequeue());
            }
            return temp;
        }
        public static MyQueue MergeSort(MyQueue queue1, MyQueue queue2)
        {
            MyQueue temp = new MyQueue();
            while (queue1.Count != 0 && queue2.Count != 0)
            {
                if ((int)queue1.Peek()  < (int)queue2.Peek() ) {
                    temp.Enqueue(queue1.Dequeue()); //a
                }
                else {
                    temp.Enqueue(queue2.Dequeue()); //b
                }
            }

            while (queue1.Count != 0)
            {
                temp.Enqueue(queue1.Dequeue());
            }
            while (queue2.Count != 0)
            {
                temp.Enqueue(queue2.Dequeue());
            }
            return temp;
        }
        public static MyQueue getDuplicates(MyQueue sorted)
        {
            MyQueue tempQ = new MyQueue(); //O(1) 
            for (int i = 0; i < sorted.Count; i++) //n+4
            {
                object temp = sorted.Dequeue(); //1
                if((int)temp == (int)sorted.Peek()) //3
                {
                    tempQ.Enqueue(temp); //1
                    sorted.Enqueue(temp); //1
                }
                else 
                {
                    sorted.Enqueue(temp); //1
                }

            }
            return tempQ; //1
        }
        //worst case Time Complexity: T(n) = n+5
    }

}
/// 1. a static method Merge : public static MyQueue Merge(MyQueue queue1 , MyQueue queue2)
/// to merge two queues into a single queue. the merge should alternate between the 2 queues
/// if one of them has some left items then dump them into the resulting queue
/// 
/// 2. a static method MergeSort: public static MyQueue MergeSort(MyQueue queue1 , MyQueue queue2)
/// to merge two sorted queues into a sorted queue
/// so here we assume that both queue1 and queue2 are sorted
/// merge them into a single queue so that the resulting queue is also sorted.
/// 
/// 3. a static method GetDuplicates that takes a sorted queue and returns a queue of all the duplicates
/// do that in O(n)