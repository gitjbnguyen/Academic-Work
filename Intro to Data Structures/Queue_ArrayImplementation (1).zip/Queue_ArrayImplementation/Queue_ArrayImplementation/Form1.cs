﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Queue_ArrayImplementation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //this button enqueues
        private void btnDisplayQueue_Click(object sender, EventArgs e)
        {
            MyQueue queue1 = new MyQueue(8);
            queue1.Enqueue(10);
            queue1.Enqueue(20);
            queue1.Enqueue(30);
            queue1.Enqueue(40);
            queue1.Enqueue(50);
            queue1.Enqueue(60);
            queue1.Enqueue(70);
            queue1.Enqueue(80);
            queue1.Enqueue(90);
            queue1.Enqueue(100);


            //display            
            Display(queue1);
        }
        private void Display(MyQueue queue)
        {
            //listBox1.Items.Clear();
            object[] array = queue.ToArray();
            foreach (object data in array)
            {
                listBox1.Items.Add(data);
            }
        }


        //this button dequeues
        private void btnDequeue_Click(object sender, EventArgs e)
        {
            MyQueue queue1 = new MyQueue(8);
            queue1.Enqueue(10);
            queue1.Enqueue(20);
            queue1.Enqueue(30);
            queue1.Enqueue(40);
            queue1.Enqueue(50);
            queue1.Enqueue(60);
            queue1.Enqueue(70);
            queue1.Enqueue(80);
            queue1.Enqueue(90);
            queue1.Enqueue(100);
            //display            
            Display(queue1);

            object x = queue1.Dequeue();
            listBox1.Items.Add("-------------");
            listBox1.Items.Add($"dequeued: {x}");
            listBox1.Items.Add("-------------");

            //display            
            Display(queue1);

            object y = queue1.Peek();
            listBox1.Items.Add("-------------");
            listBox1.Items.Add($"peek: {y}");
            listBox1.Items.Add("-------------");
        }

        private void btnMerge_Click(object sender, EventArgs e)
        {


            //MyQueue queue1 = new MyQueue(8);
            //Random rand = new Random();
            //for (int i = 0; i < 9; i++)
            //{
            //    queue1.Enqueue(rand.Next(1, 50));
            //}
            //MyQueue queue2 = new MyQueue(8);
            //for (int i = 0; i < 9; i++)
            //{
            //    queue2.Enqueue(rand.Next(1, 50));
            //}
            MyQueue queue1 = new MyQueue(8);
            queue1.Enqueue(10);
            queue1.Enqueue(20);
            queue1.Enqueue(30);
            queue1.Enqueue(40);
            queue1.Enqueue(50);
            queue1.Enqueue(60);
            queue1.Enqueue(70);
            queue1.Enqueue(80);
            queue1.Enqueue(90);
            queue1.Enqueue(100);
            MyQueue queue2 = new MyQueue(8);
            queue2.Enqueue(10);
            queue2.Enqueue(20);
            queue2.Enqueue(30);
            queue2.Enqueue(40);
            queue2.Enqueue(50);
            queue2.Enqueue(60);
            queue2.Enqueue(70);
            queue2.Enqueue(80);
            queue2.Enqueue(90);
            queue2.Enqueue(100);
            listBox1.Items.Add("pre merge:");
            Display(queue1);
            Display(queue2);
            listBox1.Items.Add("post merge:");
            MyQueue mq = MyQueue.Merge(queue1,queue2);
            Display(mq);


        }

        private void btnMergeSort_Click(object sender, EventArgs e)
        {
            MyQueue queue1 = new MyQueue(8);
            queue1.Enqueue(10);
            queue1.Enqueue(20);
            queue1.Enqueue(30);
            queue1.Enqueue(40);
            queue1.Enqueue(50);
            queue1.Enqueue(60);
            queue1.Enqueue(70);
            queue1.Enqueue(80);
            queue1.Enqueue(90);
            queue1.Enqueue(100);
            MyQueue queue2 = new MyQueue(8);
            queue2.Enqueue(61);
            queue2.Enqueue(71);
            queue2.Enqueue(80);
            queue2.Enqueue(91);

            listBox1.Items.Add("pre merge:");
            Display(queue1);
            Display(queue2);
            listBox1.Items.Add("post merge:");
            MyQueue mq = MyQueue.MergeSort(queue1, queue2);
            Display(mq);
        }

        private void btnGetDuplicates_Click(object sender, EventArgs e)
        {
            MyQueue queue1 = new MyQueue(8);
            queue1.Enqueue(10);
            queue1.Enqueue(10);
            queue1.Enqueue(30);
            queue1.Enqueue(40);
            queue1.Enqueue(50);
            queue1.Enqueue(60);
            queue1.Enqueue(70);
            queue1.Enqueue(90);
            queue1.Enqueue(90);
            queue1.Enqueue(100);
            //MyQueue queue2 = MyQueue.getDuplicates(queue1);

            listBox1.Items.Add("before getting duplicates");
            Display(queue1);
            listBox1.Items.Add("after getting duplicates");
            Display(MyQueue.getDuplicates(queue1));
        }
    }
}
