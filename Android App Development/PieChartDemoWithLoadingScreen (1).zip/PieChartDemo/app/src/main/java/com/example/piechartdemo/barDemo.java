package com.example.piechartdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class barDemo extends AppCompatActivity {


    BarChart barChart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.setTitle("Bar Chart");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bar_demo);

        barChart = findViewById(R.id.barchart);

        ArrayList<BarEntry> records = new ArrayList<>();

        BarDataSet dataSet = new BarDataSet(records, "Bar Chart Business Report");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(22f);

        BarData barData = new BarData(dataSet);

        barChart.setData(barData);
        barChart.getDescription().setEnabled(true);
        // enable touch gestures
        barChart.setTouchEnabled(true);

        // enable scaling and dragging
        barChart.setDragEnabled(true);
        barChart.setScaleEnabled(true);

        // if disabled, scaling can be done on x- and y-axis separately
        barChart.setPinchZoom(false);

        //lineChart.setCenterText("Quarterly Revenue");
        barChart.animate();

    }
}