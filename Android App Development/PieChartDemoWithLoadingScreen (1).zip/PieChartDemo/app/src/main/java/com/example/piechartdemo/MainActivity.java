package com.example.piechartdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button btnpie;
    Button btnline;
    Button btnbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.setTitle("Main Activity");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        btnpie = findViewById(R.id.btnpie);
        btnline = findViewById(R.id.btnline);
        btnbar = findViewById(R.id.btnbar);
        btnpie.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), pieDemo.class));
            }
        });
        btnline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), lineDemo.class));
            }
        });
        btnbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(), barDemo.class));
            }
        });
    }
}