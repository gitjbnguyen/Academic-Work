package com.example.piechartdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.lusfold.spinnerloading.SpinnerLoading;

public class spinnerActivity extends AppCompatActivity {

    SpinnerLoading spinnerLoading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setTitle("Loading Screen");
        setContentView(R.layout.activity_spinner);

        //create handler to handle the switching of activities from splash to main
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(spinnerActivity.this, MainActivity.class);
                startActivity(intent);
                spinnerLoading = findViewById(R.id.spinner);
                spinnerLoading.setPaintMode(1);
                spinnerLoading.setCircleRadius(30);
            }
        }, 4000);
    }
}