package com.example.piechartdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;

public class lineDemo extends AppCompatActivity {

    LineChart lineChart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.setTitle("Line Chart");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_line_demo);

        lineChart = findViewById(R.id.linechart);

        ArrayList<Entry> records = new ArrayList<>();
        records.add(new Entry(10, 20));
        records.add(new Entry(11, 21));
        records.add(new Entry(12, 22));
        records.add(new Entry(13, 23));

        LineDataSet dataSet = new LineDataSet(records, "Line Chart Business Report");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        dataSet.setValueTextColor(Color.BLACK);
        dataSet.setValueTextSize(22f);

        LineData lineData = new LineData(dataSet);

        lineChart.setData(lineData);
        lineChart.getDescription().setEnabled(true);
        // enable touch gestures
        lineChart.setTouchEnabled(true);

        // enable scaling and dragging
        lineChart.setDragEnabled(true);
        lineChart.setScaleEnabled(true);

        // if disabled, scaling can be done on x- and y-axis separately
        lineChart.setPinchZoom(false);

        //lineChart.setCenterText("Quarterly Revenue");
        lineChart.animate();
    }
}