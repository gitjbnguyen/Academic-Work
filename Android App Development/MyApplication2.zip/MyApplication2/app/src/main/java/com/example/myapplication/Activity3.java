package com.example.myapplication;

import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Activity3 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        //grab the components and call them by their id
        final RadioGroup radioGroup1 = findViewById(R.id.radioGroup1);
        final RadioGroup radioGroup2 = findViewById(R.id.radioGroup2);
        final TextView textView = (TextView) findViewById(R.id.tv4result);
        Button button = findViewById(R.id.btnGetSelection);

        //the button will need an onclick listener
        View.OnClickListener onClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton Drinks = findViewById(radioGroup1.getCheckedRadioButtonId());
                RadioButton Food = findViewById(radioGroup2.getCheckedRadioButtonId());
                String result = "You ordered: " + Drinks.getText().toString() + " and " + Food.getText().toString();
                textView.setText(result);

            }
        };
        //call the onclick listener method
        button.setOnClickListener(onClickListener);
    }
    public void onRadioButtonClicked(View view) {}
}