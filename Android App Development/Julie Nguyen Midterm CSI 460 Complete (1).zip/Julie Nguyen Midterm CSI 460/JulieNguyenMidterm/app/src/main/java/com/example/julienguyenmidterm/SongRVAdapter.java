package com.example.julienguyenmidterm;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

/*
Julie Nguyen
10/30/2021
CSI 460
Objective: create a recycler view adapter to work with the recycler view item
*/

//Source: https://www.geeksforgeeks.org/how-to-perform-crud-operations-in-room-database-in-android/
//tutorial by Chaitanya Munje
//Chaitanya Munje provides a tutorial on how to perform CRUD operations in room database along with step by step instructions.
public class SongRVAdapter extends ListAdapter<Song, SongRVAdapter.ViewHolder>{

    // creating a variable for on item click listener.
    private OnItemClickListener listener;

    // creating a constructor class for our adapter class.
    SongRVAdapter() {
        super(DIFF_CALLBACK);
    }

    // creating a call back for item of recycler view.
    private static final DiffUtil.ItemCallback<Song> DIFF_CALLBACK = new DiffUtil.ItemCallback<Song>() {
        @Override
        public boolean areItemsTheSame(Song oldItem, Song newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(Song oldItem, Song newItem) {
            // below line is to check the song title, artist, year, genre, and rating.
            return oldItem.getTitle().equals(newItem.getTitle()) &&
                    oldItem.getArtist().equals(newItem.getArtist()) &&
                    oldItem.getYear() == newItem.getYear() &&
                    oldItem.getAlbum().equals(newItem.getAlbum()) &&
                    oldItem.getGenre().equals(newItem.getGenre()) &&
                    oldItem.getRating() == newItem.getRating();
        }
    };

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // below line is use to inflate our layout file for each item of our recycler view.
        View item = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.song_rv_item, parent, false);
        return new ViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // below line of code is use to set data to each item of our recycler view.
        Song model = getSongAt(position);
        holder.songTitleTV.setText(model.getTitle());
        holder.songArtistTV.setText(model.getArtist());
        holder.songYearTV.setText(model.getYear() + "");
        holder.songAlbumTV.setText(model.getAlbum());
        holder.songGenreTV.setText(model.getGenre());
        holder.songRatingTV.setText(model.getRating() + "");
    }

    // creating a method to get song model for a specific position.
    public Song getSongAt(int position) {
        return getItem(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        // view holder class to create a variable for each view.
        TextView songTitleTV, songArtistTV, songYearTV, songAlbumTV, songGenreTV, songRatingTV;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            // initializing each view of our recycler view.
            songTitleTV = itemView.findViewById(R.id.idTVSongTitle);
            songArtistTV = itemView.findViewById(R.id.idTVSongArtist);
            songYearTV = itemView.findViewById(R.id.idTVSongYear);
            songAlbumTV = itemView.findViewById(R.id.idTVSongAlbum);
            songGenreTV = itemView.findViewById(R.id.idTVSongGenre);
            songRatingTV = itemView.findViewById(R.id.idTVSongRating);

            // adding on click listener for each item of recycler view.
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // inside on click listener we are passing
                    // position to our item of recycler view.
                    int position = getAdapterPosition();
                    if (listener != null && position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(getItem(position));
                    }
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Song model);
    }
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

}
