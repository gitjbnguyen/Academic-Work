package com.example.julienguyenmidterm;

import android.app.Application;
import android.os.AsyncTask;

import androidx.lifecycle.LiveData;

import java.util.List;
/*
Julie Nguyen
10/30/2021
CSI 460
Objective: create repository class that implements CRUD operations and does background tasks
*/

//Source: https://www.geeksforgeeks.org/how-to-perform-crud-operations-in-room-database-in-android/
//tutorial by Chaitanya Munje
//Chaitanya Munje provides a tutorial on how to perform CRUD operations in room database along with step by step instructions.
public class SongRepository {
    // below line is the create a variable for dao and list for all songs.
    private Dao dao;
    private LiveData<List<Song>> allSongs;

    // creating a constructor for our variables and passing the variables to it.
    public SongRepository(Application application) {
        SongDatabase database = SongDatabase.getInstance(application);
        dao = database.Dao();
        allSongs = dao.getAllSongs();
    }

    // creating a method to insert the data to our database.
    public void insert(Song model) {
        new InsertSongAsyncTask(dao).execute(model);
    }

    // creating a method to update data in database.
    public void update(Song model) {
        new UpdateSongAsyncTask(dao).execute(model);
    }

    // creating a method to delete the data in our database.
    public void delete(Song model) {
        new DeleteSongAsyncTask(dao).execute(model);
    }

    // below is the method to delete all the songs.
    public void deleteAllSongs() {
        new DeleteAllSongsAsyncTask(dao).execute();
    }

    // below method is to read all the songs.
    public LiveData<List<Song>> getAllSongs() {
        return allSongs;
    }

    // we are creating a async task method to insert new song.
    private static class InsertSongAsyncTask extends AsyncTask<Song, Void, Void> {
        private Dao dao;

        private InsertSongAsyncTask(Dao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(Song... model) {
            // below line is use to insert our model in dao.
            dao.insert(model[0]);
            return null;
        }
    }

    // we are creating a async task method to update our song.
    private static class UpdateSongAsyncTask extends AsyncTask<Song, Void, Void> {
        private Dao dao;

        private UpdateSongAsyncTask(Dao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(Song... models) {
            // below line is use to update our modal in dao.
            dao.update(models[0]);
            return null;
        }
    }

    // we are creating a async task method to delete song.
    private static class DeleteSongAsyncTask extends AsyncTask<Song, Void, Void> {
        private Dao dao;

        private DeleteSongAsyncTask(Dao dao) {
            this.dao = dao;
        }

        @Override
        protected Void doInBackground(Song... models) {
            // below line is use to delete our song model in dao.
            dao.delete(models[0]);
            return null;
        }
    }

    // we are creating a async task method to delete all songs.
    private static class DeleteAllSongsAsyncTask extends AsyncTask<Void, Void, Void> {
        private Dao dao;
        private DeleteAllSongsAsyncTask(Dao dao) {
            this.dao = dao;
        }
        @Override
        protected Void doInBackground(Void... voids) {
            //calling method to delete all songs.
            dao.deleteAllSongs();
            return null;
        }
    }
}
