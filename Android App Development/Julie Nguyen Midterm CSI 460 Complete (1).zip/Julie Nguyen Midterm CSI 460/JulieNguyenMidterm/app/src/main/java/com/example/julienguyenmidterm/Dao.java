package com.example.julienguyenmidterm;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

/*
Julie Nguyen
10/30/2021
CSI 460
Objective: dao class created for CRUD operations
*/

// Adding annotation
// to our Dao class
//Sources: https://developer.android.com/reference/android/arch/persistence/room/Dao
//https://developer.android.com/training/data-storage/room/accessing-data
//https://developer.android.com/training/data-storage/room/async-queries#guava-livedata
//Source: https://www.geeksforgeeks.org/how-to-perform-crud-operations-in-room-database-in-android/
//tutorial by Chaitanya Munje
//Chaitanya Munje provides a tutorial on how to perform CRUD operations in room database along with step by step instructions.
@androidx.room.Dao
public interface Dao {

    // add song to database.
    @Insert
    void insert(Song model);

    // update song in our database.
    @Update
    void update(Song model);

    // delete song in the database.
    @Delete
    void delete(Song model);

    // we are making query to delete all songs from our database.
    @Query("DELETE FROM Songs")
    void deleteAllSongs();

    // below line is to read all the songs from our database. in this case we are ordering our songs in ascending
    // order by our song title.
    @Query("SELECT * FROM Songs ORDER BY Title ASC")
    LiveData<List<Song>> getAllSongs();
}