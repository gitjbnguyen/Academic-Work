package com.example.julienguyenmidterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;


/*
Julie Nguyen
10/30/2021
CSI 460
Objective: create a splash page as a loading screen to introduce the user the context of the app
*/

//Source: https://www.youtube.com/watch?v=EK4KKsmYNEY
// the author "FIREBOLT Studio" provides a tutorial on how to implement splash activity
// put the intent filter from main activity to the splash activity in the AndroidManifest.xml
// create a styles.xml file if it does not exist and create color values
// go to SplashActivity.java (here) to create logic for the handler.
public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        //create handler to handle the switching of activities from splash to main
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
            }
        }, 2000);

    }
}