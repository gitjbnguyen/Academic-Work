package com.example.julienguyenmidterm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/*
Julie Nguyen
10/30/2021
CSI 460
Objective: create logic to send the data to room database after receiving user input
*/

//Source: https://www.geeksforgeeks.org/how-to-perform-crud-operations-in-room-database-in-android/
//tutorial by Chaitanya Munje
//Chaitanya Munje provides a tutorial on how to perform CRUD operations in room database along with step by step instructions.
public class NewSongActivity extends AppCompatActivity {

    // creating a variables for our button and edittext.
    private EditText titleEdt, artistEdt, yearEdt, albumEdt, genreEdt, ratingEdt;
    private Button songBtn;

    // creating a constant string variable for our song title, artist and genre.
    //creating string variables for year and rating
    public static final String EXTRA_ID = "com.example.julienguyenmidterm.EXTRA_ID";
    public static final String EXTRA_SONG_TITLE = "com.example.julienguyenmidterm.EXTRA_SONG_TITLE";
    public static final String EXTRA_SONG_ARTIST = "com.example.julienguyenmidterm.EXTRA_SONG_ARTIST";
    public static final String EXTRA_SONG_YEAR = "com.example.julienguyenmidterm.EXTRA_SONG_YEAR";
    public static final String EXTRA_SONG_ALBUM = "com.example.julienguyenmidterm.EXTRA_SONG_ALBUM";
    public static final String EXTRA_SONG_GENRE = "com.example.julienguyenmidterm.EXTRA_SONG_GENRE";
    public static final String EXTRA_SONG_RATING = "com.example.julienguyenmidterm.EXTRA_SONG_RATING";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_song);

        // initializing our variables for each view.
        titleEdt = findViewById(R.id.idEdtSongTitle);
        artistEdt = findViewById(R.id.idEdtSongArtist);
        yearEdt = findViewById(R.id.idEdtSongYear);
        albumEdt = findViewById(R.id.idEdtSongAlbum);
        genreEdt = findViewById(R.id.idEdtSongGenre);
        ratingEdt = findViewById(R.id.idEdtSongRating);
        songBtn = findViewById(R.id.idBtnSaveSong);

        // below line is to get intent as we are getting data via an intent.
        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_ID)) {
            // if we get id for our data then we are setting values to our edit text fields.
            titleEdt.setText(intent.getStringExtra(EXTRA_SONG_TITLE));
            artistEdt.setText(intent.getStringExtra(EXTRA_SONG_ARTIST));
            yearEdt.setText(intent.getStringExtra(EXTRA_SONG_YEAR));
            albumEdt.setText(intent.getStringExtra(EXTRA_SONG_ALBUM));
            genreEdt.setText(intent.getStringExtra(EXTRA_SONG_GENRE));
            ratingEdt.setText(intent.getStringExtra(EXTRA_SONG_RATING));

        }
        // adding on click listener for our save button.
        songBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // getting text value from edittext and validating if the text fields are empty or not.
                String songTitle = titleEdt.getText().toString();
                String songArtist = artistEdt.getText().toString();
                int songYear = Integer.parseInt(yearEdt.getText().toString());
                String songAlbum = albumEdt.getText().toString();
                String songGenre = genreEdt.getText().toString();
                int songRating = Integer.parseInt(ratingEdt.getText().toString());

                if (songTitle.isEmpty() || songArtist.isEmpty() || songYear == -1 || songAlbum.isEmpty() || songGenre.isEmpty() || songRating == -1) {
                    Toast.makeText(NewSongActivity.this, "Please enter the valid song details.", Toast.LENGTH_SHORT).show();
                    return;
                }
                // calling a method to save our song.
                saveSong(songTitle, songArtist, songYear, songAlbum, songGenre, songRating);
            }
        });
    }

    private void saveSong(String Title, String Artist, int Year, String Album, String Genre, int Rating) {
        // inside this method we are passing all the data via an intent.
        Intent data = new Intent();

        //we are passing all our song details.
        data.putExtra(EXTRA_SONG_TITLE, Title);
        data.putExtra(EXTRA_SONG_ARTIST, Artist);
        data.putExtra(EXTRA_SONG_YEAR, Year);
        data.putExtra(EXTRA_SONG_ALBUM, Album);
        data.putExtra(EXTRA_SONG_GENRE, Genre);
        data.putExtra(EXTRA_SONG_RATING, Rating);

        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        if (id != -1) {
            //we are passing our id.
            data.putExtra(EXTRA_ID, id);
        }

        // at last we are setting result as data.
        setResult(RESULT_OK, data);

        // displaying a toast message after adding the data
        Toast.makeText(this, "Song has been saved to Room Database. ", Toast.LENGTH_SHORT).show();
    }


}