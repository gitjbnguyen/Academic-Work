package com.example.julienguyenmidterm;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;
/*
Julie Nguyen
10/30/2021
CSI 460
Objective: create a view model class to interact with the repository along with additional CRUD operations
*/

//Source: https://www.geeksforgeeks.org/how-to-perform-crud-operations-in-room-database-in-android/
//tutorial by Chaitanya Munje
//Chaitanya Munje provides a tutorial on how to perform CRUD operations in room database along with step by step instructions.

public class ViewModel extends AndroidViewModel {

    // creating a new variable for song repository.
    private SongRepository repository;

    // below line is to create a variable for live data where all the songs are present.
    private LiveData<List<Song>> allSongs;

    // constructor for our view model.
    public ViewModel(@NonNull Application application) {
        super(application);
        repository = new SongRepository(application);
        allSongs = repository.getAllSongs();
    }

    // below method is use to insert the data to our repository.
    public void insert(Song model) {
        repository.insert(model);
    }

    // below line is to update song in our repository.
    public void update(Song model) {
        repository.update(model);
    }

    // below line is to delete the song in our repository.
    public void delete(Song model) {
        repository.delete(model);
    }

    // below method is to delete all the songs in our list.
    public void deleteAllSongs() {
        repository.deleteAllSongs();
    }

    // below method is to get all the songs in our list.
    public LiveData<List<Song>> getAllSongs() {
        return allSongs;
    }
}