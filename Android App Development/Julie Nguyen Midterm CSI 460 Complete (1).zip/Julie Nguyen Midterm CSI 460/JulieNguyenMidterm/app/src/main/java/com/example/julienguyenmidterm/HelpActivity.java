package com.example.julienguyenmidterm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

/*
Julie Nguyen
10/30/2021
CSI 460
Objective: Provide instruction to the user on how to use the database app
*/

public class HelpActivity extends AppCompatActivity {

    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        textView = findViewById(R.id.txtHelp);
        textView.setText("1. In the main activity, tap the floating action button on the lower right hand corner" + "\n"
        + "2. Add the valid details of your song " + "\n" +
                "3. Click 'save song'" + "\n" +
                "4. If you want to delete the song, swipe left on your selection " + "\n" +
                "5. To go back to the main activity, use the back button on your phone");
    }
}