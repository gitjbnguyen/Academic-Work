package com.example.julienguyenmidterm;
import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/*
Julie Nguyen
10/30/2021
CSI 460
Objective: create a model to use as a blueprint for data*/
//Song is a model class
//Source: https://www.geeksforgeeks.org/how-to-perform-crud-operations-in-room-database-in-android/
//tutorial by Chaitanya Munje
@Entity(tableName = "Songs")
public class Song {

    //id is primary key
    @NonNull
    @PrimaryKey(autoGenerate = true)
    private int id;

    //make the columns
    @ColumnInfo(name = "Title")
    private String title;
    @ColumnInfo(name = "Artist")
    private String artist;
    @ColumnInfo(name = "Year")
    private int year;
    @ColumnInfo(name = "Album")
    private String album;
    @ColumnInfo(name = "Genre")
    private String genre;
    @ColumnInfo(name = "Rating")
    private int rating;

    public Song (String title, String artist, int year, String album, String genre, int rating){
        this.title = title;
        this.artist = artist;
        this.year = year;
        this.album = album;
        this.genre = genre;
        this.rating = rating;
    }

    //getter and setter methods for each field
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getAlbum() {
        return album;
    }

    public void setAlbum(int year) {
        this.album = album;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}
