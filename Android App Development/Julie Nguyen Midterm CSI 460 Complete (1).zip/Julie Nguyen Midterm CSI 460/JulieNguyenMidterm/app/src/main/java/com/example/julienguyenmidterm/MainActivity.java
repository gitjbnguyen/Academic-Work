package com.example.julienguyenmidterm;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

/*
Julie Nguyen
10/30/2021
CSI 460
Objective: user interactions on the main activity and input for new songs, removing songs, and updating songs
*/

//Source: https://www.geeksforgeeks.org/how-to-perform-crud-operations-in-room-database-in-android/
//tutorial by Chaitanya Munje
//Chaitanya Munje provides a tutorial on how to perform CRUD operations in room database along with step by step instructions.

public class MainActivity extends AppCompatActivity {

    // creating a variables for our recycler view.
    private RecyclerView songsRV;
    private static final int ADD_SONG_REQUEST = 1;
    private static final int EDIT_SONG_REQUEST = 2;
    private ViewModel vm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initializing our variable for our recycler view and fab.
        songsRV = findViewById(R.id.idRVSong);
        FloatingActionButton fab = findViewById(R.id.idFABAdd);

        // adding on click listener for floating action button.
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // starting a new activity for adding a new song and passing a constant value in it.
                Intent intent = new Intent(MainActivity.this, NewSongActivity.class);
                startActivityForResult(intent, ADD_SONG_REQUEST);
            }
        });



        // set layout manager for the adapter class.
        songsRV.setLayoutManager(new LinearLayoutManager(this));
        songsRV.setHasFixedSize(true);

        // initializing adapter for recycler view.
        final SongRVAdapter adapter = new SongRVAdapter();

        // set adapter class for recycler view.
        songsRV.setAdapter(adapter);

        // passing a data from view model.
        vm = ViewModelProviders.of(this).get(ViewModel.class);

        // below line is use to get all the songs from view model.
        vm.getAllSongs().observe(this, new Observer<List<Song>>() {
            @Override
            public void onChanged(List<Song> models) {
                // when the data is changed in our models we are adding that list to our adapter class.
                adapter.submitList(models);
            }
        });
        // below method is use to add swipe to delete method for item of recycler view.
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                // on recycler view item swiped then we are deleting the item of our recycler view.
                vm.delete(adapter.getSongAt(viewHolder.getAdapterPosition()));
                Toast.makeText(MainActivity.this, "Song deleted", Toast.LENGTH_SHORT).show();
            }
        }).
                // below line is use to attach this to recycler view.
                        attachToRecyclerView(songsRV);
        // below line is use to set item click listener for our item of recycler view.
        adapter.setOnItemClickListener(new SongRVAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Song model) {
                // after clicking on item of recycler view we are opening a new activity and passing a data to our activity.
                Intent intent = new Intent(MainActivity.this, NewSongActivity.class);
                intent.putExtra(NewSongActivity.EXTRA_ID, model.getId());
                intent.putExtra(NewSongActivity.EXTRA_SONG_TITLE, model.getTitle());
                intent.putExtra(NewSongActivity.EXTRA_SONG_ARTIST, model.getArtist());
                intent.putExtra(NewSongActivity.EXTRA_SONG_YEAR, model.getYear());
                intent.putExtra(NewSongActivity.EXTRA_SONG_ALBUM, model.getAlbum());
                intent.putExtra(NewSongActivity.EXTRA_SONG_GENRE, model.getGenre());
                intent.putExtra(NewSongActivity.EXTRA_SONG_RATING, model.getRating());
                // below line is to start a new activity and adding a edit course constant.
                startActivityForResult(intent, EDIT_SONG_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        //method checks to see if the song is able to be saved or not along with being able to update or not
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_SONG_REQUEST && resultCode == RESULT_OK) {
            String songTitle = data.getStringExtra(NewSongActivity.EXTRA_SONG_TITLE);
            String songArtist = data.getStringExtra(NewSongActivity.EXTRA_SONG_ARTIST);
            int songYear = data.getIntExtra(NewSongActivity.EXTRA_SONG_YEAR, -1);
            String songAlbum = data.getStringExtra(NewSongActivity.EXTRA_SONG_ALBUM);
            String songGenre = data.getStringExtra(NewSongActivity.EXTRA_SONG_GENRE);
            int songRating = data.getIntExtra(NewSongActivity.EXTRA_SONG_RATING, -1);
            Song model = new Song(songTitle, songArtist, songYear, songAlbum, songGenre, songRating);
            vm.insert(model);
            Toast.makeText(this, "Song saved", Toast.LENGTH_SHORT).show();
        } else if (requestCode == EDIT_SONG_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(NewSongActivity.EXTRA_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Song can't be updated", Toast.LENGTH_SHORT).show();
                return;
            }
            String songTitle = data.getStringExtra(NewSongActivity.EXTRA_SONG_TITLE);
            String songArtist = data.getStringExtra(NewSongActivity.EXTRA_SONG_ARTIST);
            int songYear = data.getIntExtra(NewSongActivity.EXTRA_SONG_YEAR, -1);
            String songAlbum = data.getStringExtra(NewSongActivity.EXTRA_SONG_ALBUM);
            String songGenre = data.getStringExtra(NewSongActivity.EXTRA_SONG_GENRE);
            int songRating = data.getIntExtra(NewSongActivity.EXTRA_SONG_RATING, -1);
            Song model = new Song(songTitle, songArtist, songYear, songAlbum, songGenre, songRating);
            model.setId(id);
            vm.update(model);
            Toast.makeText(this, "Song updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Song not saved", Toast.LENGTH_SHORT).show();
        }
    }

    //help button onclick method
    public void UserHelp(View v)
    {
        Intent intent = new Intent(MainActivity.this, HelpActivity.class);
        startActivity(intent);
    }
}