package com.example.recyclerviewexample;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    RecyclerView rcl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcl = (RecyclerView)findViewById(R.id.rclview);
        rcl.setLayoutManager(new LinearLayoutManager(this));

        String array[] = {"Lewis", "Matt", "Kenny", "Steven", "William", "Julie"};

        rcl.setAdapter(new myAdapter(array));
    }
}