package com.example.coffeejulienguyen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

public class LatteActivity extends AppCompatActivity {

    Cart cart;
    GridView grid;
    //EditText editTextQuantity;
    Button btnOrder;
    Button btnCancel;
    String description [] = {"creamy antioxidant booster", "double shot grizzly espresso added", "honey flavored latte", "autumn special", "I ran out of ideas"};
    String name []= {"Beary Matcha Latte","Grizzly Latte","Honeybee Latte","Cubkin Spice Latte","Polar Vanilla Latte"};
    double prices [] = {5.75, 6.25, 4.50, 5.50, 5.25};
    int quantity [] = {0,0,0,0,0};
    int images [] = {
            R.drawable.bearymatchalatte,
            R.drawable.grizzlylatte,
            R.drawable.honeylatte,
            R.drawable.pslatte,
            R.drawable.vclatte,
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_latte);
        setTitle("Latte Menu");

        cart = (Cart)getIntent().getSerializableExtra("cart");
        if(cart == null)
        {
            cart = new Cart();
        }
        //grid code
        grid = (GridView)findViewById(R.id.gridview);
        gridAdapter ga = new gridAdapter(name, images, prices, description, quantity,this);
        grid.setAdapter(ga);

        //choose the drink and adjust quantity by clicking
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //be able to choose the item and modify the quantity
                Toast.makeText(getApplicationContext(), "Added to your order: " + name[position],  Toast.LENGTH_SHORT).show();
                Drink drink = new Drink(name[position], prices[position], quantity[position] + 1);
                cart.addDrink(drink);

            }
        });


    }
    //button onclick methods
    public void PlaceOrder(View view)
    {
        Intent intent = new Intent(getApplicationContext(), OrderActivity.class);
        intent.putExtra("cart", cart);
        startActivity(intent);
    }

    public void CancelOrder(View view)
    {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }

}