package com.example.coffeejulienguyen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

public class MochaActivity extends AppCompatActivity {

    Cart cart;
    GridView gvmocha;
    String description [] = {"A sweet creamy mocha", "A bold dark chocolate brew", "A seasonal mocha", "A fragrant blend of spices", "Fruity blend"};
    String name []= {"Pale Grizzly Mocha","Black Grizzly Mocha","Cubkin Spiced Mocha","Cubkin Chai Mocha","Wild Raspberry Mocha"};
    double prices [] = {5.75, 6.25, 4.50, 5.50, 5.25};
    int quantity [] = {0,0,0,0,0};
    int images [] = {
            R.drawable.ccmocha,
            R.drawable.cafemocha,
            R.drawable.psmocha,
            R.drawable.chaimocha,
            R.drawable.raspberrymocha,
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mocha);
        setTitle("Mocha Menu");

        cart = (Cart)getIntent().getSerializableExtra("cart");
        if(cart == null)
        {
            cart = new Cart();
        }
        //grid code
        gvmocha = (GridView)findViewById(R.id.gvmocha);
        gridAdapter gm = new gridAdapter(name, images, prices, description, quantity,this);
        gvmocha.setAdapter(gm);

        //choose the drink and adjust quantity by clicking
        gvmocha.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //be able to choose the item and modify the quantity
                Toast.makeText(getApplicationContext(), "Added to your order: " + name[position],  Toast.LENGTH_SHORT).show();
                Drink drink = new Drink(name[position], prices[position], quantity[position] + 1);
                cart.addDrink(drink);

            }
        });


    }
    //button onclick methods
    public void PlaceOrderMocha(View view)
    {
        Intent intent = new Intent(getApplicationContext(), OrderActivity.class);
        intent.putExtra("cart", cart);
        startActivity(intent);
    }

    public void CancelMocha(View view)
    {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);
    }
}