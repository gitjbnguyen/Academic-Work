package com.example.coffeejulienguyen;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

//this is the cart (order) class

public class Cart implements Serializable {

    List<Drink> drinks;

    public Cart() {
        drinks = new ArrayList<Drink>();
    }

    public void addDrink(Drink drink)
    {
        int index = -1;
        for(int i =0; i < drinks.size(); i++)
        {
            if(drinks.get(i).getName().equals(drink.getName())) {
                index = i;
                break;
            }
        }

       if(index == -1)
       {
           drinks.add(drink);
       } else {
               int quantity = drinks.get(index).getQuantity();
               drinks.get(index).setQuantity(quantity + 1);
       }
    }

    public void removeDrink(Drink drink)
    {
        drinks.remove(drink);
    }

    public void getDrinkQuantity()
    {
        System.out.println(drinks.size());
    }

    public Drink getDrinkName(int index)
    {
        return drinks.get(index);
    }





    public double getSubtotal()
    {
        double price = 0.00;
        for(Drink drink: drinks)
        {
            price += drink.getPrice() * drink.getQuantity();
        }
        return price;
    }

    public double getTotal()
    {
        double subtotal = getSubtotal();
        double tax = subtotal * 0.1;
        return subtotal + tax;
    }

    public String displayDrinks()
    {
        String list = "";

        for(Drink drink : drinks)
        {
            list += drink.getName() + " Price $" + drink.getPrice() + " Quantity x " + drink.getQuantity() + "\n";
        }
        return list;
    }
}
