package com.example.coffeejulienguyen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.DecimalFormat;

public class OrderActivity extends AppCompatActivity {

    DecimalFormat df = new DecimalFormat("#.##");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        setTitle("Order Receipt");

        Button btnPassOrder = findViewById(R.id.btnPassOrder);
        TextView txtOrder = findViewById(R.id.txtOrder);
        Cart cart = (Cart)getIntent().getSerializableExtra("cart");
        if(cart != null)
        {
            double expression = cart.getTotal() - cart.getSubtotal();
            double tax = Math.floor(expression * 100)/100;
            txtOrder.setText(cart.displayDrinks() + "Subtotal: $" + cart.getSubtotal() + "\n" + "Tax: $" + (tax + 0.01) + "\n" + "Total Cost: $ " + String.format("%.2f",cart.getTotal()) + "\n");
        }
        else {
            txtOrder.setText("No upcoming orders.");
        }

        btnPassOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("cart", cart);
                startActivity(intent);
            }
        });



    }


}