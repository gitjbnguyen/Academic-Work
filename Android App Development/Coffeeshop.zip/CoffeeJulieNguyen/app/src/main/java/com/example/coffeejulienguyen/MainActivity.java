package com.example.coffeejulienguyen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button button;
    Button btnViewOrder;
    TextView txtOrderSummary;
    Cart cart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Julie's Coffee Shop");
        //context menu here in this button
        button = (Button) findViewById(R.id.button);

        //register a view for context menu
        // register a view like a list
        registerForContextMenu(button);
        //view order here
        btnViewOrder = findViewById(R.id.btnViewOrder);
        txtOrderSummary = (TextView)findViewById(R.id.txtOrderSummary);
        cart = (Cart)getIntent().getSerializableExtra("cart");
        if(cart != null) {
            txtOrderSummary.setText("Total: $ " + String.format("%.2f",cart.getTotal()) + "\n");
        }

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        // you can set menu header with title icon etc
        menu.setHeaderTitle("Choose a drink:");
        // add menu items
        menu.add(0, v.getId(), 0, "Latte");
        menu.add(0, v.getId(), 0, "Mocha");
        menu.add(0, v.getId(), 0, "Americano");
    }
    // menu item select listener
    @Override
    public boolean onContextItemSelected(MenuItem item) {
        Intent intent;
        if (item.getTitle() == "Latte") {
            intent = new Intent(this, LatteActivity.class);
            if(cart != null)
                intent.putExtra("cart", cart);
            startActivity(intent);
        } else if (item.getTitle() == "Mocha") {
            intent = new Intent(this, MochaActivity.class);
            if(cart != null)
                intent.putExtra("cart", cart);
            startActivity(intent);
        } else if (item.getTitle() == "Americano") {
            intent = new Intent(this, AmericanoActivity.class);
            if(cart != null)
                intent.putExtra("cart", cart);
            startActivity(intent);
        }

        return true;
    }

    public void viewOrder(View view)
    {
        Intent intent = new Intent(getApplicationContext(), OrderActivity.class);
        if(cart != null)
        {
            intent.putExtra("cart", cart);
        }
        startActivity(intent);

    }

}