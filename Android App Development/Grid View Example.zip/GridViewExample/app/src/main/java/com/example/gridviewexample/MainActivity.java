package com.example.gridviewexample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.os.Bundle;
import android.widget.GridView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    GridView grid;

    String name []= {"HTML","Java","JSP","PHP","Python","SQL","Android", "Angular", "C++"};
    int images [] = {
            R.drawable.a,
            R.drawable.b,
            R.drawable.c,
            R.drawable.d,
            R.drawable.e,
            R.drawable.f,
            R.drawable.g,
            R.drawable.h,
            R.drawable.i
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Grid View App");

        grid = (GridView)findViewById(R.id.gridview);
        gridAdapter ga = new gridAdapter(name, images, this);
        grid.setAdapter(ga);

        grid.setOnItemClickListener(new AdapterView.OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent,View v, int position, long id)
            {
                Toast.makeText(getApplicationContext(), name[position], Toast.LENGTH_SHORT).show();
                //Toast.makeText(getApplicationContext(), name.toString(), Toast.LENGTH_SHORT).show();
                //Toast.makeText(MainActivity.this, "here: " + position, Toast.LENGTH_SHORT).show();
            }
        });
    }
}