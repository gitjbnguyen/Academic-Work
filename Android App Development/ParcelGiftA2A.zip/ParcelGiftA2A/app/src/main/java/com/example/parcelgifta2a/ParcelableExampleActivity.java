package com.example.parcelgifta2a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class ParcelableExampleActivity extends AppCompatActivity {

    Information information;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcelable_example);

        textView = findViewById(R.id.textView);

        Bundle info = getIntent().getExtras();
        information = (Information) info.getParcelable("A");
        String displayInfo =
                "Name: " + information.getName() +
                        " Birthday: " + information.getBirthday() +
                        " Quote: " + information.getQuote();
       textView.setText(displayInfo);


    }
}