package com.example.parcelgifta2a;

import java.io.Serializable;

public class GiftToSend implements Serializable
{
    String name, address, zipcode, country, state, city;
    String [] gift;

    public GiftToSend(String name, String address, String zipcode, String state, String country, String city, String[] gift) {
        this.name = name;
        this.address = address;
        this.zipcode = zipcode;
        this.state = state;
        this.country = country;
        this.city = city;
        this.gift = gift;
    }

}
