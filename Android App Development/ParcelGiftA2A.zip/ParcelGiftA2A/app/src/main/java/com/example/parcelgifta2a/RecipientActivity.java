package com.example.parcelgifta2a;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import java.util.Arrays;

public class RecipientActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipient);
        setTitle("Serialized and Unserialized");
        GiftToSend giftToSend = (GiftToSend) getIntent().getSerializableExtra("gift");

        TextView txt = findViewById(R.id.txt);

        txt.setText("Name: " + giftToSend.name + "\n" +
               "Address: " + giftToSend.address + "\n" +
                "Zip Code" + giftToSend.zipcode + "\n" +
                "City: " + giftToSend.city + "\n" +
                "State: " + giftToSend.state + "\n" +
                "Country: " + giftToSend.country + "\n" +
                "Gift or Message: " + Arrays.toString(giftToSend.gift) + "\n");
    }
}