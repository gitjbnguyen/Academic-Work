package com.example.parcelgifta2a;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Information information;
    TextView textView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Serializable Example");
        Intent intent = getIntent();
        findViewById(R.id.button).setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RecipientActivity.class);

                GiftToSend giftToSend = new GiftToSend("RTC",
                        "3000 NE 4th St",
                        "98056",
                        "WA",
                        "USA",
                        "Renton",
                        new String [] {
                        "Our graduation ceremony will be very soon",
                        "you are cordially invited"
                });
                intent.putExtra("gift", giftToSend);
                startActivity(intent);
            }
        });
        //--------------------------------------------------------------------------------
        findViewById(R.id.button2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ParcelableExampleActivity.class);
                intent.putExtra("A", new Information("Jane", "04/20/2020", "I like chocolate."));
                startActivity(intent);
            }
        });
    }
}