package com.example.parcelgifta2a;

import android.os.Parcel;
import android.os.Parcelable;

public class Information implements Parcelable {
    String name;
    String birthday;
    String quote;

    public Information(String name, String birthday, String quote) {
        this.name = name;
        this.birthday = birthday;
        this.quote = quote;
    }

    public String getName() {
        return name;
    }

    public String getBirthday() {
        return birthday;
    }

    public String getQuote() {
        return quote;
    }

    //Parcelling as taught in week 6
    public Information(Parcel in)
    {
        String[] data = new String[3];
        in.readStringArray(data);
        //Order needs to be the same as in writeToParcel() method
        this.name = data[0];
        this.birthday = data[1];
        this.quote = data[2];
    }

    @Override
    public int describeContents()
    {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeStringArray(new String[] { (
                String.valueOf(this.name)),
                String.valueOf(this.birthday),
                String.valueOf(this.quote)});
    }

    public static final Parcelable.Creator CREATOR = new Parcelable.Creator()
    {
        public Information createFromParcel(Parcel in)
        {
            return new Information(in);
        }

        public Information[] newArray(int size)
        {
            return new Information[size];
        }
    };





}
