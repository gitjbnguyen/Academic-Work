package com.example.jbncontacts;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

public class ViewModel extends AndroidViewModel {

    // creating a new variable for contact repository.
    private ContactRepository repository;

    // below line is to create a variable for live
    // data where all the contacts are present.
    private LiveData<List<Contact>> allContacts;

    // constructor for our view modal.
    public ViewModel(@NonNull Application application) {
        super(application);
        repository = new ContactRepository(application);
        allContacts = repository.getAllContacts();
    }

    // below method is use to insert the data to our repository.
    public void insert(Contact model) {
        repository.insert(model);
    }

    // below line is to update data in our repository.
    public void update(Contact model) {
        repository.update(model);
    }

    // below line is to delete the data in our repository.
    public void delete(Contact model) {
        repository.delete(model);
    }

    // below method is to delete all the contacts in our list.
    public void deleteAllContacts() {
        repository.deleteAllContacts();
    }

    // below method is to get all the contacts in our list.
    public LiveData<List<Contact>> getAllContacts() {
        return allContacts;
    }
}