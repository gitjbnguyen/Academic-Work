package com.example.jbncontacts;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

// Adding annotation
// to our Dao class
@androidx.room.Dao
public interface Dao {

    // below method is use to
    // add data to database.
    @Insert
    void insert(Contact model);

    // below method is use to update
    // the data in our database.
    @Update
    void update(Contact model);

    // below line is use to delete a
    // specific course in our database.
    @Delete
    void delete(Contact model);

    // on below line we are making query to
    // delete all courses from our database.
    @Query("DELETE FROM Contacts")
    void deleteAllContacts();

    // below line is to read all the contacts from our database.
    // in this we are ordering our contacts in ascending order
    // with our id.
    @Query("SELECT * FROM Contacts ORDER BY id ASC")
    LiveData<List<Contact>> getAllContacts();
}