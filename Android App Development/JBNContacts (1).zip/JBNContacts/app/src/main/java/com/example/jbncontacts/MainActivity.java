package com.example.jbncontacts;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView contactsRV;
    private static final int ADD_CONTACT_REQUEST = 1;
    private static final int EDIT_CONTACT_REQUEST = 2;
    private ViewModel viewmodel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        contactsRV = findViewById(R.id.idRVContacts);
        FloatingActionButton fab = findViewById(R.id.idFABAdd);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NewContactActivity.class);
                startActivityForResult(intent, ADD_CONTACT_REQUEST);
            }
        });

        contactsRV.setLayoutManager(new LinearLayoutManager(this));
        contactsRV.setHasFixedSize(true);

        final ContactRVAdapter adapter = new ContactRVAdapter();

        contactsRV.setAdapter(adapter);

        viewmodel = ViewModelProviders.of(this).get(ViewModel.class);

        viewmodel.getAllContacts().observe(this, new Observer<List<Contact>>() {
            @Override
            public void onChanged(List<Contact> models) {
                adapter.submitList(models);
            }
        });
        // below method is use to add swipe to delete method for item of recycler view.
        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                // on recycler view item swiped then we are deleting the item of our recycler view.
                viewmodel.delete(adapter.getContactAt(viewHolder.getAdapterPosition()));
                Toast.makeText(MainActivity.this, "Contact deleted", Toast.LENGTH_SHORT).show();
            }
        }).
                // below line is use to attach this to recycler view.
                        attachToRecyclerView(contactsRV);
        // below line is use to set item click listener for our item of recycler view.
        adapter.setOnItemClickListener(new ContactRVAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Contact model) {
                // after clicking on item of recycler view
                // we are opening a new activity and passing
                // a data to our activity.
                Intent intent = new Intent(MainActivity.this, NewContactActivity.class);
                intent.putExtra(NewContactActivity.EXTRA_ID, model.getId());
                intent.putExtra(NewContactActivity.EXTRA_CONTACT_FIRST_NAME, model.getFirst_name());
                intent.putExtra(NewContactActivity.EXTRA_CONTACT_LAST_NAME, model.getLast_name());
                intent.putExtra(NewContactActivity.EXTRA_CONTACT_ADDRESS, model.getAddress());
                intent.putExtra(NewContactActivity.EXTRA_CONTACT_CITY, model.getCity());
                intent.putExtra(NewContactActivity.EXTRA_CONTACT_AGE, model.getAge());
                // below line is to start a new activity and
                startActivityForResult(intent, EDIT_CONTACT_REQUEST);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == ADD_CONTACT_REQUEST && resultCode == RESULT_OK) {
            String fname = data.getStringExtra(NewContactActivity.EXTRA_CONTACT_FIRST_NAME);
            String lname = data.getStringExtra(NewContactActivity.EXTRA_CONTACT_LAST_NAME);
            String address = data.getStringExtra(NewContactActivity.EXTRA_CONTACT_ADDRESS);
            String city = data.getStringExtra(NewContactActivity.EXTRA_CONTACT_CITY);
            int age = data.getIntExtra(NewContactActivity.EXTRA_CONTACT_AGE, -1);

            Contact model = new Contact(fname, lname, address, city, age);
            viewmodel.insert(model);
            Toast.makeText(this, "Contact saved", Toast.LENGTH_SHORT).show();
        } else if (requestCode == EDIT_CONTACT_REQUEST && resultCode == RESULT_OK) {
            int id = data.getIntExtra(NewContactActivity.EXTRA_ID, -1);
            if (id == -1) {
                Toast.makeText(this, "Contact can't be updated", Toast.LENGTH_SHORT).show();
                return;
            }
            String fname = data.getStringExtra(NewContactActivity.EXTRA_CONTACT_FIRST_NAME);
            String lname = data.getStringExtra(NewContactActivity.EXTRA_CONTACT_LAST_NAME);
            String address = data.getStringExtra(NewContactActivity.EXTRA_CONTACT_ADDRESS);
            String city = data.getStringExtra(NewContactActivity.EXTRA_CONTACT_CITY);
            int age = data.getIntExtra(NewContactActivity.EXTRA_CONTACT_AGE, -1);
            Contact model = new Contact(fname, lname, address, city, age);

            model.setId(id);
            viewmodel.update(model);
            Toast.makeText(this, "Contact updated", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Contact not saved", Toast.LENGTH_SHORT).show();
        }
    }
}