package com.example.jbncontacts;


import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

public class ContactRVAdapter extends ListAdapter<Contact, ContactRVAdapter.ViewHolder>{

    private OnItemClickListener listener;

    ContactRVAdapter() {
        super(DIFF_CALLBACK);
    }


    private static final DiffUtil.ItemCallback<Contact> DIFF_CALLBACK = new DiffUtil.ItemCallback<Contact>() {
        @Override
        public boolean areItemsTheSame(Contact oldItem, Contact newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(Contact oldItem, Contact newItem) {
            // below line is to check the contact info
            return oldItem.getFirst_name().equals(newItem.getFirst_name()) &&
                    oldItem.getLast_name().equals(newItem.getLast_name()) &&
                    oldItem.getAddress().equals(newItem.getAddress()) &&
                    oldItem.getCity().equals(newItem.getCity()) &&
                    oldItem.getAge()==(newItem.getAge());
        }
    };

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.contact_rv_item, parent, false);
        return new ViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Contact model = getContactAt(position);
        holder.FirstNameTV.setText(model.getFirst_name());
        holder.LastNameTV.setText(model.getLast_name());
        holder.AddressTV.setText(model.getAddress());
        holder.CityTV.setText(model.getCity());
        holder.AgeTV.setText(model.getAge() + "");
    }


    public Contact getContactAt(int position) {
        return getItem(position);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView FirstNameTV, LastNameTV, AddressTV, CityTV, AgeTV;

        ViewHolder(@NonNull View itemView) {
            super(itemView);

            FirstNameTV = itemView.findViewById(R.id.idTVContactFirstName);
            LastNameTV = itemView.findViewById(R.id.idTVContactLastName);
            AddressTV = itemView.findViewById(R.id.idTVContactAddress);
            CityTV = itemView.findViewById(R.id.idTVContactCity);
            AgeTV = itemView.findViewById(R.id.idTVContactAge);
            // adding on click listener for each item of recycler view.
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // inside on click listener we are passing
                    // position to our item of recycler view.
                    int position = getAdapterPosition();
                    if (listener != null && position != RecyclerView.NO_POSITION) {
                        listener.onItemClick(getItem(position));
                    }
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Contact model);
    }
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}