package com.example.jbncontacts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class NewContactActivity extends AppCompatActivity {

    // creating a variables for our button and edittext.
    private EditText contactFNameEdit, contactLNameEdit, contactAddressEdit, contactCityEdit, contactAgeEdit;
    private Button contactBtn;

    // creating a constant string variable for our
    // course name, description and duration.
    public static final String EXTRA_ID = "com.example.gfgroomdatabase.EXTRA_ID";
    public static final String EXTRA_CONTACT_FIRST_NAME = "com.example.jbncontacts.EXTRA_CONTACT_FIRST_NAME";
    public static final String EXTRA_CONTACT_LAST_NAME = "com.example.jbncontacts.EXTRA_CONTACT_LAST_NAME";
    public static final String EXTRA_CONTACT_ADDRESS = "com.example.jbncontacts.EXTRA_CONTACT_ADDRESS";
    public static final String EXTRA_CONTACT_CITY = "com.example.jbncontacts.EXTRA_CONTACT_CITY";
    public static final String EXTRA_CONTACT_AGE = "com.example.jbncontacts.EXTRA_CONTACT_AGE";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_contact);

        // initializing our variables for each view.
        contactFNameEdit = findViewById(R.id.idEdtContactFirstName);
        contactLNameEdit = findViewById(R.id.idEdtContactLastName);
        contactAddressEdit = findViewById(R.id.idEdtContactAddress);
        contactCityEdit = findViewById(R.id.idEdtContactCity);
        contactAgeEdit = findViewById(R.id.idEdtContactAge);
        contactBtn = findViewById(R.id.idBtnSaveContact);

        // below line is to get intent as we
        // are getting data via an intent.
        Intent intent = getIntent();
        if (intent.hasExtra(EXTRA_ID)) {
            // if we get id for our data then we are
            // setting values to our edit text fields.
            contactFNameEdit.setText(intent.getStringExtra(EXTRA_CONTACT_FIRST_NAME));
            contactLNameEdit.setText(intent.getStringExtra(EXTRA_CONTACT_LAST_NAME));
            contactAddressEdit.setText(intent.getStringExtra(EXTRA_CONTACT_ADDRESS));
            contactCityEdit.setText(intent.getStringExtra(EXTRA_CONTACT_CITY));
            contactAgeEdit.setText(intent.getStringExtra(EXTRA_CONTACT_AGE));

        }
        // adding on click listener for our save button.
        contactBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // getting text value from edittext and validating if
                // the text fields are empty or not.
                String FName = contactFNameEdit.getText().toString();
                String LName = contactLNameEdit.getText().toString();
                String Address = contactAddressEdit.getText().toString();
                String City = contactCityEdit.getText().toString();
                int Age = Integer.parseInt(contactAgeEdit.getText().toString());
                if (FName.isEmpty() || LName.isEmpty() || Address.isEmpty() || City.isEmpty() || Age == -1) {
                    Toast.makeText(NewContactActivity.this, "Please enter the valid contact details.", Toast.LENGTH_SHORT).show();
                    return;
                }
                // calling a method to save contact.
                saveContact(FName, LName, Address, City, Age);
            }
        });
    }

    private void saveContact(String FName, String LName, String Address, String City, int Age) {
        // inside this method we are passing
        // all the data via an intent.
        Intent data = new Intent();

        // in below line we are passing all our contact detail.
        data.putExtra(EXTRA_CONTACT_FIRST_NAME, FName);
        data.putExtra(EXTRA_CONTACT_LAST_NAME, LName);
        data.putExtra(EXTRA_CONTACT_ADDRESS, Address);
        data.putExtra(EXTRA_CONTACT_CITY, City);
        data.putExtra(EXTRA_CONTACT_AGE, Age);
        int id = getIntent().getIntExtra(EXTRA_ID, -1);
        if (id != -1) {
            // in below line we are passing our id.
            data.putExtra(EXTRA_ID, id);
        }

        // at last we are setting result as data.
        setResult(RESULT_OK, data);

        // displaying a toast message after adding the data
        Toast.makeText(this, "Contact has been saved to Room Database. ", Toast.LENGTH_SHORT).show();
    }
}