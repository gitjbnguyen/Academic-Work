import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class JulieNguyenAssignment1 extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtAge;
	private JTextField txtColor;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JulieNguyenAssignment1 frame = new JulieNguyenAssignment1();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JulieNguyenAssignment1() {
		super("Add Data Test");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 677, 357);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Arial", Font.PLAIN, 13));
		textArea.setBounds(230, 0, 429, 310);
		contentPane.add(textArea);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Personal Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBounds(12, 1, 206, 297);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblName = new JLabel("Name:");
		lblName.setBounds(12, 44, 57, 20);
		panel.add(lblName);
		lblName.setFont(new Font("Arial", Font.BOLD, 15));
		
		JLabel lblAge = new JLabel("Age:");
		lblAge.setBounds(12, 79, 49, 20);
		panel.add(lblAge);
		lblAge.setFont(new Font("Arial", Font.BOLD, 15));
		
		JLabel lblFavoriteColor = new JLabel("Favorite Color:");
		lblFavoriteColor.setBounds(12, 112, 109, 20);
		panel.add(lblFavoriteColor);
		lblFavoriteColor.setFont(new Font("Arial", Font.BOLD, 15));
		
		txtColor = new JTextField();
		txtColor.setBounds(122, 112, 72, 22);
		panel.add(txtColor);
		txtColor.setColumns(10);
		
		txtAge = new JTextField();
		txtAge.setBounds(122, 79, 72, 22);
		panel.add(txtAge);
		txtAge.setColumns(10);
		
		txtName = new JTextField();
		txtName.setBounds(122, 44, 72, 22);
		panel.add(txtName);
		txtName.setColumns(10);
		
		JButton btnNewButton = new JButton("ADD");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(59, 179, 86, 25);
		panel.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.removeAll(); //clears the textArea
				textArea.append(txtName.getText() + ": ");
				textArea.append(txtAge.getText() + " years old,");
				textArea.append(" and favorite color is " + txtColor.getText() + "." + "\n\n");
			}
		});
		
		
		/*
		 * JLabel lblName = new JLabel("Name: ");
		 * lblName.setHorizontalTextPosition(JLabel.HORIZONTAL);
		 * lblName.setSize(200,100); contentPane.add(lblName);
		 * 
		 * JLabel lblAge = new JLabel("Age: ");
		 * lblAge.setHorizontalTextPosition(JLabel.CENTER); lblAge.setSize(200,100);
		 * contentPane.add(lblAge);
		 * 
		 * JLabel lblColor = new JLabel("Favorite Color: ");
		 * lblColor.setHorizontalTextPosition(JLabel.CENTER); lblColor.setSize(200,100);
		 * contentPane.add(lblColor);
		 * 
		 * JTextField txtName = new JTextField(); txtName.setBackground(new Color(255,
		 * 255, 255)); GridBagConstraints gbc_txtName = new GridBagConstraints();
		 * gbc_txtName.gridy = 0; gbc_txtName.gridx = 3; contentPane.add(txtName,
		 * gbc_txtName); JTextField txtAge = new JTextField(); contentPane.add(txtAge);
		 * JTextField txtColor = new JTextField(); contentPane.add(txtColor); JButton
		 * btnAdd = new JButton(); getContentPane().add(btnAdd);
		 * 
		 * JTextArea textArea = new JTextArea(); contentPane.add(textArea);
		 */
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
