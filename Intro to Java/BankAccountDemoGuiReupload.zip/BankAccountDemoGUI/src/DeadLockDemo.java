/*
 * DeadLockDemo.java
 * DeadLockMethods.java
 * Account.java
 */
public class DeadLockDemo {

	public static void main(String[] args) throws InterruptedException {
		
		DeadLockMethods  dlm = new DeadLockMethods();
		//////////////////////////////////////////////////////////////////////////////////////////////
		// creating a thread(t1)
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					dlm.FirstThread();
				} catch (InterruptedException e) {
				}
				
			}
			
		});
		//////////////////////////////////////////////////////////////////////////////////////////////
		// creating a thread(t2)
		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					dlm.SecondThread();
				} catch (InterruptedException e) {
				}
				
			}
			
		});
		//////////////////////////////////////////////////////////////////////////////////////////////
		t1.start();
		t2.start();
		//////////////////////////////////////////////////////////////////////////////////////////////
		t1.join(); // waits for this thread to die
		t2.join();
		//////////////////////////////////////////////////////////////////////////////////////////////
		// print out the balance for Account1, Account2 and the total Balance
		dlm.finished();
		
		
	}

}
