/*
 * DeadLockDemo.java
 * DeadLockMethods.java
 * Account.java
 */
public class Account {
	private String name;
	
	private int balance = 10000;
	
	public Account(String name) {
		this.name = name;
	}
	
	public void deposit(int amount) {
		balance += amount;
	}
	public void withdraw(int amount) {
		balance -= amount;
	}
	public int getBalance() {
		return balance;
	}
	public String getName() {
		return name;
	}
	
	// transfer from Account1 -> Account2
	public synchronized static void transfer(Account account1, Account account2, int amount)
	{
		account1.withdraw(amount);
		account2.deposit(amount);
	}
}
