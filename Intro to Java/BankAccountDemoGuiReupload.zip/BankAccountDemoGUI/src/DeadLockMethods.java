import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/*
 * DeadLockDemo.java
 * DeadLockMethods.java
 * Account.java
 */
public class DeadLockMethods {
	private Account account1 = new Account("Account 1");
	private Account account2 = new Account("Account 2");
	// step2: try to fix the multi-threading issue by using ReentreantLcok class
	private Lock lock1 = new ReentrantLock();
	private Lock lock2 = new ReentrantLock();
	
	// step3: to fix the deadlock issue (deadlock happened because  neither of the threads
	// can process because each of the threads need a lock that other thread has
	private void acquireLock(Lock firstLock, Lock secondLock) throws InterruptedException {
		//
		while(true) {
			boolean gotFirstLock = false;
			boolean gotsecondLock = false;
			
			try {
				gotFirstLock = firstLock.tryLock();
				gotsecondLock = secondLock.tryLock();
			}finally {
				// check if I acquired both Locks
				if(gotFirstLock && gotsecondLock) {
					return;
				}
				if(gotFirstLock) {
					firstLock.unlock();
				}
				if(gotsecondLock) {
					secondLock.unlock();
				}
				
			}
			// 3. if failed, i.e. locks not acquired 
			Thread.sleep(1);
		}
	}
	
	public void FirstThread() throws InterruptedException {
		
		Random random = new Random();
		// // step2: before any transaction, I will lock for the accounts
		// lock1.lock();
		// lock2.lock();
		acquireLock(lock1, lock2);
				
		try {
			// transfer any amount up to $100 from account1 -> account2. 10000 times
			for(int i = 0; i < 10000;i++)
			{
				Account.transfer(account1, account2, random.nextInt(100));
			}
		}
		finally {
			// step2: unlock after lock
		lock1.unlock();
		lock2.unlock();
		
		}
		
		
	}
	public void SecondThread() throws InterruptedException{	
		
		Random random = new Random();
		// step2: before any transaction, I will lock for the accounts
		// lock1.lock();
		// lock2.lock();
		// lock1.lock();
		acquireLock(lock2, lock1);
		
		try {
			// transfer any amount up to $100 from account2 -> account1. 10000 times
		for(int i = 0; i < 10000;i++)
		{
			Account.transfer(account2, account1, random.nextInt(100));
		}
		}
		finally {
			// step2: unlock after lock
		lock2.unlock();
		lock1.unlock();
		}
		
		
	}
	
	
	// print out the balance for account1,2
	public void finished() {
		System.out.println("Account1 balance is: " + account1.getBalance());
		System.out.println("Account2 balance is: " + account2.getBalance());
		System.out.println("Total balance is: " + (account1.getBalance() + account2.getBalance()));

	}
}
