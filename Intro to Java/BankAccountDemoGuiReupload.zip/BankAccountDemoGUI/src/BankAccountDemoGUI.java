import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;

public class BankAccountDemoGUI  extends JFrame{

	private JPanel contentPane;
	private JTextField txtAmount;
	private JComboBox cboFromAcc;
	private JComboBox cboToAcc;
	private JLabel lblAccOneBal;
	private JLabel lblAccTwoBal;
	private JLabel lblTotalBalance;
	Account account1 = new Account("Account 1");
	Account account2 = new Account("Account 2");
	DeadLockMethods  dlm = new DeadLockMethods();

	/**
	 * Launch the application.
	 * 
	 * 
	 * Julie Nguyen & Christian Munoz
	 */
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				try {
					BankAccountDemoGUI frame = new BankAccountDemoGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public BankAccountDemoGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 389);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lbFromAcc = new JLabel("fromAccount:");
		lbFromAcc.setFont(new Font("Arial", Font.PLAIN, 14));
		lbFromAcc.setBounds(21, 21, 104, 36);
		contentPane.add(lbFromAcc);
		
		JLabel lblToAcc = new JLabel("toAccount:");
		lblToAcc.setFont(new Font("Arial", Font.PLAIN, 14));
		lblToAcc.setBounds(21, 49, 104, 36);
		contentPane.add(lblToAcc);
		
		JLabel lblAmount = new JLabel("Amount:");
		lblAmount.setFont(new Font("Arial", Font.PLAIN, 14));
		lblAmount.setBounds(21, 81, 104, 36);
		contentPane.add(lblAmount);
		
		txtAmount = new JTextField();
		txtAmount.setBounds(135, 90, 138, 20);
		contentPane.add(txtAmount);
		txtAmount.setColumns(10);
		
		JLabel lblDollarSign = new JLabel("$");
		lblDollarSign.setFont(new Font("Arial", Font.PLAIN, 14));
		lblDollarSign.setBounds(119, 81, 15, 36);
		contentPane.add(lblDollarSign);
		
		cboFromAcc = new JComboBox();
		cboFromAcc.setBounds(135, 30, 138, 20);
		
		cboToAcc = new JComboBox();
		cboToAcc.setBounds(135, 58, 138, 20);
		
		// add items to combo box

		
		cboFromAcc.addItem("Account 1");		
		cboFromAcc.addItem("Account 2");
		
		cboToAcc.addItem("Account 2");	
		cboToAcc.addItem("Account 1");	

		contentPane.add(cboToAcc);
		contentPane.add(cboFromAcc);	
		
		lblAccOneBal = new JLabel("Account1 Balance:");
		lblAccOneBal.setFont(new Font("Arial", Font.PLAIN, 14));
		lblAccOneBal.setBounds(21, 170, 252, 36);
		contentPane.add(lblAccOneBal);
		
		lblAccTwoBal = new JLabel("Account2 Balance:");
		lblAccTwoBal.setFont(new Font("Arial", Font.PLAIN, 14));
		lblAccTwoBal.setBounds(21, 198, 252, 36);
		contentPane.add(lblAccTwoBal);
		
		lblTotalBalance = new JLabel("Total Balance:");
		lblTotalBalance.setFont(new Font("Arial", Font.PLAIN, 14));
		lblTotalBalance.setBounds(21, 226, 252, 36);
		contentPane.add(lblTotalBalance);
		
		JButton btnTransfer = new JButton("Transfer");
		btnTransfer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				start();			
				
			}
		});
		
		btnTransfer.setBounds(95, 128, 89, 23);
		contentPane.add(btnTransfer);
		
	}
	
	
	private void start() {
		SwingWorker<Void, Void> sw = new SwingWorker<Void, Void>(){

			@Override
			protected Void doInBackground() throws Exception {

				if(cboFromAcc.getSelectedItem().toString() == "Account 1") {
					Account.transfer(account1, account2, Integer.parseInt(txtAmount.getText()));
				}
				if(cboFromAcc.getSelectedItem().toString() == "Account 2") {
					Account.transfer(account2, account1, Integer.parseInt(txtAmount.getText()));
				}
				
				return null;
			}

			@Override
			protected void done() {
								
				lblAccOneBal.setText(String.valueOf("Account1 Balance is: $" + account1.getBalance()));
				lblAccTwoBal.setText(String.valueOf("Account2 Balance is: $" + account2.getBalance()));
				lblTotalBalance.setText(String.valueOf("Total Balance: $" + (account1.getBalance() + account2.getBalance())));
				 	
				// dlm.finished();
			}
				
		};
		sw.execute();
		
	}
	
}
