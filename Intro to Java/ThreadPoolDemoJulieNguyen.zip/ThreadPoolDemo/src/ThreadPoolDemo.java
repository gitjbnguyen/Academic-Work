import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/* WARNING: YOU MAY GET DIFFERENT VALUES FOR EACH TIME.
 * 
Starting: 3
Starting: 7
Starting: 6
Starting: 5
Starting: 4
Starting: 2
Starting: 1
Starting: 0
Starting: 9
All tasks submitted for 50 tasks and 10 threads
Starting: 8
End: 2
End: 9
End: 8
End: 0
End: 6
Starting: 12
End: 7
Starting: 15
End: 5
Starting: 16
End: 3
End: 4
Starting: 18
End: 1
Starting: 19
Starting: 17
Starting: 14
Starting: 13
Starting: 11
Starting: 10
End: 16
End: 18
End: 12
Starting: 22
End: 15
Starting: 21
Starting: 20
Starting: 23
End: 19
End: 10
End: 13
Starting: 26
End: 17
End: 14
Starting: 28
End: 11
Starting: 29
Starting: 27
Starting: 25
Starting: 24
End: 20
End: 21
Starting: 31
End: 23
Starting: 30
End: 22
Starting: 32
Starting: 33
End: 24
End: 27
End: 25
End: 29
Starting: 37
End: 28
End: 26
Starting: 38
Starting: 36
Starting: 35
Starting: 34
Starting: 39
End: 31
End: 30
End: 33
End: 32
Starting: 42
Starting: 41
Starting: 40
Starting: 43
End: 37
End: 38
Starting: 45
End: 39
Starting: 46
End: 36
End: 35
End: 34
Starting: 44
Starting: 49
Starting: 48
Starting: 47
End: 41
End: 40
End: 42
End: 43
End: 46
End: 48
End: 44
End: 47
End: 49
End: 45
All tasks submitted for 50 tasks and 2 threads
Starting: 1
Starting: 0
End: 0
End: 1
Starting: 3
Starting: 2
End: 3
End: 2
Starting: 5
Starting: 4
End: 4
Starting: 6
End: 5
Starting: 7
End: 6
End: 7
Starting: 8
Starting: 9
End: 8
Starting: 10
End: 9
Starting: 11
End: 10
End: 11
Starting: 12
Starting: 13
End: 12
End: 13
Starting: 15
Starting: 14
End: 15
End: 14
Starting: 16
Starting: 17
End: 16
End: 17
Starting: 18
Starting: 19
End: 18
End: 19
Starting: 20
Starting: 21
End: 21
End: 20
Starting: 23
Starting: 22
End: 23
Starting: 24
End: 22
Starting: 25
End: 24
Starting: 26
End: 25
Starting: 27
End: 26
End: 27
Starting: 28
Starting: 29
End: 29
End: 28
Starting: 30
Starting: 31
End: 30
End: 31
Starting: 33
Starting: 32
End: 32
End: 33
Starting: 34
Starting: 35
End: 35
End: 34
Starting: 37
Starting: 36
End: 37
Starting: 38
End: 36
Starting: 39
End: 39
End: 38
Starting: 40
Starting: 41
End: 40
Starting: 42
End: 41
Starting: 43
End: 42
Starting: 44
End: 43
Starting: 45
End: 44
Starting: 46
End: 45
Starting: 47
End: 46
Starting: 48
End: 47
Starting: 49
End: 48
End: 49
All tasks completed
Time elapsed for 10 threads: 15006 milliseconds
Time elapsed for 2 threads: 75014 milliseconds

 * Demo for thread pool
 */
public class ThreadPoolDemo {

	static class Processor implements Runnable{
		
		private int id;
		
		//constructor
		public Processor(int id) {
			this.id = id;
		}
		
		@Override
		public void run() {
			// TODO Auto-generated method stub
			System.out.println("Starting: " + id);
			
			//put thread to sleep
		
				try {
					Thread.sleep(3000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} //sleep for 3 seconds
		
			
			
			System.out.println("End: " + id);
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//1.ExecutorService to create a thread pool
		//thread pool size = 2
		long start; 
		long end;
		
		long elapsed10;
		long elapsed2;
		ExecutorService exe = Executors.newFixedThreadPool(2);
		ExecutorService exs = Executors.newFixedThreadPool(10);
		
		//create 2 variables of type long
		
		
		
		
		//2. after creating a thread pool. Let's submit the 10 tasks to exe
		
		start = System.currentTimeMillis();
		
		for(int i = 0; i < 50; i++) {
			//give the processor id
			exs.submit(new Processor(i));
		}
		System.out.println("All tasks submitted for 50 tasks and 10 threads");
		exs.shutdown();
		
		
		try {
			exs.awaitTermination(1, TimeUnit.DAYS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		} //specify the time I will wait: 1 Day
		end = System.currentTimeMillis();
		elapsed10 = end - start;
		
		start = System.currentTimeMillis();
		//submit 2 tasks
		for(int j = 0; j < 50; j++) {
			exe.submit(new Processor(j));
		}
		
		//3. stop accepting new tasks and to shut itself down when all tasks are finished
		
		
		exe.shutdown();
		System.out.println("All tasks submitted for 50 tasks and 2 threads");
		
		//4. wait for all tasks to complete
		try {
			exe.awaitTermination(1, TimeUnit.DAYS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			
			e.printStackTrace();
		} //specify the time I will wait: 1 Day
		end = System.currentTimeMillis();
		elapsed2 = end - start;
		
		System.out.println("All tasks completed");
		System.out.println("Time elapsed for 10 threads: " + elapsed10 + " milliseconds");
		System.out.println("Time elapsed for 2 threads: " + elapsed2 + " milliseconds");
	}

}
