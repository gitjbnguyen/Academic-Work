﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphics_RectShapes_Lib
{
    public class Rectangle
    {
        private double _length;
        private double _width;
        //constructor
        public Rectangle(double length, double width)
        {
            _length = length;
            _width = width;
        }
        //properties
        public virtual double Length { get { return _length; } }
        public virtual double Width { get { return _width; } }
        public virtual double Height { get { return 0; } }

        public virtual double Perimeter()
        {
            double P = 2 * (Length + Width);
            return P;
        }
        public virtual double Area()
        {
            double A = Width * Length;
            return A;
        }
        public virtual double Volume()
        {

            return 0;
        }
    }

}

