﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphics_RectShapes_Lib
{
    public class Pyramid : Box
    {
        public Pyramid(double Length, double Width, double Height) : base(Length, Width, Height)
        {

        }
        public override double Area()
        {
            double A = (Length * Width) + (Length * Math.Sqrt(Math.Pow(Width / 2, 2) + Math.Pow(Height, 2)))
                + (Width * Math.Sqrt(Math.Pow(Length / 2, 2) + Math.Pow(Height, 2)));
            return A;
        }
        public override double Volume()
        {
            double V = (Length * Width * Height) / 3;
            return V;
        }

    }
}
