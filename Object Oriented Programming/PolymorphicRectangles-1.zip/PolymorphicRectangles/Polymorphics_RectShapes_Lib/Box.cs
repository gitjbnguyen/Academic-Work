﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Polymorphics_RectShapes_Lib
{
    public class Box : Rectangle
    {
        private double _height;
        
        public Box(double Length, double Width, double Height): base(Length, Width)
        {
            _height = Height;
        }
        public override double Height { get { return _height; } }
        public override double Area()
        {
            double area = 2 * (Height + Width) + 2 * (Height + Width) + 2 * (Width + Length);
            return area;
        }
        public override double Volume()
        {
            double volume = Length * Width * Height;
            return volume;
        }
    }
}
