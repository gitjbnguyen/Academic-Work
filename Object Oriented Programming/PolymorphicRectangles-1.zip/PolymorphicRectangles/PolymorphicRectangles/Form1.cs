﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Polymorphics_RectShapes_Lib;

namespace PolymorphicRectangles
{
    public partial class Form1 : Form
    {
        List<Rectangle> rectangularShapes = new List<Rectangle>();
        public Form1()
        {
            InitializeComponent();
        }
        private void RectangularDisplay(Rectangle r)
        {
            double area = r.Area();
            double volume = r.Volume();
            double perimeter = r.Perimeter();
            string[] row = { r.Length.ToString("f"), r.Height.ToString("f"), r.Width.ToString("f"),
                area.ToString("f"), volume.ToString("f"), perimeter.ToString("f"), r.GetType().Name };
            ListViewItem lsvitem2 = new ListViewItem(row);
            listView2.Items.Add(lsvitem2);
        }



        private List<Rectangle> getShapesListByName(string name)
        {
            //creates a list of the rectangular shapes
            List<Rectangle> list = new List<Rectangle>();
            foreach (Rectangle r in rectangularShapes)
            {
                if (r.GetType().Name == name)
                    list.Add(r);
            }
            return list;
        }

        private double GetAvgVolOfShapesByName(string name)
        {
            double total = 0;
            int counter = 0;
            foreach (Rectangle r in rectangularShapes)
            {
                if (r.GetType().Name == name)
                {
                    counter++;
                    total += r.Volume();

                }
            }
            return total / counter;
        }
        private List<Rectangle> GetLargerShapesByName()
        {


            double avgVolume = GetAvgVolOfShapesByName(cboAvgShapes.Text);
            List<Rectangle> list = new List<Rectangle>();//list to hold bigger boxes
            foreach (Rectangle r in rectangularShapes)
            {
                if (r.GetType().Name == cboAvgShapes.Text)
                {
                    if (r.Volume() > avgVolume)
                        list.Add(r);
                }

            }
            return list;
        }
        public void Display(List<Rectangle> list)
        {
            listView2.Items.Clear();
            foreach (Rectangle r in list)
            {
                RectangularDisplay(r);
            }
        }



        private void btnRectangle_Click_1(object sender, EventArgs e)
        {
            Random rand = new Random();
            double length = rand.Next(5, 20) + rand.NextDouble();
            double width = rand.Next(1, 20) + rand.NextDouble();
            Rectangle R = new Rectangle(length, width);
            rectangularShapes.Add(R);
            RectangularDisplay(R);
        }

        private void btnBox_Click_1(object sender, EventArgs e)
        {
            Random rand = new Random();
            double length = rand.Next(5, 20) + rand.NextDouble();
            double width = rand.Next(1, 20) + rand.NextDouble();
            double height = rand.Next(5, 20) + rand.NextDouble();
            Box B = new Box(length, width, height);
            rectangularShapes.Add(B);
            RectangularDisplay(B);
        }

        private void btnPyramid_Click_1(object sender, EventArgs e)
        {
            Random rand = new Random();
            double length = rand.Next(5, 20) + rand.NextDouble();
            double width = rand.Next(1, 20) + rand.NextDouble();
            double height = rand.Next(5, 20) + rand.NextDouble();
            Pyramid P = new Pyramid(length, width, height);
            rectangularShapes.Add(P);
            RectangularDisplay(P);
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            listView2.Items.Clear();
            rectangularShapes.Clear();
        }

        private void btnDisplayBigShapes_Click(object sender, EventArgs e)
        {
            GetLargerShapesByName();
            Display(GetLargerShapesByName());
        }

        private void btnDisplayAvgShapes_Click(object sender, EventArgs e)
        {
            double avg = GetAvgVolOfShapesByName(cboAvgShapes.Text);
            MessageBox.Show($"The average of {cboAvgShapes.Text} shapes is {avg:f2}");
        }

        private void btnShapesList_Click(object sender, EventArgs e)
        {
            List<Rectangle> list = getShapesListByName(cboAvgShapes.Text);
            Display(list);
        }
    }
}
