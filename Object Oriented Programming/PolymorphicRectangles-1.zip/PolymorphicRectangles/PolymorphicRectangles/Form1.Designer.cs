﻿namespace PolymorphicRectangles
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnDisplayAvgShapes = new System.Windows.Forms.Button();
            this.btnDisplayBigShapes = new System.Windows.Forms.Button();
            this.cboAvgShapes = new System.Windows.Forms.ComboBox();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.listView2 = new System.Windows.Forms.ListView();
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader9 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader10 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader11 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader12 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader13 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader14 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnPyramid = new System.Windows.Forms.Button();
            this.btnBox = new System.Windows.Forms.Button();
            this.btnRectangle = new System.Windows.Forms.Button();
            this.btnShapesList = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnShapesList);
            this.groupBox1.Controls.Add(this.btnDisplayAvgShapes);
            this.groupBox1.Controls.Add(this.btnDisplayBigShapes);
            this.groupBox1.Controls.Add(this.cboAvgShapes);
            this.groupBox1.Location = new System.Drawing.Point(146, 184);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(179, 134);
            this.groupBox1.TabIndex = 31;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Display Shapes";
            // 
            // btnDisplayAvgShapes
            // 
            this.btnDisplayAvgShapes.Location = new System.Drawing.Point(6, 98);
            this.btnDisplayAvgShapes.Name = "btnDisplayAvgShapes";
            this.btnDisplayAvgShapes.Size = new System.Drawing.Size(160, 23);
            this.btnDisplayAvgShapes.TabIndex = 25;
            this.btnDisplayAvgShapes.Text = "Display Avg Shapes";
            this.btnDisplayAvgShapes.UseVisualStyleBackColor = true;
            this.btnDisplayAvgShapes.Click += new System.EventHandler(this.btnDisplayAvgShapes_Click);
            // 
            // btnDisplayBigShapes
            // 
            this.btnDisplayBigShapes.Location = new System.Drawing.Point(6, 69);
            this.btnDisplayBigShapes.Name = "btnDisplayBigShapes";
            this.btnDisplayBigShapes.Size = new System.Drawing.Size(160, 23);
            this.btnDisplayBigShapes.TabIndex = 23;
            this.btnDisplayBigShapes.Text = "Display Big Shapes";
            this.btnDisplayBigShapes.UseVisualStyleBackColor = true;
            this.btnDisplayBigShapes.Click += new System.EventHandler(this.btnDisplayBigShapes_Click);
            // 
            // cboAvgShapes
            // 
            this.cboAvgShapes.FormattingEnabled = true;
            this.cboAvgShapes.Items.AddRange(new object[] {
            "Rectangle",
            "Box",
            "Pyramid"});
            this.cboAvgShapes.Location = new System.Drawing.Point(6, 12);
            this.cboAvgShapes.Name = "cboAvgShapes";
            this.cboAvgShapes.Size = new System.Drawing.Size(160, 21);
            this.cboAvgShapes.TabIndex = 24;
            // 
            // btnClearAll
            // 
            this.btnClearAll.Location = new System.Drawing.Point(379, 191);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(106, 93);
            this.btnClearAll.TabIndex = 30;
            this.btnClearAll.Text = "CLEAR ALL";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // listView2
            // 
            this.listView2.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader8,
            this.columnHeader9,
            this.columnHeader10,
            this.columnHeader11,
            this.columnHeader12,
            this.columnHeader13,
            this.columnHeader14});
            this.listView2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listView2.FullRowSelect = true;
            this.listView2.GridLines = true;
            this.listView2.Location = new System.Drawing.Point(12, 12);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(662, 151);
            this.listView2.TabIndex = 29;
            this.listView2.UseCompatibleStateImageBehavior = false;
            this.listView2.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Length";
            this.columnHeader8.Width = 96;
            // 
            // columnHeader9
            // 
            this.columnHeader9.Text = "Height";
            this.columnHeader9.Width = 66;
            // 
            // columnHeader10
            // 
            this.columnHeader10.Text = "Width";
            this.columnHeader10.Width = 83;
            // 
            // columnHeader11
            // 
            this.columnHeader11.Text = "Area";
            this.columnHeader11.Width = 106;
            // 
            // columnHeader12
            // 
            this.columnHeader12.Text = "Volume";
            this.columnHeader12.Width = 81;
            // 
            // columnHeader13
            // 
            this.columnHeader13.Text = "Perimeter";
            this.columnHeader13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader13.Width = 95;
            // 
            // columnHeader14
            // 
            this.columnHeader14.Text = "Type";
            this.columnHeader14.Width = 130;
            // 
            // btnPyramid
            // 
            this.btnPyramid.Location = new System.Drawing.Point(33, 261);
            this.btnPyramid.Name = "btnPyramid";
            this.btnPyramid.Size = new System.Drawing.Size(75, 23);
            this.btnPyramid.TabIndex = 28;
            this.btnPyramid.Text = "Pyramid";
            this.btnPyramid.UseVisualStyleBackColor = true;
            this.btnPyramid.Click += new System.EventHandler(this.btnPyramid_Click_1);
            // 
            // btnBox
            // 
            this.btnBox.Location = new System.Drawing.Point(33, 232);
            this.btnBox.Name = "btnBox";
            this.btnBox.Size = new System.Drawing.Size(75, 23);
            this.btnBox.TabIndex = 27;
            this.btnBox.Text = "Box";
            this.btnBox.UseVisualStyleBackColor = true;
            this.btnBox.Click += new System.EventHandler(this.btnBox_Click_1);
            // 
            // btnRectangle
            // 
            this.btnRectangle.Location = new System.Drawing.Point(33, 203);
            this.btnRectangle.Name = "btnRectangle";
            this.btnRectangle.Size = new System.Drawing.Size(75, 23);
            this.btnRectangle.TabIndex = 26;
            this.btnRectangle.Text = "Rectangle";
            this.btnRectangle.UseVisualStyleBackColor = true;
            this.btnRectangle.Click += new System.EventHandler(this.btnRectangle_Click_1);
            // 
            // btnShapesList
            // 
            this.btnShapesList.Location = new System.Drawing.Point(6, 40);
            this.btnShapesList.Name = "btnShapesList";
            this.btnShapesList.Size = new System.Drawing.Size(160, 23);
            this.btnShapesList.TabIndex = 26;
            this.btnShapesList.Text = "Display Shapes List by Name";
            this.btnShapesList.UseVisualStyleBackColor = true;
            this.btnShapesList.Click += new System.EventHandler(this.btnShapesList_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 345);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnClearAll);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.btnPyramid);
            this.Controls.Add(this.btnBox);
            this.Controls.Add(this.btnRectangle);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnDisplayAvgShapes;
        private System.Windows.Forms.Button btnDisplayBigShapes;
        private System.Windows.Forms.ComboBox cboAvgShapes;
        private System.Windows.Forms.Button btnClearAll;
        private System.Windows.Forms.ListView listView2;
        private System.Windows.Forms.ColumnHeader columnHeader8;
        private System.Windows.Forms.ColumnHeader columnHeader9;
        private System.Windows.Forms.ColumnHeader columnHeader10;
        private System.Windows.Forms.ColumnHeader columnHeader11;
        private System.Windows.Forms.ColumnHeader columnHeader12;
        private System.Windows.Forms.ColumnHeader columnHeader13;
        private System.Windows.Forms.ColumnHeader columnHeader14;
        private System.Windows.Forms.Button btnPyramid;
        private System.Windows.Forms.Button btnBox;
        private System.Windows.Forms.Button btnRectangle;
        private System.Windows.Forms.Button btnShapesList;
    }
}

