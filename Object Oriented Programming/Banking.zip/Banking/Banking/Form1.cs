﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BankingLib;
namespace Banking
{
    public partial class Form1 : Form
    {
        string[] bank = {"Bank of America", "Wells Fargo", "Chase", "BECU", "Citibank", "Captial One",
        "KeyBank", "American Express"};
        List<Account> accounts = new List<Account>();
        List<Account> belowAverageAccounts = new List<Account>();
        int sindex = 0;
        public Form1()
        {


            InitializeComponent();


        }

        private void Display(Account account)
        {
            string[] row = new string[0];
            //display in the listview row as an array, refer to polymorphic shapes

            if (account.GetType() == typeof(SavingsAccount))
            {
                SavingsAccount sa = (SavingsAccount)account;
                row = new string[] {account.accountNumber.ToString(),
            sa.currentBalance.ToString("C"), //C will return the string as currency
            sa.bankName,
            sa.GetType().Name,
            (sa.interestRate * sa.currentBalance).ToString("C")
                };
            }
            else
            {
                row = new string[] {account.accountNumber.ToString(),
            account.currentBalance.ToString("C"), //C will return the string as currency
            account.bankName,
            account.GetType().Name,
            0.ToString()
            };
            }
          



            ListViewItem lstvitem = new ListViewItem(row);
            listView1.Items.Add(lstvitem);



        }
        private void Display(List<Account> account)
        {
            listView1.Items.Clear();
            foreach (Account acc in account)
            {
                Display(acc);
            }
        }



        private void Form1_Load(object sender, EventArgs e)
        {


            decimal fees = 25;
            decimal interestRate = 0.025m;
            SavingsAccount s1 = new SavingsAccount(6006, 6000, "BECU", interestRate);
            SavingsAccount s2 = new SavingsAccount(7007, 7500, "BECU", interestRate);
            SavingsAccount s3 = new SavingsAccount(8008, 8500, "Bank of America", interestRate);
            SavingsAccount s4 = new SavingsAccount(9009, 9000, "Bank of America", interestRate);
            SavingsAccount s5 = new SavingsAccount(10010, 5500, "Chase", interestRate);
            accounts.Add(s1);
            accounts.Add(s2);
            accounts.Add(s3);
            accounts.Add(s4);
            accounts.Add(s5);
            CheckingAccount c1 = new CheckingAccount(1001, 5000, "BECU", 1000, fees);
            CheckingAccount c2 = new CheckingAccount(2002, 6000, "BECU", 1000, fees);
            CheckingAccount c3 = new CheckingAccount(3003, 5050, "Bank of America", 1000, fees);
            CheckingAccount c4 = new CheckingAccount(4004, 5750, "Bank of America", 1000, fees);
            CheckingAccount c5 = new CheckingAccount(5005, 5030, "Chase", 1000, fees);
            accounts.Add(c1);
            accounts.Add(c2);
            accounts.Add(c3);
            accounts.Add(c4);
            accounts.Add(c5);
            Display(accounts);

            foreach (Account acc in accounts)
            {
                cboFromAccount.Items.Add(acc.accountNumber);
                cboToAccount.Items.Add(acc.accountNumber);
            }

        }


        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            decimal funds = 0; 
            // listView1.SelectedIndices[0]
            if (decimal.TryParse(txtAmounts.Text, out funds)) 
            if (listView1.SelectedIndices.Count > 0)
            {
                Account acc = accounts[listView1.SelectedIndices[0]];
                // acc = Accounts[X] where X = SelectedIndices[0] so only first selection (and only)
                if (acc.Withdraw(funds)) { }
                else
                {
                    MessageBox.Show("Nonsufficient Funds. Fee charged.");
                }
            }
            Display(accounts);

        }



        //same thing except reversed
        private void btnDeposit_Click(object sender, EventArgs e)
        {
            decimal funds;
            if (decimal.TryParse(txtAmounts.Text, out funds)) 
            if (listView1.SelectedIndices.Count > 0)
            {
                Account acc = accounts[listView1.SelectedIndices[0]];
                // acc = Accounts[X] where X = SelectedIndices[0] so only first selection (and only)
                acc.Deposit(funds);
            }
            Display(accounts);
        }

        private void btnTransfer_Click(object sender, EventArgs e)
        {
            int AccountA = cboFromAccount.SelectedIndex;
            int AccountB = cboToAccount.SelectedIndex;
            decimal funds = decimal.Parse(txtAmounts.Text);

            
            if (Account.Transfer(accounts[AccountA], accounts[AccountB], funds))
            {

            }
            else
            {
                MessageBox.Show("transaction cancelled: the funds demanded are too high.");
            }
            Display(accounts);


        }

        private decimal AverageCheckings(List<Account> accounts)
        {
            decimal total = 0;
            int counter = 0;
            foreach (Account CA in accounts)
            {
                if (CA is CheckingAccount)
                {
                    counter++;
                    total += CA.currentBalance;
                }
            }
            if (counter == 0)
            {
                return 0;
            }
            else
            {
                return total / counter;
            }
        }
        private decimal AverageSavings(List<Account> accounts)
        {
            decimal total = 0;
            int counter = 0;
            foreach (Account CA in accounts)
            {
                if (CA is SavingsAccount)
                {
                    counter++;
                    total += CA.currentBalance;
                }
            }
            if (counter == 0)
            {
                return 0;
            }
            else
            {
                return total / counter;
            }
        }
        private void btnGetAvg_Click(object sender, EventArgs e)
        {


            lblAverage.Text = "The average for Checkings is: " + AverageCheckings(accounts).ToString("c") + "\n" + "The average " +
                "for Savings is: " + AverageSavings(accounts).ToString("c");
        }
        private void belowAverage(List<Account> accounts)
        {
            belowAverageAccounts.Clear();

            decimal avgC = AverageCheckings(accounts);

            foreach (Account acc in accounts)
            {
                if (acc is CheckingAccount)
                {
                    if (acc.currentBalance < avgC)
                    {
                        belowAverageAccounts.Add(acc);
                    }

                }
            }
            Display(belowAverageAccounts);

        }
        private void btnGetLowBalances_Click(object sender, EventArgs e)
        {
            belowAverage(accounts);
        }
        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listView1.SelectedIndices.Count > 0)
            {
                sindex = listView1.SelectedIndices[0];
            }
        }

        private void btnAccrueInterest_Click(object sender, EventArgs e)
        {
            Account acc = null;

            if(listView1.SelectedIndices.Count > 0)
            {
                acc = accounts[listView1.SelectedIndices[0]];
            }

            acc.ApplyInterest();

            DisplaySavings();


            //listView1.Items.Clear();
            //foreach (Account acc in accounts)
            //{
            //    if (acc.GetType() == typeof(SavingsAccount))
            //    {
            //        Display(acc);
            //    }


            //    //if (listView1.SelectedIndices.Count > 0)
            //    //{
            //    //    DisplaySavings();
            //    //    Account acc = accounts[listView1.SelectedIndices[0]];
            //    //    acc.ApplyInterest();

            //    //}
            //}

            //if (listView1.SelectedIndices.Count > 0)
            //{
            //    DisplaySavings();
            //    Account acc = accounts[listView1.SelectedIndices[0]];
            //    acc.ApplyInterest();
            //}
            //Display(accounts);

            //DisplaySavings();
        }

        private void btnDisplayAll_Click(object sender, EventArgs e)
        {
            Display(accounts);
        }

        private void btnViewInterest_Click(object sender, EventArgs e)
        {
            DisplaySavings();
        }

       private void DisplaySavings()
        {
            listView1.Items.Clear();
            foreach (Account acc in accounts)
            {
                if (acc.GetType() == typeof(SavingsAccount))
                {
                    Display(acc);
                }
            }
           
        }


    }
}
