﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLib
{
    public class SavingsAccount : Account
    {
        //still handling money and so decimal percentage is necessary instead of double.
        private decimal _interestRate;

        public SavingsAccount(int accountNumber, decimal currentBalance, string bankName, decimal interestRate )
            :base(accountNumber, currentBalance, bankName)
        {
            _interestRate = interestRate;
        }

        public decimal interestRate { get { return _interestRate; } }

        //from parent class and to here, the interest is overwritten and redefined to a different value
        public override decimal ApplyInterest()
        {
            decimal interest = currentBalance * interestRate;
            currentBalance += interest;
            return interest;
        }
    }
}
