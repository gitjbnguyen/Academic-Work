﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLib
{
    public class CheckingAccount:Account
    {
        private decimal _minBalance;
        private decimal _fees;

        public CheckingAccount(int accountNumber, decimal currentBalance, string bankName,
            decimal minBalance, decimal fees):base(accountNumber, currentBalance, bankName)
        {
            _minBalance = minBalance;
            _fees = fees;
        }
        //some methods/properties can't be overwritten
        public decimal minBalance { get { return _minBalance; } }
        public decimal fees { get { return _fees; } }

        //overiding because of fees that are included
        public override bool Withdraw(decimal amount)
        {
            if (currentBalance < amount)
            {
                currentBalance -= fees;
                return false;
            }
            else
            {
                currentBalance -= amount;
                return true;
            }
        }

    }

  
}
