﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingLib
{
    public class Account
    {
        // this is the virtual parent class 

        //private fields
        private int _accountNumber;
        private decimal _currentBalance;
        private string _bankName;

        //constructors
        public Account(int accountNumber, decimal currentBalance, string bankName)
        {
            _accountNumber = accountNumber;
            _currentBalance = currentBalance;
            _bankName = bankName;
        }
        //properties
        public virtual int accountNumber { get { return _accountNumber; } }
        public virtual decimal currentBalance { get { return _currentBalance; } set { _currentBalance = value; } }

        public virtual string bankName { get { return _bankName; } }

        //methods
        public virtual decimal Deposit(decimal amount)
        {
            return currentBalance += amount;

        }
        public virtual bool Withdraw(decimal amount)
        {

            if (currentBalance < amount)
            {
                return false;
            }
            else
            {
                currentBalance -= amount;
                return true;
            }
        }
        public virtual decimal ApplyInterest()
        {
            //interest will be defined later in the child class
            return 0;
        }

        //void methods can't be virtual
        public static bool Transfer(Account fromAccount, Account toAccount, decimal amount)
        {


            if (fromAccount.Withdraw(amount))
            {
                toAccount.Deposit(amount);
                return true;
            }
            else
            {
                return false;
            }


        }
    }
}
